"""Excludes the Maldives from the ages 10-14 (completed primary) contrast everywhere it is pooled or bias-adjusted.
Reason: only 13 first births before age 15 in the Maldives sample, so the contrast is not estimable (CI 0.05 to >100,000). Idempotent."""
import re, sys
from pathlib import Path
B = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
HELP = 'ORD = lambda t: [c for c in ORDER if not (c == "Maldives" and str(t).startswith("early"))]  # Maldives: ages 10-14 contrast not estimable\n'
def edit(rel, fn):
    p = B / rel; s = p.read_text(); n = fn(s)
    if n != s: p.write_text(n); print("patched", rel)
    else: print("unchanged", rel)
def addhelp(s):
    if "ORD = lambda" in s: return s
    return re.sub(r'(\nORDER = \[[^\n]*\n)', lambda m: m.group(1) + HELP, s, count=1)
def pa(s):
    s = addhelp(s); return s.replace('.set_index("country").loc[ORDER]', '.set_index("country").loc[ORD(t)]')
def q2(s):
    s = addhelp(s); s = s.replace('.set_index("country").loc[ORDER]', '.set_index("country").loc[ORD(t)]')
    return s.replace('np.array([sh[c][t] for c in ORDER])', 'np.array([sh[c][t] for c in ORD(t)])')
def p2(s):
    s = addhelp(s); s = s.replace('for c in ORDER for t in TERMS)', 'for t in TERMS for c in ORD(t))')
    s = s.replace('.set_index("country").loc[ORDER]', '.set_index("country").loc[ORD(t)]'); return s.replace('for c in ORDER]); ya', 'for c in ORD(t)]); ya')
def q1(s):
    s = addhelp(s); return s.replace("        y, s = [], []\n        for c in ORDER:", "        y, s = [], []\n        for c in ORD(t):")
def p1(s):
    s = addhelp(s); return s.replace('for c in ORDER for t in TERMS)', 'for t in TERMS for c in ORD(t))').replace('.set_index("country").loc[ORDER]', '.set_index("country").loc[ORD(t)]').replace('for c in ORDER]); ya', 'for c in ORD(t)]); ya')
def st2(s):
    if "n.e." in s: return s
    s = s.replace('x = d[(d.model == m) & (d.term == term)].sort_values("country")', 'x = d[(d.model == m) & (d.term == term)].sort_values("country"); x = x[~((x.country == "Maldives") & x.term.str.startswith("early"))]')
    s = s.replace('cell = lambda m, t, c: (lambda r: f"{r.HR:.2f} ({r.lo_pct:.2f}, {r.hi_pct:.2f})")(prim[(prim.model == m) & (prim.term == t) & (prim.country == c)].iloc[0])',
      'cell = lambda m, t, c: "n.e." if (c == "Maldives" and t.startswith("early")) else (lambda r: f"{r.HR:.2f} ({r.lo_pct:.2f}, {r.hi_pct:.2f})")(prim[(prim.model == m) & (prim.term == t) & (prim.country == c)].iloc[0])')
    a = s.index("    def forest(term"); b = s.index("    forest(TERMS[0]"); f = s[a:b]
    f = f.replace("        x = d[d.term == term].set_index", "        avail = [c for c in globals()['avail'] if not (c == 'Maldives' and term.startswith('early'))]\n        x = d[d.term == term].set_index")
    return s[:a] + f + s[b:]
def pm(s):
    if "n.e." in s: return s
    s = s.replace('s = M[(M.schooling == sch) & (M.term == t) & (M["sample"] == "all women")].sort_values("country")', 's = M[(M.schooling == sch) & (M.term == t) & (M["sample"] == "all women")].sort_values("country"); s = s[~((s.country == "Maldives") & s.term.str.startswith("early"))]')
    return s.replace('**{t: f"{g[g.term == t].HR.iloc[0]:.2f} ({g[g.term == t].lo.iloc[0]:.2f}, {g[g.term == t].hi.iloc[0]:.2f})" for t in TERMS}', '**{t: ("n.e." if (c == "Maldives" and t.startswith("early")) else f"{g[g.term == t].HR.iloc[0]:.2f} ({g[g.term == t].lo.iloc[0]:.2f}, {g[g.term == t].hi.iloc[0]:.2f})") for t in TERMS}')
for rel, fn in [("bias_analysis/primary_allwomen.py", pa), ("bias_analysis/qba_pool2.py", q2), ("bias_analysis/qba_prob2.py", p2), ("bias_analysis/qba_pool.py", q1), ("bias_analysis/qba_prob.py", p1), ("run_stage2.py", st2), ("pool_marriage.py", pm)]: edit(rel, fn)
