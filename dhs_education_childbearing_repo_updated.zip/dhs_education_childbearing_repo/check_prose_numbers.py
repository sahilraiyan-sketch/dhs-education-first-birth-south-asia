"""Recomputes the numbers quoted in the manuscript text from results/ and writes results/stage2/prose_numbers_check.csv."""
import os, sys
from pathlib import Path
import numpy as np, pandas as pd
BASE = Path(os.getcwd()); R = BASE / "results"; S2 = R / "stage2"
C = ["Bangladesh", "India", "Nepal", "Pakistan", "Afghanistan", "Myanmar"]; E, LI, LC = "early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv"
prim = pd.read_csv(S2 / "stage1_all_primary.csv"); t1 = pd.read_csv(S2 / "table1_sample.csv").set_index("country"); ar = pd.read_csv(S2 / "table3_absolute_risks.csv")
P1 = pd.read_csv(S2 / "pooled_primary.csv"); P2 = pd.read_csv(S2 / "pooled_harmonized10.csv"); L1 = pd.read_csv(S2 / "leave_one_out_primary.csv")
os1 = pd.read_csv(S2 / "onestage_mixed_results.csv").set_index("term") if (S2 / "onestage_mixed_results.csv").exists() else None
mr = pd.read_csv(S2 / "meta_regression.csv") if (S2 / "meta_regression.csv").exists() else None
spec = {c: pd.read_csv(R / c / "stage1_specifications.csv") for c in C}; lmk = {c: pd.read_csv(R / c / "stage1_landmark.csv") for c in C}
allw = {c: pd.read_csv(R / c / "stage1_allwomen.csv") for c in ("India", "Nepal", "Myanmar")}
def hr(c, term, m="A"): return float(prim[(prim.country == c) & (prim.term == term) & (prim.model == m)].HR.iloc[0])
def sp(c, s, term, m="A"): return float(spec[c][(spec[c].spec == s) & (spec[c].term == term) & (spec[c].model == m)].HR.iloc[0])
def pooled(setname, term, field, d=P1, m="A"): return float(d[(d.set == setname) & (d.term == term) & (d.model == m)][field].iloc[0])
def risk(c, key, age): return 100 * float(ar[(ar.country == c) & (ar.by_age == age) & ar.group.str.startswith(key)].risk.iloc[0])
TV, NV, MAR = "time-varying (attained by age a)", "naive fixed (final ed.)", "TV education + time-varying marriage"
rows = []
def add(where, text, quoted, value, nd=2):
    tol = 0.5 * 10 ** (-nd) + 1e-9; rows.append(dict(where=where, statement=text, quoted=quoted, recomputed=round(float(value), 4), status="OK" if abs(round(float(value), nd) - quoted) <= tol else "CHECK"))
tot_n, tot_e = int(t1.n_women.sum()), int(t1.events.sum())
add("Abstract/Results 3.1", "women analysed", 449065, tot_n, 0); add("Abstract/Results 3.1", "first births before 20", 175846, tot_e, 0)
add("Results 3.1", "weighted % before 20, Myanmar (28%)", 28, t1.loc["Myanmar", "pct_birth_before20_weighted"], 0); add("Results 3.1", "weighted % before 20, Bangladesh (64%)", 64, t1.loc["Bangladesh", "pct_birth_before20_weighted"], 0)
add("Results 3.1", "weighted % before 15, Myanmar (0.9)", 0.9, t1.loc["Myanmar", "pct_before15_weighted"], 1); add("Results 3.1", "weighted % before 15, Bangladesh (7.5)", 7.5, t1.loc["Bangladesh", "pct_before15_weighted"], 1)
for c, q in zip(C, (0.35, 0.33, 0.30, 0.29, 0.32, 0.26)): add("Table 2 / Results 3.2", f"early primary HR, {c}", q, hr(c, E))
add("Results 3.2", "early HR range: minimum (Myanmar 0.26)", 0.26, min(hr(c, E) for c in C)); add("Results 3.2", "early HR range: maximum (Bangladesh 0.35)", 0.35, max(hr(c, E) for c in C))
add("Results 3.2", "late HR Myanmar 0.21", 0.21, hr("Myanmar", LC)); add("Results 3.2", "late HR Nepal 0.27", 0.27, hr("Nepal", LC)); add("Results 3.2", "late HR Pakistan 0.35", 0.35, hr("Pakistan", LC)); add("Results 3.2", "late HR Afghanistan 0.66", 0.66, hr("Afghanistan", LC))
am = prim[(prim.country == "Myanmar") & (prim.term == LC) & (prim.model == "A")].iloc[0]; af = prim[(prim.country == "Afghanistan") & (prim.term == LC) & (prim.model == "A")].iloc[0]
add("Results 3.2", "Myanmar late CI low 0.12", 0.12, am.lo_pct); add("Results 3.2", "Myanmar late CI high 0.34", 0.34, am.hi_pct); add("Results 3.2", "Afghanistan late CI low 0.47", 0.47, af.lo_pct); add("Results 3.2", "Afghanistan late CI high 0.85", 0.85, af.hi_pct)
add("Results 3.2", "incomplete secondary: Myanmar 0.46", 0.46, hr("Myanmar", LI)); add("Results 3.2", "incomplete secondary: Bangladesh 0.79", 0.79, hr("Bangladesh", LI))
add("Results 3.2", "Model B late, Bangladesh 0.36", 0.36, hr("Bangladesh", LC, "B")); add("Results 3.2", "Model B late, India 0.35", 0.35, hr("India", LC, "B"))
cvals = {c: sp(c, TV, LC, "C") for c in C}; add("Results 3.2", "Model C late: minimum 0.32 (Nepal)", 0.32, min(cvals.values())); add("Results 3.2", "Model C late: maximum 0.68 (Afghanistan)", 0.68, max(cvals.values()))
for c, q in zip(C, (0.29, 0.24, 0.26, 0.34, 0.54, 0.18)): add("Results 3.3", f"late HR with final schooling, {c}", q, sp(c, NV, "late_comp_sec"))
for c, q in zip(C, (0.31, 0.29, 0.27, 0.35, 0.66, 0.21)): add("Results 3.3", f"late HR time-varying, {c}", q, hr(c, LC))
fx = [sp(c, "naive fixed, primary-completion contrast", "early_prim_comp_fx") for c in C]; add("Results 3.3", "early final-schooling HR minimum 0.25", 0.25, min(fx)); add("Results 3.3", "early final-schooling HR maximum 0.33", 0.33, max(fx))
ne = [sp(c, NV, "early_comp_sec") for c in C]; add("Results 3.3", "naive early complete-secondary HR minimum 0.01", 0.01, min(ne)); add("Results 3.3", "naive early complete-secondary HR maximum 0.17", 0.17, max(ne))
for c, q in zip(C, (0.41, 0.42, 0.33, 0.33, 0.65, 0.24)): add("Results 3.3", f"landmark grade 9+, {c}", q, float(lmk[c][(lmk[c].model == "A") & (lmk[c].term == "ed15_grade9_plus")].HR.iloc[0]))
for c, q in zip(C, (0.34, 0.32, 0.29, 0.36, 0.72, 0.23)): add("Results 3.3", f"entry age 7 late HR, {c}", q, sp(c, "TV entry age 7", LC))
ch = [100 * (hr(c, LC) / sp(c, NV, "late_comp_sec") - 1) for c in C]; add("Discussion", "change from final to time-varying: minimum 3%", 3, min(abs(x) for x in ch), 0); add("Discussion", "change from final to time-varying: maximum 23%", 23, max(abs(x) for x in ch), 0)
for c, q in zip(C, (0.55, 0.66, 0.59, 0.85, 1.02, 0.58)): add("Results 3.4 / Abstract", f"late HR with time-varying marriage, {c}", q, sp(c, MAR, LC))
me = [sp(c, MAR, E) for c in C]; add("Results 3.4", "early HR with marriage: minimum 0.51", 0.51, min(me)); add("Results 3.4", "early HR with marriage: maximum 0.80", 0.80, max(me))
for c, q in (("India", 0.18), ("Nepal", 0.18), ("Myanmar", 0.11)):
    a = allw[c]; add("Results 3.4", f"all-women late HR, {c}", q, float(a[(a.spec.str.contains("no marriage")) & (a.model == "A") & (a.term == LC)].HR.iloc[0]))
for c, q in (("India", 0.65), ("Nepal", 0.58), ("Myanmar", 0.56)):
    a = allw[c]; add("Results 3.4", f"all-women late HR with marriage, {c}", q, float(a[(a.spec.str.contains("time-varying marriage")) & (a.model == "A") & (a.term == LC)].HR.iloc[0]))
rn = {c: risk(c, "No schooling", 20) for c in C}; add("Results 3.5 / Abstract", "no schooling, risk by 20: Myanmar 37.5", 37.5, rn["Myanmar"], 1); add("Results 3.5 / Abstract", "no schooling, risk by 20: Bangladesh 79.1", 79.1, rn["Bangladesh"], 1)
add("Results 3.5", "primary only vs none, Bangladesh 77.0", 77.0, risk("Bangladesh", "Primary only", 20), 1); add("Results 3.5", "primary only vs none, Pakistan 41.9", 41.9, risk("Pakistan", "Primary only", 20), 1); add("Results 3.5", "none, Pakistan 43.0", 43.0, rn["Pakistan"], 1)
for c, q in zip(("Myanmar", "Pakistan", "Nepal", "India", "Bangladesh", "Afghanistan"), (10.9, 18.7, 25.3, 25.4, 42.5, 45.1)): add("Results 3.5 / Abstract", f"completed secondary, risk by 20: {c}", q, risk(c, "Complete secondary", 20), 1)
for c, q in zip(("Afghanistan", "Pakistan", "Myanmar", "India", "Bangladesh", "Nepal"), (13.6, 24.3, 26.7, 26.8, 36.7, 37.5)):
    add("Results 3.5", f"risk difference secondary vs none (pp): {c}", q, -100 * float(ar[(ar.country == c) & (ar.by_age == 20) & ar.group.str.startswith("Risk difference: complete secondary minus No")].risk.iloc[0]), 1)
p15 = [risk(c, "Primary only", 15) for c in C]; n15 = [risk(c, "No schooling", 15) for c in C]
add("Results 3.5", "by age 15, primary: minimum 0.5", 0.5, min(p15), 1); add("Results 3.5", "by age 15, primary: maximum 5.5 (Bangladesh)", 5.5, max(p15), 1); add("Results 3.5", "by age 15, none: minimum 1.7", 1.7, min(n15), 1); add("Results 3.5", "by age 15, none: maximum 14.9", 14.9, max(n15), 1)
add("Abstract", "no schooling by 20: minimum 38", 38, min(rn.values()), 0); add("Abstract", "no schooling by 20: maximum 79", 79, max(rn.values()), 0)
add("Results 3.6 / Abstract", "pooled early HR 0.33", 0.33, pooled("all countries", E, "HR")); add("Results 3.6 / Abstract", "pooled early CI low 0.30", 0.30, pooled("all countries", E, "hksj_lo")); add("Results 3.6 / Abstract", "pooled early CI high 0.35", 0.35, pooled("all countries", E, "hksj_hi"))
add("Results 3.6", "pooled early tau 0", 0, pooled("all countries", E, "tau")); add("Results 3.6", "pooled early I2 0", 0, pooled("all countries", E, "I2"), 0)
for k, q in (("HR", 0.33), ("hksj_lo", 0.23), ("hksj_hi", 0.48), ("pi_lo", 0.13), ("pi_hi", 0.81)): add("Results 3.6 / Abstract", f"pooled late all six: {k}", q, pooled("all countries", LC, k))
add("Results 3.6 / Abstract", "pooled late I2 98", 98, pooled("all countries", LC, "I2"), 0)
for k, q in (("HR", 0.30), ("hksj_lo", 0.26), ("hksj_hi", 0.35), ("pi_lo", 0.22), ("pi_hi", 0.40)): add("Results 3.6 / Abstract", f"pooled late core four: {k}", q, pooled("core four", LC, k))
add("Results 3.6", "core four late I2 84", 84, pooled("core four", LC, "I2"), 0)
lo_af = L1[(L1.model == "A") & (L1.term == LC) & (L1.omitted == "Afghanistan")].iloc[0]; add("Results 3.6", "omit Afghanistan HR 0.30", 0.30, lo_af.HR); add("Results 3.6", "omit Afghanistan CI low 0.26", 0.26, lo_af.hksj_lo); add("Results 3.6", "omit Afghanistan CI high 0.34", 0.34, lo_af.hksj_hi); add("Results 3.6", "omit Afghanistan I2 80", 80, lo_af.I2, 0)
oth = L1[(L1.model == "A") & (L1.term == LC) & (L1.omitted != "Afghanistan")].HR; add("Results 3.6", "omit any other country: minimum 0.32", 0.32, oth.min()); add("Results 3.6", "omit any other country: maximum 0.35", 0.35, oth.max())
for k, q in (("HR", 0.35), ("hksj_lo", 0.24), ("hksj_hi", 0.50)): add("Results 3.6", f"harmonized 10+ yr, all six: {k}", q, pooled("all countries", LC, k, P2))
for k, q in (("HR", 0.32), ("hksj_lo", 0.26), ("hksj_hi", 0.41)): add("Results 3.6", f"harmonized 10+ yr, core four: {k}", q, pooled("core four", LC, k, P2))
for k, q in (("HR", 0.67), ("hksj_lo", 0.56), ("hksj_hi", 0.81), ("pi_lo", 0.43), ("pi_hi", 1.05)): add("Results 3.6", f"pooled incomplete secondary: {k}", q, pooled("all countries", LI, k))
if os1 is not None:
    for term, q, ql, qh in (("e_early", .33, .31, .34), ("e_late_inc", .68, .59, .78), ("e_late_comp", .33, .24, .47)):
        add("Results 3.6 / Table 4", f"one-stage {term} HR", q, os1.loc[term, "HR"]); add("Results 3.6 / Table 4", f"one-stage {term} CI low", ql, os1.loc[term, "lo_t"]); add("Results 3.6 / Table 4", f"one-stage {term} CI high", qh, os1.loc[term, "hi_t"])
    add("Results 3.6", "one-stage late tau 0.31", 0.31, os1.loc["e_late_comp", "tau"]); add("Results 3.6", "two-stage late tau 0.32", 0.32, pooled("all countries", LC, "tau"))
if mr is not None:
    m = mr[mr.term == LC]; add("Results 3.7", "meta-regression, late secondary: smallest p is at least 0.2", 0.2, min(1.0, np.floor(m.p.min() * 10) / 10), 1)
    r = mr[(mr.term == LI) & (mr.moderator == "pct_married_before_18")].iloc[0]; add("Results 3.7", "incomplete secondary, % married <18: ratio 1.14", 1.14, r.ratio_HR_per_SD); add("Results 3.7", "incomplete secondary, % married <18: p 0.04", 0.04, r.p)
core_late = [hr(c_, LC) for c_ in C[:4]]; add("Discussion", "four multi-wave countries late HR: minimum 0.27", 0.27, min(core_late)); add("Discussion", "four multi-wave countries late HR: maximum 0.35", 0.35, max(core_late))
rd = [-100 * float(ar[(ar.country == c_) & (ar.by_age == 20) & ar.group.str.startswith("Risk difference: complete secondary minus No")].risk.iloc[0]) for c_ in C]
add("Discussion", "risk differences secondary vs none: minimum 14 pp", 14, min(rd), 0); add("Discussion", "risk differences secondary vs none: maximum 37 pp", 37, max(rd), 0)
add("Discussion/Abstract", "late HR range across countries: minimum 0.21", 0.21, min(hr(c_, LC) for c_ in C)); add("Discussion/Abstract", "late HR range across countries: maximum 0.66", 0.66, max(hr(c_, LC) for c_ in C))
add("Abstract", "completed secondary, risk by 20: minimum 11%", 11, min(risk(c_, "Complete secondary", 20) for c_ in C), 0); add("Abstract", "completed secondary, risk by 20: maximum 45%", 45, max(risk(c_, "Complete secondary", 20) for c_ in C), 0)
# ---- revision additions (Oct 2026): first marriage (extras2.py + pool_marriage.py), exposure person-years, harmonized country values
h10 = pd.read_csv(S2 / "stage1_all_harmonized10.csv")
def hh(c, d): return float(d[(d.country == c) & (d.term == LC) & (d.model == "A")].HR.iloc[0])
for c, q1, q2 in (("India", 0.29, 0.38), ("Afghanistan", 0.66, 0.65), ("Myanmar", 0.21, 0.23)):
    add("Discussion (limitations)", f"completed secondary HR, {c}: country definition", q1, hh(c, prim)); add("Discussion (limitations)", f"completed secondary HR, {c}: harmonized 10 years", q2, hh(c, h10))
if (S2 / "marriage_pooled.csv").exists():
    mc, mp = pd.read_csv(S2 / "marriage_by_country.csv"), pd.read_csv(S2 / "marriage_pooled.csv")
    def mh(c, term, sch="current"): return float(mc[(mc.country == c) & (mc.term == term) & (mc.schooling == sch)].HR.iloc[0])
    def mpool(term, field, sch="current"): return float(mp[(mp.term == term) & (mp.schooling == sch)][field].iloc[0])
    for c, q in (("Myanmar", 0.23), ("India", 0.23), ("Nepal", 0.26), ("Pakistan", 0.39), ("Bangladesh", 0.42), ("Afghanistan", 0.57)): add("Results (Marriage)", f"first-marriage HR, completed secondary, {c}", q, mh(c, LC))
    ev = [mh(c, E) for c in C]; add("Results (Marriage)", "first-marriage HR, primary: minimum 0.20", 0.20, min(ev)); add("Results (Marriage)", "first-marriage HR, primary: maximum 0.58", 0.58, max(ev))
    for term, k, q in ((E, "HR", 0.33), (E, "hksj_lo", 0.30), (E, "hksj_hi", 0.36), (LC, "HR", 0.24), (LC, "hksj_lo", 0.20), (LC, "hksj_hi", 0.29), (LC, "pi_lo", 0.18), (LC, "pi_hi", 0.33)):
        add("Abstract / Results (Marriage) / Table 5", f"pooled first-marriage HR (India, Nepal, Myanmar): {term} {k}", q, mpool(term, k))
    add("Results (Marriage)", "pooled first-marriage HR, lag 1, completed secondary 0.26", 0.26, mpool(LC, "HR", "lag1"))
    t5 = pd.read_csv(S2 / "table5_marriage.csv").set_index("country"); b = t5.births_before_marriage_pct.dropna()
    add("Results (Marriage)", "births before marriage: minimum 0.7", 0.7, b.min(), 1); add("Results (Marriage)", "births before marriage: maximum 3.8", 3.8, b.max(), 1)
    add("Table 5", "births before marriage, Bangladesh 0.9", 0.9, t5.loc["Bangladesh", "births_before_marriage_pct"], 1); add("Table 5", "births before marriage, India 1.9", 1.9, t5.loc["India", "births_before_marriage_pct"], 1)
    add("Results (Marriage)", "women dropped for missing age at first marriage, Bangladesh 3,383", 3383, t5.loc["Bangladesh", "dropped_missing_v511"], 0); add("Results (Marriage)", "women dropped for missing age at first marriage, India 4,047", 4047, t5.loc["India", "dropped_missing_v511"], 0)
if (S2 / "exposure_person_years.csv").exists():
    xp = pd.read_csv(S2 / "exposure_person_years.csv"); own = xp[xp.is_own].set_index("country")
    add("Discussion (limitations)", "Afghanistan completed-secondary share of person-years 2.3%", 2.3, own.loc["Afghanistan", "pct_of_late_py"], 1); add("Discussion (limitations)", "Afghanistan first births in that state 156", 156, own.loc["Afghanistan", "births_late_completed"], 0)
    add("Discussion (limitations)", "Myanmar completed-secondary share of person-years 7.1%", 7.1, own.loc["Myanmar", "pct_of_late_py"], 1); add("Discussion (limitations)", "Myanmar first births in that state 20", 20, own.loc["Myanmar", "births_late_completed"], 0)
    oth = own.drop(["Afghanistan", "Myanmar"]).pct_of_late_py; add("Discussion (limitations)", "other countries: minimum 10.5%", 10.5, oth.min(), 1); add("Discussion (limitations)", "other countries: maximum 28.5%", 28.5, oth.max(), 1)
out = pd.DataFrame(rows); out.to_csv(S2 / "prose_numbers_check.csv", index=False)
print(f"PROSE CHECK: {int((out.status == 'OK').sum())} of {len(out)} numbers in the manuscript text reproduced; CHECK={int((out.status == 'CHECK').sum())}")
if (out.status == "CHECK").any(): print(out[out.status == "CHECK"].to_string(index=False))
