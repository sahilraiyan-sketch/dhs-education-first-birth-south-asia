"""Maldives cohort builder (appended to cohorts.py by apply_maldives_patch.py).
The Maldives DHS surveys sampled ALL women aged 15-49 (not only ever-married women), like India, Nepal and Myanmar.
Individual-recode files: MVIR51FL (2009) and MVIR71FL (2016-17). File names are found by pattern (MV?IR??FL), so a different suffix is fine.
Cultural-group covariate: none (the country is almost entirely one religion and the recodes have no ethnicity variable), so Model A adjusts for region and residence only."""
import re, json, zipfile
from pathlib import Path
import numpy as np, pandas as pd, pyreadstat
from dhs_engine import find_dta, log

_MV = re.compile(r"^mv.?ir..fl$", re.I)

def _find_mv_stems(base):
    base = Path(base); skip = {"results", "figures", "_extracted"}; stems = {}
    for p in base.rglob("*"):
        if p.is_file() and not (skip & set(p.relative_to(base).parts)):
            if p.suffix.lower() == ".dta" and _MV.match(p.stem): stems[p.stem.upper()] = str(p)
            elif p.suffix.lower() == ".zip":
                try:
                    for m in zipfile.ZipFile(p).namelist():
                        pm = Path(m)
                        if pm.suffix.lower() == ".dta" and _MV.match(pm.stem): stems.setdefault(pm.stem.upper(), str(p))
                except Exception: pass
    return sorted(stems)

def _year(v007):
    v = pd.to_numeric(v007, errors="coerce").dropna()
    y = int(v.min()) if len(v) else 0
    return y + (1900 if y < 100 and y > 30 else 2000 if y < 100 else 0)

def _settings(base):
    f = Path(base) / "maldives_settings.json"
    return json.load(open(f)) if f.exists() else {}

def _region(label, rmap):
    s = re.sub(r"[^a-z ]", "", str(label).lower().replace("'", "")).strip()
    if s in rmap: return rmap[s]
    if "male" in s: return "male"
    return s or "unknown"

def build_maldives(base):
    stems = _find_mv_stems(base)
    if not stems: raise FileNotFoundError("No Maldives individual-recode file (MV?IR??FL.dta or a .zip containing it) found under " + str(base))
    log("Maldives files found: " + ", ".join(stems)); rmap = {k.lower(): v for k, v in _settings(base).get("region_map", {}).items()}
    WANT = ["v005","v007","v012","v021","v022","v024","v025","v133","v149","v151","v190","v201","v212","v501","v511"]
    parts, years = [], []
    for stem in stems:
        path = find_dta(base, [stem]); allcols = pyreadstat.read_dta(path, metadataonly=True)[1].column_names
        VAR = [v for v in WANT if v in allcols]; d, meta = pyreadstat.read_dta(path, usecols=VAR)
        d = d[(d["v012"] >= 20) & (d["v012"] <= 29)].copy()
        yr = _year(d["v007"]) if "v007" in d else 0; years.append((yr, int(pd.to_numeric(d["v007"], errors="coerce").max()) if "v007" in d else yr))
        for col in ["v212", "v511", "v133", "v201", "v501"]:
            d[col] = pd.to_numeric(d[col], errors="coerce") if col in d else np.nan
        d["survey_year"] = yr; d["ever_married"] = (d["v501"].fillna(0) != 0).astype(int); d["wt"] = d["v005"] / 1e6
        if "v022" not in d: d["v022"] = d["v024"].astype(str) + "_" + d["v025"].astype(str)
        d["psu_p"] = d["v021"].astype(str) + "_" + str(yr); d["strata_p"] = d["v022"].astype(str) + "_" + str(yr)
        lab = meta.variable_value_labels.get("v024", {}); d["division"] = d["v024"].map(lab).fillna(d["v024"]).map(lambda x: _region(x, rmap))
        d["residence"] = d["v025"].astype(int); d["wealth_index"] = d["v190"].astype(int)
        d["hhead_sex"] = pd.to_numeric(d["v151"], errors="coerce").fillna(1).astype(int) if "v151" in d else 1
        if "v149" not in d: d["v149"] = np.nan
        log(f"Maldives {stem}: year {yr}, {len(d):,} women aged 20-29, regions: {sorted(d['division'].unique())}")
        parts.append(d[["survey_year","wt","psu_p","strata_p","division","residence","wealth_index","hhead_sex","ever_married","v012","v133","v149","v201","v212","v511","v005"]])
    c = pd.concat(parts, ignore_index=True)
    waves = ", ".join(f"{y}-{str(m)[2:]}" if m > y else str(y) for y, m in sorted(years))
    return c, dict(frame="All women", waves=waves, ever_married_only_sample=False)
