from docx import Document
from docx.shared import Pt
rows=[
("Title and abstract","1","(a) Indicate the study's design with a commonly used term in the title or the abstract. (b) Provide in the abstract an informative and balanced summary of what was done and what was found.","Title (retrospective cohort analysis); Abstract (Background, Methods, Results, Conclusions)"),
("Introduction","2","Explain the scientific background and rationale for the investigation being reported.","Background"),
("","3","State specific objectives, including any prespecified hypotheses.","Background, final paragraph (four contributions)"),
("Methods","4","Present key elements of study design early in the paper.","Methods: Data and study population; Outcome and time-varying schooling"),
("","5","Describe the setting, locations, and relevant dates, including periods of recruitment, exposure, follow-up, and data collection.","Methods: Data and study population (countries and survey years); Outcome and time-varying schooling (ages 10 to 19)"),
("","6","(a) Give the eligibility criteria, and the sources and methods of selection of participants. Describe methods of follow-up. (b) For matched studies: not applicable.","Methods: Data and study population (women aged 20 to 29; ever-married or all women by country); (b) not applicable"),
("","7","Clearly define all outcomes, exposures, predictors, potential confounders, and effect modifiers. Give diagnostic criteria, if applicable.","Methods: Outcome and time-varying schooling; Statistical analysis (Models A and B, covariates, wealth interaction)"),
("","8","For each variable of interest, give sources of data and details of methods of assessment (measurement). Describe comparability of assessment methods if there is more than one group.","Methods: Data and study population; Outcome and time-varying schooling (country-specific definitions of completed secondary schooling; harmonized definition in sensitivity analysis)"),
("","9","Describe any efforts to address potential sources of bias.","Methods: Statistical analysis (time-varying exposure, lagged and final schooling, all-women analyses, E-values, survey weights, cluster-robust or bootstrap errors); Discussion: limitations"),
("","10","Explain how the study size was arrived at.","Results: Study population; Table 1 (all eligible women in the surveys; secondary analysis, no sample size calculation)"),
("","11","Explain how quantitative variables were handled in the analyses. If applicable, describe which groupings were chosen, and why.","Methods: Outcome and time-varying schooling (age-specific schooling categories and the years that define completion)"),
("","12","(a) Describe all statistical methods, including those used to control for confounding. (b) Describe any methods used to examine subgroups and interactions. (c) Explain how missing data were addressed. (d) If applicable, explain how loss to follow-up was addressed. (e) Describe any sensitivity analyses.","Methods: Statistical analysis (a, b, e); (c) women with missing age at first marriage excluded from the marriage models and women with missing schooling excluded from the analysis sample, Methods and Results: Marriage; (d) not applicable (retrospective survey data; women without a birth censored at age 20)"),
("Results","13","(a) Report numbers of individuals at each stage of the study. (b) Give reasons for non-participation at each stage. (c) Consider use of a flow diagram.","Results: Study population; Table 1; Additional file 1, Table S7 (exact counts); no flow diagram is provided"),
("","14","(a) Give characteristics of study participants and information on exposures and potential confounders. (b) Indicate number of participants with missing data for each variable of interest. (c) Summarise follow-up time.","Table 1; Additional file 1, Tables S7 and S19 (person-years); (b) missing age at first marriage reported in Results: Marriage"),
("","15","Report numbers of outcome events or summary measures over time.","Table 1 (first births before age 20 by country and wave); Additional file 1, Tables S7 and S19"),
("","16","(a) Give unadjusted estimates and, if applicable, confounder-adjusted estimates and their precision. (b) Report category boundaries when continuous variables were categorized. (c) If relevant, consider translating relative risk into absolute risk for a meaningful time period.","Tables 2 and 5 (adjusted hazard ratios with 95% CIs; Model B adds wealth); Methods: Outcome and time-varying schooling (categories); Table 3, Figure 1 and Additional file 1, Table S6 (absolute risks)"),
("","17","Report other analyses done, e.g. analyses of subgroups and interactions, and sensitivity analyses.","Results: Marriage, Stability across survey rounds, Sensitivity to adjustment and to unmeasured confounding; Additional file 1, Tables S1 to S19"),
("Discussion","18","Summarise key results with reference to study objectives.","Discussion, first paragraph"),
("","19","Discuss limitations of the study, taking into account sources of potential bias or imprecision. Discuss both direction and magnitude of any potential bias.","Discussion: limitations paragraph"),
("","20","Give a cautious overall interpretation of results considering objectives, limitations, multiplicity of analyses, results from similar studies, and other relevant evidence.","Discussion; Conclusions"),
("","21","Discuss the generalisability (external validity) of the study results.","Discussion: limitations paragraph (ever-married-only samples; six countries; survey waves)"),
("Other information","22","Give the source of funding and the role of the funders for the present study and, if applicable, for the original data on which the present article is based.","Declarations: Funding (no specific funding)"),
]
d=Document(); d.add_heading("STROBE Statement: checklist of items for cohort studies",1)
d.add_paragraph("Manuscript: Age-specific schooling and first birth before age 20 in six South Asian and adjacent countries: a retrospective cohort analysis of Demographic and Health Survey data. Locations are given as manuscript sections and tables; page numbers depend on the final layout. Checklist after von Elm et al., Lancet 2007;370:1453-1457.")
t=d.add_table(rows=1,cols=4); t.style="Table Grid"
for c,h in zip(t.rows[0].cells,["Section","Item","Recommendation","Where reported"]): c.text=h; c.paragraphs[0].runs[0].bold=True
for r in rows:
    cells=t.add_row().cells
    for c,v in zip(cells,r): c.text=v
for row in t.rows:
    for c in row.cells:
        for p in c.paragraphs:
            for run in p.runs: run.font.size=Pt(9)
import sys
d.save(sys.argv[1] if len(sys.argv) > 1 else "Additional_file_2_STROBE_checklist.docx")
