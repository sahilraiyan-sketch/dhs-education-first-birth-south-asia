#!/usr/bin/env python3
"""build_docx.py: main.tex (+ tables/, figures/, references.bib) -> manuscript.docx for BMC Public Health.

Usage:  python3 build_docx.py <latex_dir> <output.docx>

What it does
  * Floats are rewritten as "Table N. caption" / table / note and "figure / Figure N. caption / note" blocks, numbered in order of
    appearance (as LaTeX does), so captions can never land in table cells. \\ref{..} becomes the number.
  * Inline maths ($\\tau$, $I^2=0\\%$ ...) goes through pandoc and arrives as native Word equations (OMML).
  * \\cite{..} becomes numbered citations [1], [2,3], [4-6] in order of first citation; the reference list is formatted in Vancouver
    style from references.bib (no CSL file or network needed).
  * Word formatting: 12 pt Times New Roman, double spacing, continuous line numbers, page numbers.
Requires pandoc >= 3 and python-docx."""
import re, subprocess, sys, tempfile, shutil
from pathlib import Path
from docx import Document
from docx.shared import Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

SRC, OUT = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
tex = (SRC / "main.tex").read_text(encoding="utf-8")
body = tex[tex.index("\\begin{document}") + len("\\begin{document}"):tex.index("\\bibliographystyle")]

# ----------------------------------------------------------------- bibliography (Vancouver)
def parse_bib(text):
    entries, i = {}, 0
    for m in re.finditer(r"@(\w+)\s*\{\s*([^,\s]+)\s*,", text):
        depth, j = 1, m.end()
        while depth and j < len(text):
            depth += (text[j] == "{") - (text[j] == "}"); j += 1
        fields, k, chunk = {}, 0, text[m.end():j - 1]
        for fm in re.finditer(r"(\w+)\s*=\s*", chunk):
            if fm.start() < k: continue
            s = fm.end()
            if chunk[s] == "{":
                d, e = 1, s + 1
                while d: d += (chunk[e] == "{") - (chunk[e] == "}"); e += 1
                fields[fm.group(1).lower()] = chunk[s + 1:e - 1]; k = e
            else:
                e = re.compile(r"[,\s}]").search(chunk, s).start(); fields[fm.group(1).lower()] = chunk[s:e]; k = e
        entries[m.group(2)] = dict(fields, _type=m.group(1).lower())
    return entries

def clean(s):
    s = re.sub(r"\\&", "&", s); s = s.replace("--", "\u2013").replace("~", " ")
    s = re.sub(r"[{}]", "", s); return re.sub(r"\s+", " ", s).strip()

def authors(a):
    if not a: return ""
    if a.startswith("{") and a.endswith("}") and a.count("{") == 1: return clean(a)
    names = [n.strip() for n in re.split(r"\s+and\s+", a)]; out, more = [], False
    for n in names:
        if n.lower() in ("others", "et al"): more = True; continue
        if n.startswith("{"): out.append(clean(n)); continue
        sur, _, given = n.partition(","); ini = "".join(p[0] for p in re.split(r"[\s.\-]+", given.strip()) if p)
        out.append(f"{clean(sur)} {ini}".strip())
    if len(out) > 6: out = out[:6]; more = True
    return ", ".join(out) + (", et al" if more else "")

def fmt(e):
    t = e["_type"]; a = authors(e.get("author", "")); ti = clean(e.get("title", "")).rstrip(".")
    yr, doi, url = e.get("year", ""), clean(e.get("doi", "")), clean(e.get("url", ""))
    note = clean(e.get("note", "")); pages = clean(e.get("pages", ""))
    if t == "article":
        vol, num = clean(e.get("volume", "")), clean(e.get("number", ""))
        s = f"{a}. {ti}. {clean(e.get('journal', ''))}. {yr}"
        if vol: s += f";{vol}" + (f"({num})" if num else "")
        if pages: s += f":{pages}"
        s += "."
    elif t == "book":
        s = f"{a}. {ti}. {clean(e.get('address', ''))}: {clean(e.get('publisher', ''))}; {yr}."
    elif t == "techreport":
        s = f"{a}. {ti}. {clean(e.get('address', ''))}: {clean(e.get('institution', ''))}; {yr}." + (f" {clean(e['type'])}." if e.get("type") else "")
    elif t == "inproceedings":
        s = f"{a}. {ti}. In: {clean(e.get('booktitle', ''))}; {yr}." + (f" p. {pages}." if pages else "")
    else:   # misc, manual
        org = clean(e.get("organization", "") or e.get("howpublished", ""))
        s = f"{a}. {ti}. " + (f"{clean(e.get('address', ''))}: " if e.get("address") else "") + (f"{org}; " if org else "") + f"{yr}."
    s = s.replace("..", ".").replace(". .", ".").replace(": ;", ":")
    if doi: s += f" https://doi.org/{doi}"
    if url: s += f" {url}"
    if note: s += f" {note}."
    return re.sub(r"\s+", " ", s).replace("..", ".").strip()

bib = parse_bib((SRC / "references.bib").read_text(encoding="utf-8"))

# ----------------------------------------------------------------- citations: numbers in order of first citation
order = []
def cite_nums(m):
    nums = []
    for k in [x.strip() for x in m.group(1).split(",")]:
        if k not in bib: raise SystemExit(f"citation key not in references.bib: {k}")
        if k not in order: order.append(k)
        nums.append(order.index(k) + 1)
    nums = sorted(set(nums)); parts, i = [], 0
    while i < len(nums):
        j = i
        while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1: j += 1
        parts.append(str(nums[i]) if j == i else (f"{nums[i]},{nums[j]}" if j == i + 1 else f"{nums[i]}\u2013{nums[j]}")); i = j + 1
    return "[" + ",".join(parts) + "]"
body = re.sub(r"\s*\\cite\{([^}]*)\}", lambda m: " " + cite_nums(m), body)

# ----------------------------------------------------------------- floats -> numbered blocks
counters, labels = {"table": 0, "figure": 0}, {}
def float_block(m):
    kind, inner = m.group(1), m.group(2)
    counters[kind] += 1; n = counters[kind]
    cap = re.search(r"\\caption\{((?:[^{}]|\{[^{}]*\})*)\}", inner).group(1)
    lab = re.search(r"\\label\{([^}]*)\}", inner)
    if lab: labels[lab.group(1)] = n
    note = re.sub(r"^.*?\\label\{[^}]*\}", "", inner, flags=re.S) if lab else re.sub(r"^.*?\\caption\{(?:[^{}]|\{[^{}]*\})*\}", "", inner, flags=re.S)
    note = re.sub(r"\\par|\\vspace\{[^}]*\}|\\raggedright|\\footnotesize|\\noindent|\\centering", " ", note)
    note = re.sub(r"\\small\s*", "", note).strip()
    if note.startswith("{") and note.endswith("}"): note = note[1:-1]
    head = f"\n\n\\noindent\\textbf{{{kind.capitalize()} {n}.}} {cap}\n\n"
    if kind == "table":
        tb = re.search(r"\\input\{([^}]*)\}", inner).group(1)
        grid = (SRC / (tb if tb.endswith(".tex") else tb + ".tex")).read_text(encoding="utf-8")
        grid = re.sub(r"\\cmidrule(\([lr]+\))?\{[^}]*\}", "", grid)
        block = head + grid + "\n\n"
    else:
        img = re.search(r"\\includegraphics\[[^\]]*\]\{([^}]*)\}", inner).group(1)
        block = f"\n\n\\includegraphics{{{img}}}\n" + head
    return block + (f"\\noindent {note}\n\n" if note else "")
body = re.sub(r"\\begin\{(table|figure)\}(?:\[[^\]]*\])?(.*?)\\end\{\1\}", float_block, body, flags=re.S)
body = re.sub(r"(Table|Figure|Fig\.)~?\\ref\{([^}]*)\}", lambda m: f"{m.group(1)}~{labels[m.group(2)]}", body)
if "\\ref{" in body: raise SystemExit("unresolved \\ref left in body")

# ----------------------------------------------------------------- title block and clean-up
body = re.sub(r"\\begin\{flushleft\}\s*\{\\Large\\bfseries (.*?)\}\\\\\[[^\]]*\]", r"\\begin{center}\\textbf{\1}\\\\[0.5em]", body, flags=re.S)
body = body.replace("\\end{flushleft}", "\\end{center}")
body = re.sub(r"\\FloatBarrier|\\linenumbers|\\clearpage", "", body)
body = re.sub(r"\\todo\{([^}]*)\}", r"\\textbf{[\1]}", body)

refs = "\n\n".join(f"[{i + 1}] {fmt(bib[k])}".replace("&", "\\&").replace("%", "\\%").replace("#", "\\#").replace("_", "\\_").replace("$", "\\$") for i, k in enumerate(order))
doc = ("\\documentclass{article}\\usepackage{graphicx}\\usepackage{url}\\begin{document}\n" + body +
       "\n\\section*{References}\n\\begin{refs}\n" + refs + "\n\\end{refs}\n\\end{document}\n")
doc = doc.replace("\\begin{refs}", "").replace("\\end{refs}", "")

tmp = Path(tempfile.mkdtemp()); (tmp / "m.tex").write_text(doc, encoding="utf-8")
for d in ("figures", "tables"):
    if (SRC / d).exists(): shutil.copytree(SRC / d, tmp / d)
subprocess.run(["pandoc", "m.tex", "-f", "latex", "-t", "docx", "-o", str(OUT), "--resource-path", str(tmp)], cwd=tmp, check=True)

# ----------------------------------------------------------------- Word formatting: font, double spacing, line numbers, page numbers
d = Document(str(OUT))
for st in d.styles:
    try:
        if st.font is not None and st.type in (1, 2): st.font.name = "Times New Roman"; st.font.size = Pt(12) if st.name not in ("Heading 1", "Heading 2", "Heading 3") else st.font.size
    except Exception: pass
for p in d.paragraphs:
    p.paragraph_format.line_spacing = 2.0
for t in d.tables:
    t.style = d.styles["Table Grid"] if "Table Grid" in [s.name for s in d.styles] else t.style
    for row in t.rows:
        for c in row.cells:
            for p in c.paragraphs: p.paragraph_format.line_spacing = 1.0; [setattr(r.font, "size", Pt(9)) for r in p.runs]
sect = d.sections[0]; sp = sect._sectPr
ln = OxmlElement("w:lnNumType"); ln.set(qn("w:countBy"), "1"); ln.set(qn("w:restart"), "continuous"); sp.append(ln)
fp = sect.footer.paragraphs[0]
for typ, txt in (("begin", None), (None, "PAGE"), ("end", None)):
    r = fp.add_run()
    if typ: e = OxmlElement("w:fldChar"); e.set(qn("w:fldCharType"), typ)
    else: e = OxmlElement("w:instrText"); e.set(qn("xml:space"), "preserve"); e.text = txt
    r._r.append(e)
fp._p.get_or_add_pPr().append(OxmlElement("w:suppressLineNumbers"))
fp.alignment = 1
d.save(str(OUT))
print(f"wrote {OUT}: {counters['table']} tables, {counters['figure']} figures, {len(order)} references")
