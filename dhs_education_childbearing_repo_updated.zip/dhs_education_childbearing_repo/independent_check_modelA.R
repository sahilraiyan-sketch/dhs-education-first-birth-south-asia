# independent_check_modelA.R
# A second, separately written implementation of Model A (R only, no Python code is used) for Myanmar and Nepal.
# It rebuilds the analysis from the raw DHS files and compares the education hazard ratios with results/<Country>/stage1_final.csv.
#
# HOW TO RUN (RStudio): set the working directory to your analysis folder (the one with results/ and the raw DHS data), then
#   source("independent_check_modelA.R")
# Needs the R packages haven and sandwich (installed automatically if missing). Takes about 1-2 minutes.
#
# The logic below is deliberately written from the definitions in the manuscript, not copied from the Python code:
#   sample   : women aged 20-29, ever married, years of schooling known
#   outcome  : first birth before age 20 (births reported before age 10 are set to age 10)
#   records  : one row per year of age from 10 up to the birth age (or 19)
#   exposure : schooling attained at age a = min(final years, max(0, a - 6)); early epoch (age < 15): primary completed;
#              late epoch (age >= 15): incomplete secondary (more than primary, less than SEC years) and secondary completed (>= SEC years)
#   model    : weighted complementary log-log regression, baseline by age band (10-12 pooled) x survey wave,
#              region, urban/rural and one cultural-group variable; weights = v005 / 1e6
for (p in c("haven", "sandwich")) if (!requireNamespace(p, quietly = TRUE)) install.packages(p, repos = "https://cloud.r-project.org")
suppressMessages({library(haven); library(sandwich)})

find_dta <- function(stem) {                      # looks for the .dta, or unzips it from a .zip in the working folder
  f <- list.files(".", pattern = paste0("^", stem, "\\.dta$"), recursive = TRUE, ignore.case = TRUE, full.names = TRUE)
  f <- f[!grepl("^\\./(results|_extracted)", f)]
  if (length(f)) return(f[1])
  for (z in list.files(".", pattern = "\\.zip$", recursive = TRUE, full.names = TRUE, ignore.case = TRUE)) {
    m <- grep(paste0(stem, "\\.dta$"), unzip(z, list = TRUE)$Name, ignore.case = TRUE, value = TRUE)
    if (length(m)) { dir.create("_extracted_R", showWarnings = FALSE); unzip(z, files = m[1], exdir = "_extracted_R", junkpaths = TRUE); return(list.files("_extracted_R", pattern = paste0(stem, "\\.dta$"), ignore.case = TRUE, full.names = TRUE)[1]) }
  }
  stop("cannot find ", stem, ".dta (or a zip containing it) in the working folder")
}
lab <- function(x) as.character(as_factor(x))     # value labels -> text

person_period <- function(d, sec, prim = 5) {
  d$ev <- ifelse(d$v201 > 0 & d$v212 < 20, pmax(d$v212, 10), NA)
  last <- ifelse(is.na(d$ev), 19, pmin(d$ev, 19))
  idx <- rep(seq_len(nrow(d)), times = last - 10 + 1); pp <- d[idx, ]
  pp$age <- unlist(lapply(last, function(l) 10:l))
  pp$y <- as.integer(!is.na(pp$ev) & pp$age == pp$ev)
  pp$att <- pmin(pp$v133, pmax(0, pp$age - 6))
  pp$e_early <- as.integer(pp$age < 15 & pp$att >= prim)
  pp$e_inc   <- as.integer(pp$age >= 15 & pp$att > prim & pp$att < sec)
  pp$e_comp  <- as.integer(pp$age >= 15 & pp$att >= sec)
  pp$band <- paste(pmax(pp$age, 12), pp$wave, sep = "_")
  pp
}
fit_modelA <- function(pp) {
  f <- glm(y ~ 0 + factor(band) + factor(region) + factor(urban) + factor(group) + e_early + e_inc + e_comp,
           family = binomial(link = "cloglog"), weights = wt, data = pp)
  vc <- sandwich::vcovCL(f, cluster = pp$psu, type = "HC0")
  b <- coef(f)[c("e_early", "e_inc", "e_comp")]; se <- sqrt(diag(vc))[c("e_early", "e_inc", "e_comp")]
  data.frame(term = c("early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv"), HR_R = exp(b), lo = exp(b - 1.96 * se), hi = exp(b + 1.96 * se), row.names = NULL)
}
read_wave <- function(stem, wave, vars) {
  x <- read_dta(find_dta(stem), col_select = any_of(vars))
  x <- x[x$v012 >= 20 & x$v012 <= 29 & x$v501 != 0, ]
  x$v133 <- as.numeric(x$v133); x <- x[!is.na(x$v133) & x$v133 < 90, ]
  x$v201 <- as.numeric(x$v201); x$v212 <- as.numeric(x$v212)
  x$wave <- wave; x$wt <- as.numeric(x$v005) / 1e6; x$psu <- paste(wave, as.numeric(x$v021)); x$urban <- as.numeric(x$v025); x
}
compare <- function(country, res, n_women, events) {
  ref <- read.csv(file.path("results", country, "stage1_final.csv")); ref <- ref[ref$model == "A", c("term", "HR", "lo_pct", "hi_pct", "n_women", "events")]
  m <- merge(res, ref, by = "term"); m$diff <- m$HR_R - m$HR
  cat("\n====", country, "====\n")
  cat(sprintf("women: R %d vs Python %d | first births before 20: R %d vs Python %d | %s\n", n_women, ref$n_women[1], events, ref$events[1], ifelse(n_women == ref$n_women[1] && events == ref$events[1], "sample sizes match exactly", "SAMPLE SIZES DIFFER")))
  print(data.frame(term = m$term, HR_R = round(m$HR_R, 4), HR_python = round(m$HR, 4), diff = signif(m$diff, 2), CI_R = sprintf("%.3f-%.3f", m$lo, m$hi), CI_boot = sprintf("%.3f-%.3f", m$lo_pct, m$hi_pct)), row.names = FALSE)
  cat(ifelse(all(abs(m$diff) < 0.002), "PASS: hazard ratios agree with the Python results (|difference| < 0.002)\n", "CHECK: hazard ratios differ by 0.002 or more; investigate\n"))
}

# ---------------- Myanmar (one survey; secondary completed = 11 years) ----------------
mm <- read_wave("MMIR71FL", 2015, c("v005", "v012", "v021", "v024", "v025", "v133", "v201", "v212", "v501", "v045c"))
mm$region <- lab(mm$v024); mm$group <- ifelse(lab(mm$v045c) == "myanmar", "myanmar", "other"); 
pp <- person_period(mm, sec = 11)
compare("Myanmar", fit_modelA(pp), nrow(mm), sum(mm$v201 > 0 & mm$v212 < 20))

# ---------------- Nepal (three surveys; secondary completed = 10 years; 2011 districts mapped to provinces through the 2016 survey) ----------------
vn <- c("v005", "v012", "v021", "v024", "v025", "v133", "v201", "v212", "v501", "v131", "sdist")
n16 <- read_wave("NPIR7HFL", 2016, vn); n11 <- read_wave("NPIR61FL", 2011, vn); n22 <- read_wave("NPIR82FL", 2022, vn)
xw <- read_dta(find_dta("NPIR7HFL"), col_select = c("sdist", "v024")); xw$prov <- lab(xw$v024)
xwalk <- tapply(xw$prov, xw$sdist, function(p) names(sort(table(p), decreasing = TRUE))[1])
n16$region <- lab(n16$v024); n22$region <- lab(n22$v024); n11$region <- xwalk[as.character(n11$sdist)]
nm <- c("province 1" = "koshi", "province 2" = "madhesh province", "province 3" = "bagmati province", "province 4" = "gandaki province", "province 5" = "lumbini province", "province 6" = "karnali province", "province 7" = "sudurpashchim province")
rn <- function(x) { x <- tolower(trimws(x)); ifelse(x %in% names(nm), nm[x], x) }
slim <- function(x) data.frame(v133 = as.numeric(x$v133), v201 = as.numeric(x$v201), v212 = as.numeric(x$v212), wave = x$wave, wt = x$wt, psu = x$psu,
                               urban = x$urban, region = rn(as.character(x$region)), group = lab(x$v131), stringsAsFactors = FALSE)
np <- rbind(slim(n11), slim(n16), slim(n22))
pp <- person_period(np, sec = 10)
compare("Nepal", fit_modelA(pp), nrow(np), sum(np$v201 > 0 & np$v212 < 20))
cat("\nIf both countries say PASS, an independently written Model A reproduces the hazard ratios. Extend it to the other countries the same way (see INDEPENDENT_RERUN_PROTOCOL.md).\n")
