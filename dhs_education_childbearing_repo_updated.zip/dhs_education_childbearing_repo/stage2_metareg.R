# Exploratory meta-regression: log HR on one country-level moderator at a time (k = 6 or 7). Reads results/stage2/*.csv
if (!requireNamespace("metafor", quietly = TRUE)) install.packages("metafor", repos = "https://cloud.r-project.org")
suppressMessages(library(metafor))
s <- read.csv("results/stage2/stage1_all_primary.csv"); m <- read.csv("results/stage2/moderators.csv"); s <- s[s$model == "A", ]
mods <- c("legal_marriage_age", "log_gdp_pc", "pct_married_before_18", "median_age_first_marriage"); out <- NULL
for (term in c("early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv")) {
  d <- merge(s[s$term == term, c("country", "logHR", "se_boot")], m, by = "country")
  if (term == "early_prim_comp_tv") d <- d[d$country != "Maldives", ]   # ages 10-14 contrast not estimable in the Maldives
  base <- rma(yi = d$logHR, sei = d$se_boot, method = "REML", test = "knha")
  for (mv in mods) {
    ok <- !is.na(d[[mv]]); dd <- d[ok, ]   # moderators missing for a country (e.g. GDP per capita for the Maldives) drop that country
    x <- dd[[mv]]; x <- (x - mean(x)) / sd(x)
    f <- rma(yi = dd$logHR, sei = dd$se_boot, mods = ~ x, method = "REML", test = "knha")
    out <- rbind(out, data.frame(term = term, moderator = mv, k = nrow(dd), ratio_HR_per_SD = exp(f$beta[2]), lo = exp(f$ci.lb[2]), hi = exp(f$ci.ub[2]),
                                 p = f$pval[2], tau2_base = base$tau2, tau2_resid = f$tau2))
  }
}
write.csv(out, "results/stage2/meta_regression.csv", row.names = FALSE); print(format(out, digits = 3), row.names = FALSE)
