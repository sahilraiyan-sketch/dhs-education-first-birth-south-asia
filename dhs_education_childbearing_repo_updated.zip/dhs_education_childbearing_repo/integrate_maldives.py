"""Seven-country integration. Usage (from the repo folder, after apply_maldives_patch.py and after run_maldives.py, allwomen_analysis/aw_bootstrap.py,
allwomen_analysis/aw_extras.py, extras2.py and aw_harmonized10.py have been run for Maldives):
    python integrate_maldives.py [--seed-from-reference] [--skip-qba]
--seed-from-reference : copy reference_results/<Country>/ into results/<Country>/ for the six existing countries (use when their microdata runs are not on this machine).
Steps: (1) Stage 2 pooling over seven countries (run_stage2.py --skip-r); (2) Maldives rows added to exposure_person_years.csv; (3) marriage pooling;
(4) stage-2 files copied to reference_results/ (read by bias_analysis/); (5) primary-sample pooling; (6) bias analysis grid for Maldives, pooled scenarios, probabilistic analysis."""
import os, sys, shutil, subprocess, argparse
from pathlib import Path
import pandas as pd
ap = argparse.ArgumentParser(); ap.add_argument("--seed-from-reference", action="store_true"); ap.add_argument("--skip-qba", action="store_true"); a = ap.parse_args()
BASE = Path.cwd(); py = sys.executable; REF = BASE / "reference_results"; RES = BASE / "results"; SIX = ["Bangladesh", "India", "Nepal", "Pakistan", "Afghanistan", "Myanmar"]
def run(args, cwd=BASE):
    print("\n$", " ".join(str(x) for x in args), flush=True); r = subprocess.run([py] + [str(x) for x in args], cwd=str(cwd))
    if r.returncode != 0: sys.exit(f"step failed: {args}")
if a.seed_from_reference:
    for c in SIX:
        if not (RES / c).exists(): shutil.copytree(REF / c, RES / c); print("seeded results/" + c)
(RES / "stage2").mkdir(parents=True, exist_ok=True)
old_exp = pd.read_csv(REF / "stage2" / "exposure_person_years.csv") if (REF / "stage2" / "exposure_person_years.csv").exists() else None
run(["run_stage2.py", "--skip-r"])
if (RES / "stage2" / "exposure_person_years.csv").exists(): shutil.copy(RES / "stage2" / "exposure_person_years.csv", RES / "stage2" / "exposure_person_years_before.csv")
run(["exposure_person_years.py"])
new = pd.read_csv(RES / "stage2" / "exposure_person_years.csv"); mv = new[new.country == "Maldives"]
if old_exp is not None: pd.concat([old_exp[old_exp.country != "Maldives"], mv], ignore_index=True).to_csv(RES / "stage2" / "exposure_person_years.csv", index=False)
run(["pool_marriage.py"])
for f in (RES / "stage2").glob("*"):
    if f.is_file() and not f.name.endswith("_before.csv"): shutil.copy(f, REF / "stage2" / f.name)
(REF / "Maldives").mkdir(exist_ok=True)
for f in (RES / "Maldives").glob("*.csv"): shutil.copy(f, REF / "Maldives" / f.name)
run(["primary_allwomen.py"], cwd=BASE / "bias_analysis")
if not a.skip_qba:
    BA = BASE / "bias_analysis"
    run(["run_qba_grid2.py", "0,0.25,0.5,0.75,1", "0,0.5,1,1.5,2,2.5,3", "0,0.25,0.5,0.75,1", "qba_grid_m.csv"], cwd=BA)
    run(["qba_pool2.py"], cwd=BA); run(["qba_prob2.py"], cwd=BA)
print("\nIntegration finished. Next: python make_seven_country_outputs.py")
