"""extras2.py : second set of checks for one country.
Usage: python extras2.py Nepal 5 10
(1) lag-1 exposure, (2) first-marriage hazard by schooling, (3) share of first births before 20 outside marriage,
(4) wave-specific hazard ratios, (5) wealth benchmark risk ratios.  Writes results/<country>/extras2.csv

Revision (Oct 2026): ever-married women whose age at first marriage (v511) is missing are now DROPPED from (2) and (3).
Before, a missing v511 was read as "never married" in (2) and as "birth before marriage" in (3). This mattered only for
Bangladesh (BDHS 2022: all marriage variables are missing for about a third of ever-married women) and India (NFHS-4 2016: 2.2%).
In the all-women countries (India, Nepal, Myanmar) a missing v511 is still read as never married when v501/ever_married says so."""
import sys, os, gc
sys.path.insert(0, os.getcwd())
try: sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
except NameError: pass
import numpy as np, pandas as pd, scipy.sparse as sp
from scipy.stats import norm, chi2
import dhs_engine as E
country, prim, sec = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]); E.set_thresholds(prim, sec)
raw = pd.read_parquet(f"results/{country}/cohort.parquet")
allwomen = ("ever_married" in raw.columns) and raw["ever_married"].nunique() > 1
out = []

def fit_cov(X, names, y, w, groups):
    beta = E._irls(X, y, w, E.start_vec(names))
    e = np.exp(np.clip(X @ beta, -30, 5)); p = np.clip(-np.expm1(-e), 1e-300, 1 - 1e-12); dp = e * np.exp(-e)
    sc = np.where(y == 1, dp / p, -e); iw = w * dp**2 / (p * (1 - p)); k = X.shape[1]
    bread = np.linalg.inv(E._gram(X, iw) + 1e-10 * np.eye(k)); ws = w * sc
    gid, _ = pd.factorize(groups); G = gid.max() + 1; Ug = np.zeros((G, k)); chunk = 400_000
    for r0 in range(0, X.shape[0], chunk):
        Xc = X[r0:r0 + chunk]; m = Xc.shape[0]
        Gm = sp.csr_matrix((np.ones(m), (gid[r0:r0 + m], np.arange(m))), shape=(G, m)); Ug += (Gm @ Xc.multiply(ws[r0:r0 + m][:, None]).tocsr()).toarray()
    return pd.Series(beta, names), bread @ (Ug.T @ Ug * (G / (G - 1))) @ bread

def run(label, P, expo, report, level="A", outcome="birth"):
    X, nm = E.design(P, level, expo, None, None); b, V = fit_cov(X, nm, P["y"], P["wt"], P["psu_p"]); se = pd.Series(np.sqrt(np.diag(V)), nm)
    for t in report:
        out.append(dict(country=country, analysis=label, outcome=outcome, term=t, HR=np.exp(b[t]), lo=np.exp(b[t] - 1.96 * se[t]), hi=np.exp(b[t] + 1.96 * se[t]),
                        p=2 * (1 - norm.cdf(abs(b[t] / se[t]))), events=int(P["y"].sum()), n_rows=len(P["y"]), logHR=b[t], se=se[t]))
    E.log(f"{label} [{outcome}] done"); gc.collect(); return b, V, nm

def tv(P, att):
    Q = dict(P); Q["attained"] = att; return E.tv_expo(Q, True)

# ---- (1) lag-1 exposure and (4) wave-specific HRs, outcome = first birth, ever-married sample (primary analysis)
c = E.prepare(raw, True); P = E.expand(c, 6); terms = list(tv(P, P["attained"]))
run("current (age a)", P, tv(P, P["attained"]), terms)
run("lag 1 year (schooling reached at age a-1)", P, tv(P, np.minimum(P["final"], np.maximum(0, P["a"] - 1 - 6))), terms)
# how many person-years are exposed under each definition (late completed secondary)?
L = 1 - P["early"]; cur_ex = ((P["attained"] >= sec) * L).sum(); lag_ex = ((np.minimum(P["final"], np.maximum(0, P["a"] - 7)) >= sec) * L).sum()
out.append(dict(country=country, analysis="exposed person-years, late completed secondary", term="current/lag1", HR=cur_ex, lo=lag_ex, hi=np.nan, p=np.nan))
waves = sorted(np.unique(P["survey_year"]).tolist())
if len(waves) > 1:
    cur = tv(P, P["attained"]); ex = {}
    for t in terms:
        for w_ in waves: ex[f"{t}__w{w_}"] = cur[t] * (np.asarray(P["survey_year"]) == w_)
    b, V, nm = run("wave-specific", P, ex, list(ex))
    for t in terms:
        cols = [f"{t}__w{w_}" for w_ in waves]; idx = [nm.index(x) for x in cols]
        d = np.array([b[cols[i]] - b[cols[0]] for i in range(1, len(cols))])
        if len(cols) >= 2:
            D = np.zeros((len(cols) - 1, len(nm)))
            for i in range(1, len(cols)): D[i - 1, idx[i]] = 1; D[i - 1, idx[0]] = -1
            W = float(d @ np.linalg.solve(D @ V @ D.T, d)); out.append(dict(country=country, analysis="wave heterogeneity Wald test", term=t, HR=W, lo=len(d), hi=np.nan, p=1 - chi2.cdf(W, len(d))))
del P; gc.collect()

# ---- (2) first-marriage hazard by time-varying schooling
# Drop ever-married women with missing age at first marriage (v511); never-married women (all-women countries) stay in as censored.
ever = (raw["ever_married"] == 1) if "ever_married" in raw.columns else pd.Series(True, index=raw.index)
miss = ever & raw["v511"].isna(); n_dropped = int(miss.sum()); rm = raw[~miss].copy()
out.append(dict(country=country, analysis="ever-married women dropped: missing age at first marriage (v511)", term="n", HR=n_dropped, lo=int(ever.sum())))
r2 = rm.copy(); r2["v212"] = r2["v511"]; r2["v201"] = np.where(r2["v511"].notna(), 1, 0)
c2 = E.prepare(r2, not allwomen); P2 = E.expand(c2, 6)
tag = "all women" if allwomen else "ever-married women only"
run(f"first-marriage hazard, current schooling ({tag})", P2, tv(P2, P2["attained"]), terms, outcome="marriage")
run(f"first-marriage hazard, lag 1 ({tag})", P2, tv(P2, np.minimum(P2["final"], np.maximum(0, P2["a"] - 7))), terms, outcome="marriage")
del P2, c2, r2; gc.collect()

# ---- (3) first births before 20 outside marriage (women with missing v511 excluded), and (5) wealth benchmark RRs
a = rm.copy()
for k in ("v212", "v133", "v511", "v201"): a[k] = pd.to_numeric(a[k], errors="coerce")
a = a[a["v133"] < 90]; fb = a[(a["v201"] > 0) & (a["v212"] < 20)].copy()
fb["pre"] = np.where(fb["v511"].isna(), 1, (fb["v511"] > fb["v212"]).astype(int))      # remaining missing v511 = never married
out.append(dict(country=country, analysis="share of first births before 20 before marriage (weighted %)", term=tag, HR=100 * np.average(fb["pre"], weights=fb["wt"]), lo=len(fb)))
for y_, g in fb.groupby("survey_year"):
    out.append(dict(country=country, analysis="share of first births before 20 before marriage (weighted %), by wave", term=str(y_), HR=100 * np.average(g["pre"], weights=g["wt"]), lo=len(g)))
em = E.prepare(raw, True); w = em["wt"].values
poor = em["wealth_index"].astype(int).isin([1, 2]).values; birth = em["ev_age"].notna().values; comp = (em["v133"] >= sec).values
rr1 = np.average(birth[poor], weights=w[poor]) / np.average(birth[~poor], weights=w[~poor])
rr2 = np.average(comp[~poor], weights=w[~poor]) / max(np.average(comp[poor], weights=w[poor]), 1e-9)
out.append(dict(country=country, analysis="wealth benchmark: RR first birth before 20, poorest 2 vs richer 3 quintiles", term="RR", HR=rr1))
out.append(dict(country=country, analysis="wealth benchmark: RR completing secondary, richer 3 vs poorest 2 quintiles", term="RR", HR=rr2))
pd.DataFrame(out).to_csv(f"results/{country}/extras2.csv", index=False); E.log(f"{country}: extras2.csv written")
