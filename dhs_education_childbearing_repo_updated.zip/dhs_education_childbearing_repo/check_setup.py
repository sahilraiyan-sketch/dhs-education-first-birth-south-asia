"""Checks Python packages, R, and the presence of every raw DHS file in the working directory."""
import os, sys, shutil, importlib
sys.path.insert(0, os.getcwd())
print("Python:", sys.version.split()[0])
bad = False
for m in ("numpy", "pandas", "scipy", "pyarrow", "pyreadstat", "matplotlib"):
    try: mod = importlib.import_module(m); print(f"  {m:11s} OK ({getattr(mod, '__version__', '?')})")
    except Exception as e: print(f"  {m:11s} MISSING  -> pip install {m}"); bad = True
print("R (needed only for the three R steps of Stage 2):", shutil.which("Rscript") or "Rscript not found on PATH (you can still run those .R files from RStudio)")
import dhs_engine as E
need = {"Bangladesh": [["BDHS2014", "BDIR72FL"], ["BDHS2018", "BDIR7RFL", "BDHS2017"], ["BDHS2022", "BDIR81FL"]],
        "India": [["IAIR52FL"], ["IAIR74FL"], ["IAIR7EFL"]], "Nepal": [["NPIR61FL"], ["NPIR7HFL"], ["NPIR82FL"]],
        "Pakistan": [["PKIR53FL"], ["PKIR61FL"], ["PKIR71FL"]], "Afghanistan": [["AFIR71FL"]], "Myanmar": [["MMIR71FL"]]}
base = E.base_dir(); print("\nWorking directory:", base)
for c, files in need.items():
    for names in files:
        try: p = E.find_dta(str(base), names, extract=False); print(f"  {c:12s} {names[0]:10s} found: {os.path.relpath(p, base) if os.path.exists(p) else p}")
        except FileNotFoundError: print(f"  {c:12s} {names[0]:10s} MISSING (put the .dta or its .zip in the working directory)"); bad = True
print("\nAll set." if not bad else "\nFix the items marked MISSING, then run the scripts.")
