"""TEST ONLY: writes two synthetic Maldives-like DHS individual-recode files (MVIR51FL.DTA, MVIR71FL.DTA) to a folder, to test the code. Not real data.
Usage: python make_synthetic_maldives.py <out_dir> [women_per_survey]"""
import sys, numpy as np, pandas as pd, pyreadstat
from pathlib import Path
out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True); N = int(sys.argv[2]) if len(sys.argv) > 2 else 9000; rng = np.random.default_rng(7)
REG = {2009: {1: "Male'", 2: "North", 3: "Central", 4: "South"}, 2016: {1: "Male", 2: "North", 3: "North Central", 4: "Central", 5: "South Central", 6: "South"}}
for stem, yr in (("MVIR51FL", 2009), ("MVIR71FL", 2016)):
    age = rng.integers(15, 50, N); reg = rng.integers(1, len(REG[yr]) + 1, N); res = np.where(reg == 1, 1, rng.choice([1, 2], N, p=[.3, .7]))
    S = np.clip(np.round(rng.normal(9.5 if yr == 2016 else 8, 3.2, N)), 0, 16).astype(int); wealth = rng.integers(1, 6, N)
    married = rng.random(N) < np.clip((age - 17) / 12, .05, .85); mar_age = np.clip(age - rng.integers(0, 12, N), 14, 30)
    bage = np.full(N, np.nan); 
    for i in range(N):
        if not married[i]: continue
        for a in range(max(14, mar_age[i]), min(age[i], 40) + 1):
            att = min(S[i], max(0, a - 6)); e = -1.6 + 0.35 * (a - 14) - (1.1 if (a < 15 and att >= 7) else 0) - (1.3 if (a >= 15 and att >= 12) else 0) - (.5 if (a >= 15 and 7 < att < 12) else 0)
            if rng.random() < 1 - np.exp(-np.exp(e) * 0.5): bage[i] = a; break
    d = pd.DataFrame(dict(caseid=[f"{yr} {i}" for i in range(N)], v005=rng.integers(400000, 2500000, N), v007=yr + (rng.random(N) < (.4 if yr == 2016 else 0)).astype(int),
                          v012=age, v021=rng.integers(1, 250, N), v022=reg * 10 + res, v024=reg, v025=res, v133=S, v151=rng.choice([1, 2], N, p=[.6, .4]), v190=wealth,
                          v201=np.where(np.isnan(bage), 0, 1), v212=bage, v501=np.where(married, 1, 0), v511=np.where(married, mar_age, np.nan)))
    d["v149"] = np.select([d.v133 == 0, d.v133 < 7, d.v133 == 7, d.v133 < 12, d.v133 == 12], [0, 1, 2, 3, 4], 5)
    pyreadstat.write_dta(d, str(out / f"{stem}.DTA"), variable_value_labels={"v024": REG[yr], "v025": {1: "urban", 2: "rural"}, "v149": {0: "no education", 1: "incomplete primary", 2: "complete primary", 3: "incomplete secondary", 4: "complete secondary", 5: "higher"}})
    print(stem, "written", len(d))
