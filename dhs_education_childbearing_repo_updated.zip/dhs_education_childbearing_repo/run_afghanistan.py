"""Afghanistan: cohort, Stage-1 models, bootstrap, absolute risks, tables and figures.
Usage: python run_afghanistan.py [--quick] [--B N] [--skip-specs] [--skip-sensitivity] [--rebuild] [--low-memory]
Reads raw DHS files from the working directory. Writes results/Afghanistan/ and figures/Afghanistan/."""
import os, sys
sys.path.insert(0, os.getcwd())
try: sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
except NameError: pass
import dhs_engine as E

CONFIG = dict(
    name="Afghanistan",
    builder="build_afghanistan",
    prim=6,                  # years defining primary completed
    sec=12,                    # years defining secondary completed (DHS definition)
    sec_alt=10,            # years for the harmonized sensitivity run (None: not run)
    B=1000,                        # bootstrap replicates, primary run
    B_alt=1000,                # bootstrap replicates, sensitivity run
    all_women=False,        # all-women sensitivity analysis
    low_memory=False,      # one specification per process
)
E.main(CONFIG)
