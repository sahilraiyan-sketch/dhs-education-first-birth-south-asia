"""Runs extras2.py for all six countries, then pools the first-marriage hazard ratios and tabulates exposure person-years.
Usage: python run_extras.py [Country ...]      (needs results/<Country>/cohort.parquet from the run_<country>.py scripts)"""
import os, sys, subprocess
from pathlib import Path
BASE = Path(__file__).resolve().parent
SETTINGS = {"Bangladesh": (5, 10), "India": (5, 12), "Nepal": (5, 10), "Pakistan": (5, 10), "Afghanistan": (6, 12), "Myanmar": (5, 11)}   # primary, secondary years
todo = sys.argv[1:] or list(SETTINGS)
py = sys.executable
for c in todo:
    p, s = SETTINGS[c]; print(f"== {c}", flush=True)
    subprocess.run([py, str(BASE / "extras2.py"), c, str(p), str(s)], cwd=os.getcwd(), check=True)
subprocess.run([py, str(BASE / "pool_marriage.py")], cwd=os.getcwd(), check=True)
subprocess.run([py, str(BASE / "exposure_person_years.py")], cwd=os.getcwd(), check=True)
