"""All-women Model A with completed secondary schooling defined as 10 years (harmonized definition), cluster-robust SEs.
Usage: python aw_harmonized10.py <Country> <primary_years>      e.g. python aw_harmonized10.py India 5 ; Myanmar 5 ; Maldives 7
Needs results/<Country>/cohort.parquet. Writes results/<Country>/aw_harmonized10.csv (used for the primary-sample harmonized pooled row)."""
import sys, os
sys.path.insert(0, os.getcwd())
import numpy as np, pandas as pd, dhs_engine as E
country, prim = sys.argv[1], int(sys.argv[2]); E.set_thresholds(prim, 10)
raw = pd.read_parquet(f"results/{country}/cohort.parquet"); c = E.prepare(raw, False); P = E.expand(c, 6); expo = E.tv_expo(P, True); rows = []
for lvl in ("A", "B"):
    X, nm = E.design(P, lvl, expo); b, se = E.fit(X, nm, P["y"], P["wt"], P["psu_p"])
    for t in expo: rows.append(dict(country=country, model=lvl, term=t, logHR=b[t], se=se[t], HR=np.exp(b[t]), lo=np.exp(b[t] - 1.96 * se[t]), hi=np.exp(b[t] + 1.96 * se[t]), n_women=len(c), events=int(c["ev_age"].notna().sum())))
out = pd.DataFrame(rows); out.to_csv(f"results/{country}/aw_harmonized10.csv", index=False); print(out.round(3).to_string(index=False))
