"""Stage 2: pooling across countries, tables and figures, then the R steps and the manuscript number checks.
Usage: python run_stage2.py [--skip-r] [--only-r]. Reads results/<Country>/, writes results/stage2/ and figures/stage2/."""
import os, sys, subprocess, argparse, shutil
from pathlib import Path
sys.path.insert(0, os.getcwd())
try: sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
except NameError: pass
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from pooling import pool, loo

# ---- country-level inputs that are not in the DHS files (edit if you change them) ----
LEGAL_MARRIAGE_AGE = {"Bangladesh": 18, "Nepal": 18, "India": 18, "Pakistan": 16, "Afghanistan": 16, "Myanmar": 14}      # in force during the survey period
GDP_PC_CURRENT_USD = {"Bangladesh": 1965.24, "Nepal": 877.26, "India": 1553.88, "Pakistan": 1204.36, "Afghanistan": 565.57, "Myanmar": 1166.73}  # World Bank via WITS, middle survey year
ORDER = ["Bangladesh", "India", "Nepal", "Pakistan", "Afghanistan", "Myanmar"]; CORE4 = ORDER[:4]
TERMS = ["early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv"]

ap = argparse.ArgumentParser(); ap.add_argument("--skip-r", action="store_true"); ap.add_argument("--only-r", action="store_true")
args, _ = ap.parse_known_args()
BASE = Path(os.getcwd()) if (Path(os.getcwd()) / "dhs_engine.py").exists() else Path(__file__).resolve().parent
R_ = BASE / "results"; OUT = R_ / "stage2"; FIG = BASE / "figures" / "stage2"; OUT.mkdir(parents=True, exist_ok=True); FIG.mkdir(parents=True, exist_ok=True)

def run_r(script):
    exe = shutil.which("Rscript")
    if not exe: print(f"  Rscript not found on PATH: skipped {script}. Run it from RStudio (open {script}, Source)."); return
    print(f"  running {script} ..."); r = subprocess.run([exe, script], cwd=str(BASE))
    if r.returncode != 0: print(f"  {script} returned an error (see messages above).")

if not args.only_r:
    avail = [c for c in ORDER if (R_ / c / "stage1_final.csv").exists()]
    missing = [c for c in ORDER if c not in avail]
    if missing: print("WARNING: no results yet for:", ", ".join(missing), "- run their scripts first. Continuing with:", ", ".join(avail))
    if len(avail) < 3: sys.exit("Need at least three countries.")
    prim = pd.concat([pd.read_csv(R_ / c / "stage1_final.csv") for c in avail], ignore_index=True)
    harm = pd.concat([pd.read_csv((R_ / c / "sensitivity_10yr" / "stage1_final.csv") if (R_ / c / "sensitivity_10yr" / "stage1_final.csv").exists() else (R_ / c / "stage1_final.csv")) for c in avail], ignore_index=True)
    prim.to_csv(OUT / "stage1_all_primary.csv", index=False); harm.to_csv(OUT / "stage1_all_harmonized10.csv", index=False)

    def run_pooling(d, label):
        res, lo = [], []
        for m in ("A", "B"):
            for term in TERMS:
                x = d[(d.model == m) & (d.term == term)].sort_values("country")
                for setname, sub in (("all countries", x), ("core four", x[x.country.isin(CORE4)])):
                    if len(sub) < 3: continue
                    r = pool(sub.logHR.values, sub.se_boot.values); r.update(term=term, model=m, set=setname, countries=", ".join(sub.country), definition=label); res.append(r)
                    if setname == "all countries":
                        l = loo(sub.logHR.values, sub.se_boot.values, list(sub.country)); l["term"] = term; l["model"] = m; l["definition"] = label; lo.append(l)
        return pd.DataFrame(res), pd.concat(lo)
    P1, L1 = run_pooling(prim, "primary (DHS secondary definition)"); P2, L2 = run_pooling(harm, "harmonized 10+ years")
    P1.to_csv(OUT / "pooled_primary.csv", index=False); L1.to_csv(OUT / "leave_one_out_primary.csv", index=False)
    P2.to_csv(OUT / "pooled_harmonized10.csv", index=False); L2.to_csv(OUT / "leave_one_out_harmonized10.csv", index=False)
    print("\nPOOLED (primary definition, Model A):")
    print(P1[P1.model == "A"][["term", "set", "k", "HR", "hksj_lo", "hksj_hi", "pi_lo", "pi_hi", "tau", "I2"]].round(3).to_string(index=False))

    # tables
    t1 = pd.concat([pd.read_csv(R_ / c / "cohort_summary.csv") for c in avail]); t1.to_csv(OUT / "table1_sample.csv", index=False)
    cell = lambda m, t, c: (lambda r: f"{r.HR:.2f} ({r.lo_pct:.2f}, {r.hi_pct:.2f})")(prim[(prim.model == m) & (prim.term == t) & (prim.country == c)].iloc[0])
    pd.DataFrame([{"country": c, "ages 10-14 primary completed (A)": cell("A", TERMS[0], c), "ages 15-19 incomplete secondary (A)": cell("A", TERMS[1], c),
                   "ages 15-19 secondary completed (A)": cell("A", TERMS[2], c), "ages 15-19 secondary completed (B)": cell("B", TERMS[2], c)} for c in avail]).to_csv(OUT / "table2_hazard_ratios.csv", index=False)
    ar = pd.concat([pd.read_csv(R_ / c / "absolute_risks.csv") for c in avail]); ar.to_csv(OUT / "table3_absolute_risks.csv", index=False)
    mod = pd.concat([pd.read_csv(R_ / c / "moderators.csv") for c in avail]); mod["legal_marriage_age"] = mod.country.map(LEGAL_MARRIAGE_AGE)
    mod["gdp_pc_usd_current"] = mod.country.map(GDP_PC_CURRENT_USD); mod["log_gdp_pc"] = np.log(mod.gdp_pc_usd_current); mod.to_csv(OUT / "moderators.csv", index=False)
    spec = pd.concat([pd.read_csv(R_ / c / "stage1_specifications.csv").assign(country=c) for c in avail if (R_ / c / "stage1_specifications.csv").exists()])
    if len(spec): spec.to_csv(OUT / "supplement_all_specifications.csv", index=False)
    for nm in ("landmark", "allwomen"):
        fs = [pd.read_csv(R_ / c / f"stage1_{nm}.csv").assign(country=c) for c in avail if (R_ / c / f"stage1_{nm}.csv").exists()]
        if fs: pd.concat(fs).to_csv(OUT / f"supplement_{nm}.csv", index=False)
    # one-stage input
    cells = [pd.read_parquet(R_ / c / "cells_onestage.parquet").assign(country=c) for c in avail if (R_ / c / "cells_onestage.parquet").exists()]
    if cells: pd.concat(cells, ignore_index=True).to_csv(OUT / "cells_all.csv.gz", index=False)

    # ---- figures ----
    SEC = {r.country: int(r.secondary_years) for r in t1.itertuples()}
    d = prim[prim.model == "A"]
    def forest(term, title, fname, lab):
        x = d[d.term == term].set_index("country").loc[avail]; lo = np.exp(x.logHR - 1.96 * x.se_boot); hi = np.exp(x.logHR + 1.96 * x.se_boot)
        a_ = pool(x.logHR.values, x.se_boot.values); core = [c for c in avail if c in CORE4]; c4 = pool(x.loc[core].logHR.values, x.loc[core].se_boot.values) if len(core) >= 3 else None
        fig, ax = plt.subplots(figsize=(9, 5)); y = np.arange(len(avail) + 3)[::-1]
        for i, c in enumerate(avail):
            ax.plot([lo[c], hi[c]], [y[i]] * 2, color="#1f3a5f", lw=1.6); ax.plot(np.exp(x.logHR[c]), y[i], "s", color="#1f3a5f", ms=6)
            ax.text(-0.015, y[i], f"{lab(c)}  {np.exp(x.logHR[c]):.2f}", va="center", ha="right", fontsize=8.5, transform=ax.get_yaxis_transform())
        for j, (nm, r) in enumerate([("All countries (Hartung-Knapp)", a_)] + ([("Core four (Hartung-Knapp)", c4)] if c4 else [])):
            yy = y[len(avail) + j]
            ax.fill([r["hksj_lo"], r["HR"], r["hksj_hi"], r["HR"]], [yy, yy + .22, yy, yy - .22], color="#b23a48"); ax.plot([r["pi_lo"], r["pi_hi"]], [yy - .38] * 2, color="#b23a48", lw=1.2, ls="--")
            ax.text(-0.015, yy, f"{nm}  {r['HR']:.2f}", va="center", ha="right", fontsize=8.5, fontweight="bold", transform=ax.get_yaxis_transform())
        ax.axvline(1, color="grey", lw=.8); ax.set_xscale("log"); ax.set_xlim(0.08, 1.6); ax.set_xticks([.1, .2, .3, .5, 1]); ax.set_xticklabels(["0.1", "0.2", "0.3", "0.5", "1.0"])
        ax.set_yticks([]); ax.set_xlabel("Hazard ratio (log scale); diamond = 95% CI, dashed line = 95% prediction interval", fontsize=8.5); ax.set_title(title, fontsize=10, loc="left")
        [ax.spines[s].set_visible(False) for s in ("top", "right", "left")]; ax.text(.99, .02, f"I$^2$={a_['I2']:.0f}%, $\\tau$={a_['tau']:.2f}", transform=ax.transAxes, ha="right", fontsize=8)
        plt.subplots_adjust(left=.36, right=.97, top=.9, bottom=.14); plt.savefig(FIG / fname, dpi=200); plt.close()
    forest(TERMS[0], "Ages 10-14: completed primary schooling (time-varying) versus less", "forest_early.png", lambda c: c)
    forest(TERMS[2], "Ages 15-19: completed secondary schooling (time-varying) versus primary or less", "forest_late.png", lambda c: f"{c} ({SEC[c]} yrs)")
    forest(TERMS[1], "Ages 15-19: incomplete secondary schooling (time-varying) versus primary or less", "forest_late_incomplete_secondary.png", lambda c: c)
    a20 = ar[(ar.by_age == 20) & (~ar.group.str.startswith("Risk"))]; fig, ax = plt.subplots(figsize=(8.4, 4.4)); w = .26; cols = ["#9aa5b1", "#4f7cac", "#1f3a5f"]
    for k, key in enumerate(["No schooling", "Primary only", "Complete secondary"]):
        for i, c in enumerate(avail):
            s = a20[(a20.country == c) & a20.group.str.startswith(key)].iloc[0]
            ax.bar(i + (k - 1) * w, 100 * s.risk, w, color=cols[k], yerr=[[100 * (s.risk - s.lo)], [100 * (s.hi - s.risk)]], capsize=2, label=(key if i == 0 else None))
    ax.set_xticks(range(len(avail))); ax.set_xticklabels(avail, fontsize=8.5); ax.set_ylabel("Cumulative incidence of first birth by age 20 (%)", fontsize=8.5); ax.legend(fontsize=8, frameon=False)
    [ax.spines[s].set_visible(False) for s in ("top", "right")]; plt.tight_layout(); plt.savefig(FIG / "absolute_risk_age20.png", dpi=200); plt.close()
    L = L1[(L1.model == "A") & (L1.term == TERMS[2])]; fig, ax = plt.subplots(figsize=(7.5, 3.6)); yy = np.arange(len(L))[::-1]
    for y_, r in zip(yy, L.itertuples()):
        ax.plot([r.hksj_lo, r.hksj_hi], [y_, y_], color="#1f3a5f"); ax.plot(r.HR, y_, "s", color="#1f3a5f")
    ax.set_yticks(yy); ax.set_yticklabels([f"omit {o}" for o in L.omitted], fontsize=8); ax.set_xscale("log"); ax.set_xlabel("Pooled HR (95% CI) leaving one country out; ages 15-19 secondary completed", fontsize=8)
    [ax.spines[s].set_visible(False) for s in ("top", "right")]; plt.tight_layout(); plt.savefig(FIG / "leave_one_out_late.png", dpi=180); plt.close()

    # ---- manuscript check: compare this run with the numbers quoted in the manuscript ----
    exp_f = BASE / "expected_values.csv"
    if exp_f.exists():
        e = pd.read_csv(exp_f); act = {}
        for r in prim[prim.model == "A"].itertuples(): act[f"HR|{r.country}|{r.term}|A"] = r.HR
        for r in P1[P1.model == "A"].itertuples():
            for k_, v_ in (("HR", r.HR), ("hksj_lo", r.hksj_lo), ("hksj_hi", r.hksj_hi), ("pi_lo", r.pi_lo), ("pi_hi", r.pi_hi), ("I2", r.I2)): act[f"pooled|{r.set}|{r.term}|{k_}"] = v_
        for r in ar.itertuples():
            if r.by_age == 20 and not r.group.startswith("Risk"): act[f"risk20|{r.country}|{r.group.split(' (')[0]}"] = 100 * r.risk
        for r in t1.itertuples(): act[f"n_women|{r.country}"] = r.n_women; act[f"events|{r.country}"] = r.events
        e["rerun_value"] = e["key"].map(act); e["diff"] = e["rerun_value"] - e["manuscript_value"]
        e["status"] = np.where(e["rerun_value"].isna(), "MISSING", np.where(e["diff"].abs() <= e["tolerance"], "OK", "CHECK"))
        e.to_csv(OUT / "manuscript_numbers_check.csv", index=False)
        print(f"\nMANUSCRIPT CHECK: {int((e.status == 'OK').sum())} of {len(e)} quoted numbers reproduced; CHECK={int((e.status == 'CHECK').sum())}, MISSING={int((e.status == 'MISSING').sum())}  -> results/stage2/manuscript_numbers_check.csv")
    else: print("\n(expected_values.csv not found: manuscript check skipped)")
    print("Stage-2 tables written to", OUT, " figures to", FIG)

if not args.skip_r:
    print("\nR steps:"); [run_r(s) for s in ("stage2_validate.R", "stage2_metareg.R", "stage2_onestage.R")]
if (S2_OK := (OUT / "stage1_all_primary.csv").exists()):
    try:
        from dhs_engine import python_exe
        print("\nChecking the numbers written in the manuscript text:"); subprocess.run([python_exe(), "check_prose_numbers.py"], cwd=str(BASE))
    except Exception as ex: print("prose check skipped:", ex)
print("\nStage 2 finished.")
