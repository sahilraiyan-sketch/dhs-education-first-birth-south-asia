"""Shared engine: file lookup, person-period expansion, sparse weighted cloglog model, cluster bootstrap, Stage-1 runner, absolute risks, figures.
All paths are relative to the working directory."""
import os, sys, time, gc, json, shutil, zipfile, subprocess, argparse, warnings
from pathlib import Path
import numpy as np, pandas as pd
import scipy.sparse as sp
from scipy.stats import norm
warnings.filterwarnings("ignore")

CFG = {"PRIM": 5, "SEC": 10}      # years that define "primary completed" and the late-epoch secondary contrast (set per country)
def set_thresholds(prim, sec): CFG["PRIM"], CFG["SEC"] = int(prim), int(sec)

# ----------------------------------------------------------------------------- 1. helpers
_LOG = {"fh": None, "t0": time.time()}
def log(msg):
    line = f"[{time.time() - _LOG['t0']:7.0f}s] {msg}"
    print(line, flush=True)
    if _LOG["fh"]: _LOG["fh"].write(line + "\n"); _LOG["fh"].flush()

def python_exe():
    """Python used for child processes. Inside RStudio/reticulate sys.executable can point to R itself, so check it."""
    exe = sys.executable or ""
    if "python" in os.path.basename(exe).lower(): return exe
    for cand in (os.path.join(sys.prefix, "bin", "python3"), os.path.join(sys.prefix, "python.exe"), shutil.which("python3"), shutil.which("python"), shutil.which("py")):
        if cand and os.path.exists(cand): return cand
    return exe

def base_dir():
    """Working directory = where the data and scripts live. Falls back to this file's folder if the data are not in the cwd."""
    cwd = Path(os.getcwd())
    return cwd if (cwd / "dhs_engine.py").exists() else Path(__file__).resolve().parent

def find_dta(base, names, extract=True):
    """Find a raw .dta file by stem (case-insensitive) in `base` (any subfolder) or inside any .zip there (extracted once to _extracted/)."""
    base = Path(base); want = {n.lower() for n in names}
    skip = {"results", "figures", "_extracted"}
    for p in base.rglob("*"):
        if p.is_file() and p.suffix.lower() == ".dta" and p.stem.lower() in want and not (skip & set(p.relative_to(base).parts)):
            return str(p)
    ex = base / "_extracted"
    if extract: ex.mkdir(exist_ok=True)
    for z in base.rglob("*.zip"):
        if skip & set(z.relative_to(base).parts): continue
        try: zf = zipfile.ZipFile(z)
        except Exception: continue
        for m in zf.namelist():
            pm = Path(m)
            if pm.suffix.lower() == ".dta" and pm.stem.lower() in want:
                if not extract: return f"{z} (inside the zip: {pm.name})"
                out = ex / pm.name
                if not out.exists():
                    log(f"extracting {pm.name} from {z.name}"); zf.extract(m, ex / "_tmp"); shutil.move(str(ex / "_tmp" / m), str(out))
                return str(out)
    raise FileNotFoundError(f"Could not find a .dta file named any of {sorted(names)} (or a .zip containing it) under {base}. "
                            f"Put the raw DHS individual-recode file, or its .zip, in the working directory.")

# ----------------------------------------------------------------------------- 2. core model
def prepare(c, ever_married_only=True):
    """Analysis table -> cleaned copy with event age (ev_age) and a row id (pid)."""
    c = c.copy()
    if ever_married_only and "ever_married" in c: c = c[c["ever_married"] == 1]
    c = c.reset_index(drop=True)
    for col in ["v212", "v133", "v511", "v201"]: c[col] = pd.to_numeric(c[col], errors="coerce")
    c.loc[c["v133"] >= 90, "v133"] = np.nan                  # DK / missing codes
    c = c[c["v133"].notna()].reset_index(drop=True)
    for k in ("division", "ethnicity", "religion"):
        if k in c.columns: c[k] = c[k].astype(str)
    ev = np.where((c["v201"] > 0) & (c["v212"] < 20), np.maximum(c["v212"], 10), np.nan)
    c["ev_age"] = ev; c["pid"] = np.arange(len(c))
    return c

def expand(c, entry_age=6):
    """One row per woman-age (10..min(event age,19)); returns dict of numpy arrays."""
    ev = c["ev_age"].values
    reps = np.where(~np.isnan(ev), np.minimum(ev - 10 + 1, 10), 10).astype(int)
    idx = np.repeat(np.arange(len(c)), reps)
    start = np.cumsum(reps) - reps
    a = np.arange(reps.sum()) - np.repeat(start, reps) + 10
    evr = ev[idx]
    P = dict(idx=idx, a=a.astype(np.int16), y=((~np.isnan(evr)) & (a == evr)).astype(np.float64),
             wt=c["wt"].values[idx], final=c["v133"].values[idx], m511=c["v511"].values[idx])
    P["attained"] = np.minimum(P["final"], np.maximum(0, a - entry_age))
    P["early"] = (a < 15).astype(np.float64)
    P["married_tv"] = np.where(np.isnan(P["m511"]), np.nan, (a >= P["m511"]).astype(float))
    for k in ["survey_year", "division", "residence", "wealth_index", "hhead_sex", "aut_3cat", "media_any_wk", "psu_p", "strata_p",
              "partner_edu", "working_status", "social_norm_bin", "ethnicity", "religion"]:
        if k in c.columns: P[k] = c[k].values[idx]
    return P

def _cat(values, prefix, drop_ref=True, ref=None):
    s = pd.Series(values).astype(str) if not np.issubdtype(np.asarray(values).dtype, np.number) else pd.Series(values)
    codes, levels = pd.factorize(s, sort=True)
    lv = list(levels)
    if ref is not None and ref in lv: lv.remove(ref); lv = [ref] + lv
    remap = {l: i for i, l in enumerate(lv)}
    codes = s.map(remap).values
    return codes, [f"{prefix}_{l}" for l in lv]

def design(P, level="A", expo=None, extra=None, mask=None):
    """Sparse design. Baseline: age band (10-12 pooled) x wave, no intercept."""
    n = len(P["y"]); sel = np.ones(n, bool) if mask is None else mask
    pieces, names = [], []                                       # (row indices int32, column number, values or None for 1.0)
    def add_cat(codes, labels, drop_first):
        start = 1 if drop_first else 0
        for j in range(start, len(labels)):
            r = np.nonzero(codes == j)[0].astype(np.int32)
            pieces.append((r, len(names), None)); names.append(labels[j])
    band = np.clip(P["a"].astype(int), 12, None)                       # baseline hazard: age band (10-12 pooled) x survey wave
    keyi = band * 10000 + np.asarray(P["survey_year"]).astype(int)      # integer key (memory-light; same column names/order as before)
    uk, inv = np.unique(keyi, return_inverse=True)
    strs = [f"{k // 10000}_w{k % 10000}" for k in uk]; order = sorted(range(len(uk)), key=lambda i: strs[i])
    remap = np.empty(len(uk), dtype=int); remap[order] = np.arange(len(uk))
    cb = remap[inv]; lb = [f"base_{strs[i]}" for i in order]; add_cat(cb, lb, False)
    cd, ld = _cat(P["division"], "div"); add_cat(cd, ld, True)
    cr, lr = _cat(P["residence"].astype(int), "res"); add_cat(cr, lr, True)
    if "ethnicity" in P:                                   # fixed-at-birth characteristic: in every model level
        ce, le = _cat(P["ethnicity"], "eth"); add_cat(ce, le, True)
    if "religion" in P:
        crl, lrl = _cat(P["religion"], "rel"); add_cat(crl, lrl, True)
    if level in ("B", "C"):
        cw, lw = _cat(P["wealth_index"].astype(int), "wealth"); add_cat(cw, lw, True)
    if level == "C":
        if "aut_3cat" in P:
            ca, la = _cat(P["aut_3cat"].astype(str), "aut", ref="None"); add_cat(ca, la, True)
        ch, lh = _cat(P["hhead_sex"].astype(int), "hh"); add_cat(ch, lh, True)
        if "partner_edu" in P: cp, lp = _cat(P["partner_edu"].astype(int), "pedu"); add_cat(cp, lp, True)
        for k in ("social_norm_bin", "media_any_wk", "working_status"):
            if k in P:
                r = np.nonzero(P[k].astype(float) != 0)[0].astype(np.int32)
                pieces.append((r, len(names), P[k].astype(float)[r])); names.append(k)
    for k, v in (expo or {}).items():
        r = np.nonzero(v != 0)[0].astype(np.int32); pieces.append((r, len(names), v[r].astype(float))); names.append(k)
    for k, v in (extra or {}).items():
        r = np.nonzero(v != 0)[0].astype(np.int32); pieces.append((r, len(names), v[r].astype(float))); names.append(k)
    tot = sum(len(p[0]) for p in pieces)
    ri = np.empty(tot, dtype=np.int32); ci = np.empty(tot, dtype=np.int32); dv = np.empty(tot, dtype=np.float64); pos = 0
    for i_ in range(len(pieces)):
        r, j, v = pieces[i_]; m_ = len(r); ri[pos:pos + m_] = r; ci[pos:pos + m_] = j; dv[pos:pos + m_] = 1.0 if v is None else v; pos += m_
        pieces[i_] = None                                                  # free as we go
    X = sp.coo_matrix((dv, (ri, ci)), shape=(n, len(names))).tocsr(); del ri, ci, dv; gc.collect()
    if mask is not None: X = X[sel]
    return X, names


BIG = 1_000_000      # above this many person-period rows the normal equations are accumulated in row chunks (saves ~1 GB for India)

def _gram(X, iw, v=None, chunk=400_000):
    """X' diag(iw) X (+ X' v) without making full-size copies of X when X is very large."""
    n, k = X.shape
    if n <= BIG:
        XT = X.T.tocsr(); H = (XT.multiply(iw[None, :]) @ X).toarray()
        return (H, XT @ v) if v is not None else H
    H = np.zeros((k, k)); g = np.zeros(k)
    for r0 in range(0, n, chunk):
        Xc = X[r0:r0 + chunk]; XcT = Xc.T.tocsr(); H += (XcT.multiply(iw[r0:r0 + chunk][None, :]) @ Xc).toarray()
        if v is not None: g += XcT @ v[r0:r0 + chunk]
    return (H, g) if v is not None else H

def _irls(X, y, w, beta0, maxit=40, tol=1e-9):
    k = X.shape[1]; beta = beta0.copy()
    def ll(b):
        e = np.exp(np.clip(X @ b, -30, 5)); p = -np.expm1(-e)
        return np.sum(w * (y * np.log(np.clip(p, 1e-300, None)) - (1 - y) * e))
    cur = ll(beta)
    for it in range(maxit):
        e = np.exp(np.clip(X @ beta, -30, 5)); p = np.clip(-np.expm1(-e), 1e-300, 1 - 1e-12); dp = e * np.exp(-e)
        H, g = _gram(X, w * dp**2 / (p * (1 - p)), w * np.where(y == 1, dp / p, -e)); H = H + 1e-10 * np.eye(k)
        step = np.linalg.solve(H, g); t = 1.0
        while t > 1e-4:
            new = ll(beta + t * step)
            if new >= cur - 1e-10: break
            t /= 2
        beta = beta + t * step; done = abs(new - cur) < tol * (1 + abs(cur)); cur = new
        if done: break
    return beta

def start_vec(names):
    return np.array([-1.0 if n.startswith("base_") else 0.0 for n in names])

def fit(X, names, y, w, groups, chunk=400_000):
    beta = _irls(X, y, w, start_vec(names))
    e = np.exp(np.clip(X @ beta, -30, 5)); p = np.clip(-np.expm1(-e), 1e-300, 1 - 1e-12); dp = e * np.exp(-e)
    sc = np.where(y == 1, dp / p, -e); iw = w * dp**2 / (p * (1 - p)); n, k = X.shape; del e, p, dp
    bread = np.linalg.inv(_gram(X, iw) + 1e-10 * np.eye(k)); ws = w * sc
    gid, _ = pd.factorize(groups); G = gid.max() + 1
    if n <= BIG:
        Gm = sp.csr_matrix((np.ones(len(gid)), (gid, np.arange(len(gid)))), shape=(G, len(gid)))
        Ug = (Gm @ X.multiply(ws[:, None]).tocsr()).toarray()
    else:
        Ug = np.zeros((G, k))
        for r0 in range(0, n, chunk):
            Xc = X[r0:r0 + chunk]; m = Xc.shape[0]
            Gm = sp.csr_matrix((np.ones(m), (gid[r0:r0 + m], np.arange(m))), shape=(G, m)); Ug += (Gm @ Xc.multiply(ws[r0:r0 + m][:, None]).tocsr()).toarray()
    V = bread @ (Ug.T @ Ug * (G / (G - 1))) @ bread; se = np.sqrt(np.diag(V))
    return pd.Series(beta, names), pd.Series(se, names)

class Boot:
    """Stratified cluster bootstrap via PSU multiplicity weights (fast; no row duplication)."""
    def __init__(self, psu, strata):
        pc, _ = pd.factorize(psu); self.psu_code = pc; self.nP = pc.max() + 1
        first = pd.DataFrame({"p": pc, "s": pd.factorize(strata)[0]}).drop_duplicates("p")
        self.groups = [g["p"].values for _, g in first.groupby("s")]
    def multiplicity(self, rng):
        cnt = np.zeros(self.nP)
        for ids in self.groups:
            cnt[ids] = np.bincount(rng.choice(len(ids), size=len(ids), replace=True), minlength=len(ids))
        return cnt[self.psu_code]

def hr_table(beta, se, names):
    b, s = beta[names], se[names]
    return pd.DataFrame({"HR": np.exp(b), "lo": np.exp(b - 1.96 * s), "hi": np.exp(b + 1.96 * s),
                         "p": 2 * (1 - norm.cdf(np.abs(b / s)))})

def tv_expo(P, tv=True):
    att = P["attained"] if tv else P["final"]; E = P["early"]; L = 1 - E
    sfx = "_tv" if tv else "_fx"
    return {f"early_prim_comp{sfx}": ((att >= CFG["PRIM"]) * E), f"late_inc_sec{sfx}": (((att > CFG["PRIM"]) & (att < CFG["SEC"])) * L),
            f"late_comp_sec{sfx}": ((att >= CFG["SEC"]) * L)}


# ----------------------------------------------------------------------------- 3. Stage-1 runner
N_SPECS = {"main": 17, "landmark": 2, "allwomen": 4}
CULTURAL_COLS = ("ethnicity", "religion")

class SpecRunner:
    """Collects model results; can restrict to a single spec index (used by the low-memory child processes)."""
    def __init__(self, country, spec_only=0):
        self.country, self.spec_only, self.i, self.rows = country, spec_only, 0, []
    def run(self, P, label, lvl, expo, names, mask=None, extra=None):
        self.i += 1
        if self.spec_only and self.i != self.spec_only: return
        X, nm = design(P, lvl, expo, extra, mask)
        sel = np.ones(len(P["y"]), bool) if mask is None else mask
        b, se = fit(X, nm, P["y"][sel], P["wt"][sel], P["psu_p"][sel])
        t = hr_table(b, se, names); t.insert(0, "spec", label); t.insert(1, "model", lvl)
        t["n_women"] = len(np.unique(P["idx"][sel])); t["events"] = int(P["y"][sel].sum()); t["country"] = self.country
        self.rows.append(t.reset_index().rename(columns={"index": "term"})); log(f"spec {self.i:02d}: {label} [{lvl}] done"); gc.collect()
    def table(self): return pd.concat(self.rows, ignore_index=True) if self.rows else pd.DataFrame()

def section_main(c, R):
    so = R.spec_only
    need_P = (so == 0) or (1 <= so <= 9) or (14 <= so <= 17)      # specs 10-13 (entry-age 5 and 7) need only their own expansion
    P = None
    if need_P:
        P = expand(c, 6); log(f"person-period rows: {len(P['y']):,}")
        E, L, fin = P["early"], 1 - P["early"], P["final"]
        pr, sc = CFG["PRIM"], CFG["SEC"]
        naive4 = {"early_inc_sec": ((fin > pr) & (fin < sc)) * E, "early_comp_sec": (fin >= sc) * E,
                  "late_inc_sec": ((fin > pr) & (fin < sc)) * L, "late_comp_sec": (fin >= sc) * L}
        cmask = None
        ckeys = [k for k in ("aut_3cat", "media_any_wk", "partner_edu", "working_status", "social_norm_bin") if k in P]
        if ckeys:
            bad = np.zeros(len(P["y"]), bool)
            for k in ckeys: bad = bad | np.asarray(pd.isna(P[k]))
            cmask = ~bad
            for k in ("partner_edu", "working_status", "social_norm_bin"):
                if k in P: P[k] = np.nan_to_num(P[k].astype(float), nan=0.0)
        for lvl in ("A", "B", "C"):
            m = cmask if lvl == "C" else None
            if lvl == "C" and "aut_3cat" in P: P["aut_3cat"] = np.where(pd.isna(P["aut_3cat"]), "None", P["aut_3cat"].astype(str))
            if lvl == "C" and "media_any_wk" in P: P["media_any_wk"] = np.nan_to_num(P["media_any_wk"].astype(float), nan=0.0)
            R.run(P, "naive fixed (final ed.)", lvl, naive4, list(naive4), m)
            R.run(P, "naive fixed, primary-completion contrast", lvl, tv_expo(P, False), list(tv_expo(P, False)), m)
            R.run(P, "time-varying (attained by age a)", lvl, tv_expo(P, True), list(tv_expo(P, True)), m)
    else:
        R.i = 9
    for entry in (5, 7):
        if so and not (R.i < so <= R.i + 2): R.i += 2; continue
        Pe = expand(c, entry)
        for lvl in ("A", "B"): R.run(Pe, f"TV entry age {entry}", lvl, tv_expo(Pe, True), list(tv_expo(Pe, True)))
        del Pe; gc.collect()
    if P is None: return
    ok = ~np.isnan(P["married_tv"])
    for lvl in ("A", "B"):
        R.run(P, "TV education, v511-observed (no marriage term)", lvl, tv_expo(P, True), list(tv_expo(P, True)), ok)
        R.run(P, "TV education + time-varying marriage", lvl, tv_expo(P, True), list(tv_expo(P, True)) + ["married_tv"], ok,
              extra={"married_tv": np.nan_to_num(P["married_tv"], nan=0.0)})

def section_landmark(c, R):
    lm = c[(c["ev_age"].isna()) | (c["ev_age"] >= 15)].reset_index(drop=True)
    Pl = expand(lm, 6); del lm; gc.collect(); keep = Pl["a"] >= 15; att15 = np.minimum(Pl["final"], 9)
    ex = {"ed15_primary_to_8": (((att15 >= CFG["PRIM"]) & (att15 <= 8)) * 1.0), "ed15_grade9_plus": ((att15 >= 9) * 1.0)}
    for lvl in ("A", "B"): R.run(Pl, "landmark age 15 (no birth <15)", lvl, ex, list(ex), keep)

def section_allwomen(call, R):
    """All women (never-married contribute person-time with no marriage). String columns are coded to integers to save memory;
    only education and marriage coefficients are reported here, so labels do not matter."""
    ca = call.copy(); ca.loc[ca["ever_married"] == 0, "v511"] = np.inf
    need = ["pid", "ev_age", "wt", "v133", "v511", "survey_year", "division", "residence", "wealth_index", "psu_p", "strata_p", "ethnicity", "religion"]
    ca = ca[[x for x in need if x in ca.columns]].copy()
    for k in ("division", "ethnicity", "religion", "psu_p", "strata_p"):
        if k in ca.columns: ca[k] = pd.factorize(ca[k])[0]
    Pa = expand(ca, 6); log(f"all-women person-period rows: {len(Pa['y']):,}")
    for lvl in ("A", "B"):
        R.run(Pa, "ALL-WOMEN sample: TV education (no marriage term)", lvl, tv_expo(Pa, True), list(tv_expo(Pa, True)))
        ok2 = ~np.isnan(Pa["married_tv"])
        R.run(Pa, "ALL-WOMEN sample: TV education + time-varying marriage", lvl, tv_expo(Pa, True), list(tv_expo(Pa, True)) + ["married_tv"], ok2,
              extra={"married_tv": np.nan_to_num(Pa["married_tv"], nan=0.0)})

def child_spec(cfg_json, section, i):
    """Entry point for a low-memory child process: run ONE specification and write its part file."""
    cfg = json.loads(cfg_json); res = Path(cfg["base"]) / "results" / cfg["name"]
    set_thresholds(cfg["prim"], cfg["sec"]); R = SpecRunner(cfg["name"], spec_only=i)
    raw = pd.read_parquet(res / "cohort.parquet")
    if section == "allwomen": call = prepare(raw, False); del raw; section_allwomen(call, R)
    else:
        c = prepare(raw, True); del raw; gc.collect()
        (section_main if section == "main" else section_landmark)(c, R)
    (res / "_parts").mkdir(exist_ok=True); R.table().to_csv(res / "_parts" / f"{section}_{i:02d}.csv", index=False)

def run_sections(cfg, raw, res, low_memory, do_all_women):
    secs = ["main", "landmark"] + (["allwomen"] if do_all_women else [])
    for sec in secs:
        out = res / f"stage1_{'specifications' if sec == 'main' else sec}.csv"
        if out.exists(): log(f"{out.name} exists: skipping (delete it to recompute)"); continue
        log(f"--- Stage-1 section: {sec}")
        if low_memory:
            (res / "_parts").mkdir(exist_ok=True)
            for i in range(1, N_SPECS[sec] + 1):
                part = res / "_parts" / f"{sec}_{i:02d}.csv"
                if part.exists(): continue
                code = f"import sys; sys.path.insert(0, {str(cfg['base'])!r}); import dhs_engine as E; E.child_spec({json.dumps(json.dumps(cfg))}, {sec!r}, {i})"
                r = subprocess.run([python_exe(), "-c", code], cwd=str(cfg["base"]))
                if r.returncode != 0: raise RuntimeError(f"child process for {sec} spec {i} failed (out of memory?). Close other programs or add RAM.")
                log(f"spec {i}/{N_SPECS[sec]} done (child process)")
            pd.concat([pd.read_csv(res / "_parts" / f"{sec}_{i:02d}.csv") for i in range(1, N_SPECS[sec] + 1)], ignore_index=True).to_csv(out, index=False)
        else:
            R = SpecRunner(cfg["name"])
            if sec == "allwomen": section_allwomen(prepare(raw, False), R)
            else: (section_main if sec == "main" else section_landmark)(prepare(raw, True), R)
            R.table().to_csv(out, index=False)

def run_bootstrap(c, res, B, tag, seed0=20260930, levels="AB"):
    """Stratified cluster bootstrap (PSUs resampled within strata, weights carried) for the primary time-varying specification,
    Models A and B. Resumable: replicates already saved are kept."""
    P = expand(c, 6); expo = tv_expo(P, True); bt = Boot(P["psu_p"], P["strata_p"]); y, w0 = P["y"], P["wt"]; names = list(expo)
    for lvl in levels:
        outp = res / f"bootstrap_{lvl}{tag}.parquet"
        X, nm = design(P, lvl, expo)
        bfull, sefull = fit(X, nm, y, w0, P["psu_p"])
        pd.DataFrame({"beta": bfull, "se_sandwich": sefull}).to_parquet(res / f"fullfit_{lvl}{tag}.parquet")
        done = len(pd.read_parquet(outp)) if outp.exists() else 0
        if done >= B: log(f"bootstrap {lvl}{tag}: {done} replicates already saved"); del X; gc.collect(); continue
        buf = []
        for b in range(done, B):
            rng = np.random.default_rng(seed0 + b + (0 if lvl == "A" else 100000))
            try: beta = _irls(X, y, w0 * bt.multiplicity(rng), bfull.values, maxit=25, tol=1e-8)
            except Exception: continue
            buf.append(pd.Series(beta, nm))
            if len(buf) == 10 or b == B - 1:
                new = pd.DataFrame(buf)
                if outp.exists(): new = pd.concat([pd.read_parquet(outp), new], ignore_index=True)
                new.to_parquet(outp); buf = []
                log(f"bootstrap model {lvl}{tag}: {len(new)}/{B}")
        del X; gc.collect()

def final_tables(c, country, res, tag, outdir=None):
    """Primary estimates with bootstrap SE and percentile CI, plus absolute risks (g-computation over covariate cells, Model A)."""
    outdir = outdir or res; names = list(tv_expo({"attained": np.zeros(1), "final": np.zeros(1), "early": np.zeros(1)}, True))
    rows = []
    for lvl in ("A", "B"):
        full = pd.read_parquet(res / f"fullfit_{lvl}{tag}.parquet"); boot = pd.read_parquet(res / f"bootstrap_{lvl}{tag}.parquet")
        for n_ in names:
            b = full.loc[n_, "beta"]; bs = boot[n_].values
            rows.append(dict(country=country, model=lvl, term=n_, logHR=b, se_boot=bs.std(ddof=1), se_sandwich=full.loc[n_, "se_sandwich"], HR=np.exp(b),
                             lo_pct=np.exp(np.percentile(bs, 2.5)), hi_pct=np.exp(np.percentile(bs, 97.5)), n_women=len(c),
                             events=int(c["ev_age"].notna().sum()), n_boot=len(bs)))
    fin = pd.DataFrame(rows); fin.to_csv(outdir / "stage1_final.csv", index=False)
    full = pd.read_parquet(res / f"fullfit_A{tag}.parquet"); boot = pd.read_parquet(res / f"bootstrap_A{tag}.parquet"); cols = list(full.index)
    gcols = ["survey_year", "division", "residence"] + [k for k in CULTURAL_COLS if k in c.columns]
    cell = c.groupby(gcols).agg(w=("wt", "sum")).reset_index(); ages = np.arange(10, 20)
    G = cell.loc[cell.index.repeat(10)].copy(); G["a"] = np.tile(ages, len(cell)); band = np.clip(G["a"].values, 12, None)
    X = pd.DataFrame(0.0, index=G.index, columns=cols)
    for col in cols:
        if col.startswith("base_"):
            b_, w_ = col[5:].split("_w"); X[col] = ((band == int(b_)) & (G["survey_year"].astype(int).astype(str) == w_)).astype(float)
        elif col.startswith("div_"): X[col] = (G["division"].astype(str) == col[4:]).astype(float)
        elif col.startswith("res_"): X[col] = (G["residence"].astype(int).astype(str) == col[4:]).astype(float)
        elif col.startswith("eth_"): X[col] = (G["ethnicity"].astype(str) == col[4:]).astype(float)
        elif col.startswith("rel_"): X[col] = (G["religion"].astype(str) == col[4:]).astype(float)
    PR, SC = CFG["PRIM"], CFG["SEC"]; PK_, SK_ = f"Primary only ({PR} yrs)", f"Complete secondary ({SC} yrs)"
    paths = {"No schooling": 0, PK_: PR, SK_: SC}; cov_cols = [x for x in cols if x not in names]
    Eg = (G["a"].values < 15).astype(float); Lg = 1 - Eg; wc = cell["w"].values; Xc = X[cov_cols].values
    def risks(beta):
        out = {}
        for lab, fy in paths.items():
            a_ = np.minimum(fy, np.maximum(0, G["a"].values - 6))
            ex = np.column_stack([(a_ >= PR) * Eg, ((a_ > PR) & (a_ < SC)) * Lg, (a_ >= SC) * Lg])
            eta = Xc @ beta[cov_cols].values + ex @ beta[names].values
            h = -np.expm1(-np.exp(np.clip(eta, -30, 5))).reshape(-1, 10)
            out[lab] = tuple((wc * (1 - np.prod(1 - h[:, :k], axis=1))).sum() / wc.sum() for k in (5, 10))
        return out
    pt = risks(full["beta"]); rs = [risks(boot.iloc[i]) for i in range(len(boot))]; ar = []
    for lab in paths:
        for j, age in enumerate((15, 20)):
            v = np.array([r[lab][j] for r in rs]); ar.append(dict(country=country, group=lab, by_age=age, risk=pt[lab][j], lo=np.percentile(v, 2.5), hi=np.percentile(v, 97.5)))
    for ref in ("No schooling", PK_):
        for j, age in enumerate((15, 20)):
            v = np.array([r[SK_][j] - r[ref][j] for r in rs]); d0 = pt[SK_][j] - pt[ref][j]
            ar.append(dict(country=country, group=f"Risk difference: complete secondary minus {ref}", by_age=age, risk=d0, lo=np.percentile(v, 2.5), hi=np.percentile(v, 97.5)))
    ar = pd.DataFrame(ar); ar.to_csv(outdir / "absolute_risks.csv", index=False)
    return fin, ar

# ----------------------------------------------------------------------------- summaries and figures
def sample_summary(c, country, info, call):
    ev = (c["v201"] > 0) & (c["v212"] < 20)
    by = ev.groupby(c["survey_year"]).sum()
    row = dict(country=country, waves=info["waves"], frame=info["frame"], n_women=len(c), events=int(ev.sum()),
               pct_birth_before20_weighted=round(100 * np.average(ev, weights=c["wt"]), 1),
               pct_before15_weighted=round(100 * np.average(ev & (c["v212"] < 15), weights=c["wt"]), 1),
               events_by_wave="; ".join(f"{y}: {int(e)}" for y, e in by.items()), primary_years=CFG["PRIM"], secondary_years=CFG["SEC"],
               all_women_in_file_20_29=len(call))
    return pd.DataFrame([row])

def moderators(c, country):
    m = c[c["v511"].notna() & np.isfinite(c["v511"])]
    o = np.argsort(m["v511"].values); x, w = m["v511"].values[o], m["wt"].values[o]
    return pd.DataFrame([dict(country=country, median_age_first_marriage=float(x[np.searchsorted(np.cumsum(w) / w.sum(), 0.5)]),
                              pct_married_before_18=float(100 * np.average(m["v511"] < 18, weights=m["wt"])), n=len(m))])

def onestage_cells(c):
    """Weighted person-period data collapsed to covariate x exposure cells (exact for the weighted binomial likelihood); input to the R one-stage model."""
    d0 = c.copy()
    for k in CULTURAL_COLS:
        if k not in d0.columns: d0[k] = "none"
    d0 = d0[["wt", "ev_age", "v133", "v511", "survey_year", "division", "residence", "wealth_index", "ethnicity", "religion"]].copy()
    for k in ("division", "ethnicity", "religion"): d0[k] = pd.factorize(d0[k])[0]
    d0["pid"] = np.arange(len(d0)); d0["psu_p"] = 0; d0["strata_p"] = 0
    P = expand(d0, 6); ex = tv_expo(P, True); nm = list(ex)
    df = pd.DataFrame({"wave": P["survey_year"].astype(int), "division": P["division"], "residence": P["residence"].astype(int), "ethnicity": P["ethnicity"],
                       "religion": P["religion"], "a": P["a"].astype(int), "e_early": ex[nm[0]].astype(np.int8), "e_late_inc": ex[nm[1]].astype(np.int8),
                       "e_late_comp": ex[nm[2]].astype(np.int8), "wy": P["wt"] * P["y"], "w": P["wt"]})
    g = df.groupby(["wave", "division", "residence", "ethnicity", "religion", "a", "e_early", "e_late_inc", "e_late_comp"], as_index=False).agg(wy=("wy", "sum"), w=("w", "sum"))
    g["PRIM"], g["SEC"] = CFG["PRIM"], CFG["SEC"]; return g

def plot_country(country, res, figs):
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    figs.mkdir(parents=True, exist_ok=True)
    sp_f = res / "stage1_specifications.csv"
    if sp_f.exists():
        d = pd.read_csv(sp_f); d = d[d.model == "A"]
        items = [("early_comp_sec", "naive fixed (final ed.)", None), ("early_prim_comp_fx", "naive fixed, primary-completion contrast", "Ages 10-14 primary completed: final schooling"),
                 ("early_prim_comp_tv", "time-varying (attained by age a)", "Ages 10-14 primary completed: time-varying"),
                 ("early_prim_comp_tv", "TV education + time-varying marriage", "Ages 10-14 primary completed: + marriage"),
                 ("late_comp_sec", "naive fixed (final ed.)", "Ages 15-19 secondary completed: final schooling"),
                 ("late_comp_sec_tv", "time-varying (attained by age a)", "Ages 15-19 secondary completed: time-varying"),
                 ("late_comp_sec_tv", "TV education + time-varying marriage", "Ages 15-19 secondary completed: + marriage")]
        rows = []
        for term, spec, lab in items:
            if lab is None: continue
            r = d[(d.term == term) & (d.spec == spec)]
            if len(r): rows.append((lab, r.iloc[0]))
        fig, ax = plt.subplots(figsize=(8.4, 3.8)); yy = np.arange(len(rows))[::-1]
        for y_, (lab, r) in zip(yy, rows):
            ax.plot([r.lo, r.hi], [y_, y_], color="#1f3a5f", lw=1.6); ax.plot(r.HR, y_, "s", color="#1f3a5f", ms=6); ax.text(1.5, y_, f"{r.HR:.2f}", va="center", fontsize=8)
        ax.set_yticks(yy); ax.set_yticklabels([r[0] for r in rows], fontsize=8); ax.axvline(1, color="grey", lw=0.8); ax.set_xscale("log")
        ax.set_xlim(0.05, 3); ax.set_xticks([0.1, 0.2, 0.5, 1]); ax.set_xticklabels(["0.1", "0.2", "0.5", "1"]); ax.set_xlabel("Hazard ratio (log scale), Model A")
        ax.set_title(f"{country}: education and first birth before 20", fontsize=10, loc="left"); [ax.spines[s].set_visible(False) for s in ("top", "right")]
        plt.tight_layout(); plt.savefig(figs / "hr_specifications.png", dpi=170); plt.close()
    ar_f = res / "absolute_risks.csv"
    if ar_f.exists():
        ar = pd.read_csv(ar_f); ar = ar[~ar.group.str.startswith("Risk")]; groups = list(ar.group.unique())
        fig, axs = plt.subplots(1, 2, figsize=(8.4, 3.4), sharey=False)
        for ax, age in zip(axs, (15, 20)):
            s = ar[ar.by_age == age].set_index("group").loc[groups]
            ax.bar(range(3), 100 * s.risk, color=["#9aa5b1", "#4f7cac", "#1f3a5f"], yerr=[100 * (s.risk - s.lo), 100 * (s.hi - s.risk)], capsize=3)
            ax.set_xticks(range(3)); ax.set_xticklabels(["No\nschooling"] + [g.replace(" (", "\n(") for g in groups[1:]], fontsize=7); ax.set_title(f"By age {age}", fontsize=9)
            ax.set_ylabel("Cumulative incidence of first birth (%)", fontsize=8); [ax.spines[q].set_visible(False) for q in ("top", "right")]
        plt.suptitle(country, fontsize=10); plt.tight_layout(); plt.savefig(figs / "absolute_risk.png", dpi=170); plt.close()
    bf = res / "bootstrap_A.parquet"
    if bf.exists():
        b = pd.read_parquet(bf); cols = [c_ for c_ in b.columns if c_.endswith("_tv")]
        fig, axs = plt.subplots(1, len(cols), figsize=(9, 2.6))
        for ax, c_ in zip(np.atleast_1d(axs), cols):
            ax.hist(np.exp(b[c_]), bins=30, color="#4f7cac"); ax.set_title(c_.replace("_tv", ""), fontsize=8); ax.set_xlabel("HR (bootstrap)", fontsize=8)
        plt.suptitle(f"{country}: bootstrap distribution, Model A ({len(b)} replicates)", fontsize=9); plt.tight_layout(); plt.savefig(figs / "bootstrap_distribution.png", dpi=150); plt.close()

# ----------------------------------------------------------------------------- orchestration
def main(cfg_in, argv=None):
    ap = argparse.ArgumentParser(description=f"Run the {cfg_in['name']} analysis")
    ap.add_argument("--B", type=int, default=None, help="bootstrap replicates for the primary run (default from the script)")
    ap.add_argument("--quick", action="store_true", help="test run: 20 bootstrap replicates, no sensitivity run")
    ap.add_argument("--skip-specs", action="store_true", help="skip the sensitivity specifications (naive, entry age, marriage, landmark, all-women)")
    ap.add_argument("--skip-sensitivity", action="store_true", help="skip the harmonized 10+ year sensitivity run")
    ap.add_argument("--rebuild", action="store_true", help="rebuild the cohort from the raw files even if cohort.parquet exists")
    ap.add_argument("--low-memory", dest="low_memory", action="store_true", default=None, help="run each specification in its own process")
    ap.add_argument("--normal-memory", dest="low_memory", action="store_false")
    a, _ = ap.parse_known_args(argv if argv is not None else [x for x in sys.argv[1:]])
    cfg = dict(cfg_in); cfg["base"] = str(cfg.get("base") or base_dir()); name = cfg["name"]
    res = Path(cfg["base"]) / "results" / name; figs = Path(cfg["base"]) / "figures" / name; res.mkdir(parents=True, exist_ok=True); figs.mkdir(parents=True, exist_ok=True)
    _LOG["fh"] = open(res / "run_log.txt", "a"); _LOG["t0"] = time.time()
    log(f"===== {name}: start  (working directory: {cfg['base']})")
    B = a.B if a.B else (20 if a.quick else cfg["B"]); B_alt = 20 if a.quick else cfg.get("B_alt", 200)
    low = a.low_memory if a.low_memory is not None else cfg.get("low_memory", False)
    set_thresholds(cfg["prim"], cfg["sec"])
    import cohorts
    cpath = res / "cohort.parquet"
    if cpath.exists() and not a.rebuild:
        raw = pd.read_parquet(cpath); info = json.load(open(res / "cohort_info.json")); log(f"cohort loaded from {cpath.name} ({len(raw):,} women aged 20-29)")
    else:
        log("building the cohort from the raw DHS files"); raw, info = getattr(cohorts, cfg["builder"])(cfg["base"])
        raw.to_parquet(cpath); json.dump(info, open(res / "cohort_info.json", "w")); log(f"cohort built: {len(raw):,} women aged 20-29")
    c = prepare(raw, True); n_raw = len(raw)
    sample_summary(c, name, info, raw).to_csv(res / "cohort_summary.csv", index=False); moderators(c, name).to_csv(res / "moderators.csv", index=False)
    log(f"analysis sample: {len(c):,} women, {int(c['ev_age'].notna().sum()):,} first births before 20  (primary={CFG['PRIM']} yrs, secondary={CFG['SEC']} yrs)")
    if not a.skip_specs and not a.quick:
        run_sections(cfg, raw, res, low, cfg.get("all_women", False))
    elif a.quick and not a.skip_specs:
        log("quick mode: sensitivity specifications skipped (use the full run for them)")
    del raw; gc.collect()
    run_bootstrap(c, res, B, "")
    fin, ar = final_tables(c, name, res, ""); log("primary estimates and absolute risks written")
    onestage_cells(c).to_parquet(res / "cells_onestage.parquet")
    if cfg.get("sec_alt") and not a.skip_sensitivity and not a.quick:
        sens = res / "sensitivity_10yr"; sens.mkdir(exist_ok=True)
        set_thresholds(cfg["prim"], cfg["sec_alt"]); log(f"--- harmonized sensitivity: secondary = {cfg['sec_alt']} years")
        run_bootstrap(c, sens, B_alt, ""); final_tables(c, name, sens, ""); onestage_cells(c).to_parquet(sens / "cells_onestage.parquet")
        set_thresholds(cfg["prim"], cfg["sec"])
    plot_country(name, res, figs)
    log(f"===== {name}: finished. Results in {res}  Figures in {figs}")
    print("\nKEY RESULTS (Model A):"); print(fin[fin.model == "A"][["term", "HR", "lo_pct", "hi_pct", "se_boot"]].round(3).to_string(index=False))
    _LOG["fh"].close(); _LOG["fh"] = None
