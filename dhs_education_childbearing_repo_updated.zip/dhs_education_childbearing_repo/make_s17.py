import sys, numpy as np, pandas as pd
from scipy import optimize, stats
sys.path.insert(0, sys.argv[1]); from pooling import pool
D = sys.argv[2]; TERMS = ["early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv"]
def qprof(y, se):
    y = np.asarray(y); v = np.asarray(se) ** 2; k = len(y)
    def Q(t2):
        w = 1 / (v + t2); mu = np.sum(w * y) / np.sum(w); return np.sum(w * (y - mu) ** 2)
    lo_q, hi_q = stats.chi2.ppf(0.025, k - 1), stats.chi2.ppf(0.975, k - 1)   # Q decreases with tau2
    def solve(target):
        if Q(0) < target: return 0.0
        return optimize.brentq(lambda t: Q(t) - target, 0, 100)
    return solve(hi_q), solve(lo_q) if Q(0) >= lo_q else 0.0    # lower tau2 bound from upper chi2 quantile
s1 = pd.read_csv(f"{D}/stage1_all_primary.csv"); aw = pd.read_csv(f"{D}/supplement_allwomen.csv")
aw = aw[aw.spec.str.contains("no marriage term")]
ne = lambda d: d[~((d.country == "Maldives") & d.term.str.startswith("early"))]   # ages 10-14 contrast not estimable in the Maldives
s1 = ne(s1); aw = ne(aw)
rows = []
for model in ["A", "B"]:
    for source in ["main sample (as in Table 5 of the paper)", "all women where sampled (India, Nepal, Myanmar all-women estimates substituted)"]:
        for cset, ctry in [("all countries", None), ("core four", ["Bangladesh", "India", "Nepal", "Pakistan"])]:
            for term in TERMS:
                d = s1[(s1.model == model) & (s1.term == term)].set_index("country")
                y = d.logHR.copy(); se = d.se_boot.copy()
                if source.startswith("all women"):
                    a = aw[(aw.model == model) & (aw.term == term)].set_index("country")
                    for c in a.index:
                        y[c] = np.log(a.HR[c]); se[c] = (np.log(a.hi[c]) - np.log(a.lo[c])) / (2 * 1.959964)
                if ctry: y, se = y[ctry], se[ctry]
                r = pool(y.values, se.values); t2lo, t2hi = qprof(y.values, se.values)
                rows.append(dict(model=model, sample=source.split(" (")[0], countries=cset, term=term, k=r["k"], pooled_HR=r["HR"], HKSJ_lo=r["hksj_lo"], HKSJ_hi=r["hksj_hi"],
                    PI_lo=r["pi_lo"], PI_hi=r["pi_hi"], tau=r["tau"], tau_Qprofile_lo=np.sqrt(t2lo), tau_Qprofile_hi=np.sqrt(t2hi), Q=r["Q"], Q_p=r["Q_p"], I2_pct=r["I2"]))
pd.DataFrame(rows).to_csv(sys.argv[3], index=False); print(pd.DataFrame(rows).round(3).to_string())
