"""Maldives: cohort, Stage-1 models, bootstrap, absolute risks, tables and figures (same engine as the other countries).
Usage: python run_maldives.py [--quick] [--B N] [--skip-specs] [--skip-sensitivity] [--rebuild] [--low-memory]
Needs maldives_settings.json (written by check_maldives_data.py). Reads the raw DHS files from the working directory. Writes results/Maldives/ and figures/Maldives/."""
import os, sys, json
sys.path.insert(0, os.getcwd())
try: sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
except NameError: pass
import dhs_engine as E
st = json.load(open("maldives_settings.json")) if os.path.exists("maldives_settings.json") else sys.exit("Run check_maldives_data.py first (it writes maldives_settings.json).")
CONFIG = dict(
    name="Maldives",
    builder="build_maldives",
    prim=st["prim"],            # years defining primary completed (DHS definition)
    sec=st["sec"],              # years defining secondary completed (DHS definition)
    sec_alt=st.get("sec_alt"),  # harmonized 10-year sensitivity run (None if the DHS definition is already 10 years)
    B=1000,
    B_alt=200,
    all_women=True,             # the Maldives surveys sampled all women
    low_memory=False,
)
E.main(CONFIG)
