"""Adds Maldives to the repository scripts. Usage: python apply_maldives_patch.py <repo_dir>
Idempotent: running it twice changes nothing the second time. Reads maldives_settings.json (written by check_maldives_data.py) from <repo_dir>."""
import sys, json, re
from pathlib import Path
repo = Path(sys.argv[1]).resolve(); here = Path(__file__).resolve().parent
st = json.load(open(repo / "maldives_settings.json")) if (repo / "maldives_settings.json").exists() else dict(prim=7, sec=12, gdp_pc_usd_current=None, legal_marriage_age=18)
P, S_ = st["prim"], st["sec"]; log = []
SIX = '["Bangladesh", "India", "Nepal", "Pakistan", "Afghanistan", "Myanmar"]'; SEVEN = SIX[:-1] + ', "Maldives"]'
ROOTEXPR = '__import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__)))'
def edit(rel, pairs, must=True):
    f = repo / rel
    if not f.exists():
        if must: log.append(f"MISSING FILE {rel}")
        return
    t = f.read_text(encoding="utf-8"); n = 0
    for a, b in pairs:
        if a in t: t = t.replace(a, b); n += 1
    f.write_text(t, encoding="utf-8"); log.append(f"{rel}: {n} replacement(s)")
for rel in ["run_stage2.py", "pool_marriage.py", "bias_analysis/primary_allwomen.py", "bias_analysis/qba_inputs.py", "bias_analysis/qba_pool.py", "bias_analysis/qba_pool2.py",
            "bias_analysis/qba_prob.py", "bias_analysis/qba_prob2.py", "allwomen_analysis/aw_assemble.py"]:
    edit(rel, [(SIX, SEVEN), ('AW = ["India", "Nepal", "Myanmar"]', 'AW = ["India", "Nepal", "Myanmar", "Maldives"]'),
               ('sys.path.insert(0, "/home/claude/repo/dhs_education_childbearing_repo")', f"sys.path.insert(0, {ROOTEXPR})")])
edit("allwomen_analysis/aw_assemble.py", [('"Afghanistan": 6, "Myanmar": 5}', f'"Afghanistan": 6, "Myanmar": 5, "Maldives": {P}}}'), ('"Afghanistan": 12, "Myanmar": 11}', f'"Afghanistan": 12, "Myanmar": 11, "Maldives": {S_}}}')])
edit("bias_analysis/primary_allwomen.py", [("six countries", "seven countries")])
edit("make_s17.py", [("all six countries", "all countries")])
edit("exposure_person_years.py", [('"Myanmar": (5, 11)}', f'"Myanmar": (5, 11), "Maldives": ({P}, {S_})}}')]); edit("run_extras.py", [('"Myanmar": (5, 11)}', f'"Myanmar": (5, 11), "Maldives": ({P}, {S_})}}')])
g = st.get("gdp_pc_usd_current"); edit("run_stage2.py", [('"Myanmar": 14}', f'"Myanmar": 14, "Maldives": {st.get("legal_marriage_age", 18)}}}'), ('"Myanmar": 1166.73}', f'"Myanmar": 1166.73, "Maldives": {g if g else "float(\'nan\')"}}}')])
edit("check_setup.py", [('"Myanmar": [["MMIR71FL"]]}', '"Myanmar": [["MMIR71FL"]], "Maldives": [["MVIR51FL"], ["MVIR71FL"]]}')])
edit("allwomen_analysis/build_cohorts.py", [('"Myanmar": "build_myanmar"}', '"Myanmar": "build_myanmar", "Maldives": "build_maldives"}')])
c = repo / "cohorts.py"; t = c.read_text(encoding="utf-8")
if "def build_maldives" not in t:
    add = (here / "cohorts_maldives.py").read_text(encoding="utf-8"); add = "\n".join(l for l in add.splitlines() if not l.startswith(("import ", "from "))) 
    t += "\n\nimport re, json, zipfile\n# ------------------------------------------------------------------ Maldives\n" + add + "\n"; c.write_text(t, encoding="utf-8"); log.append("cohorts.py: build_maldives appended")
import shutil
for f in ("run_maldives.py", "check_maldives_data.py", "aw_harmonized10.py", "cohorts_maldives.py"):
    if (here / f).resolve() != (repo / f).resolve(): shutil.copy(here / f, repo / f)
print("\n".join(log))
