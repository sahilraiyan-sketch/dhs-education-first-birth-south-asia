# One-stage model: weighted binomial (cloglog) mixed model with pooled education terms and independent random country slopes.
# Reads results/stage2/cells_all.csv.gz (written by run_stage2.py). Takes a few minutes.
for (p in c("lme4", "Matrix")) if (!requireNamespace(p, quietly = TRUE)) install.packages(p, repos = "https://cloud.r-project.org")
suppressMessages({library(lme4); library(Matrix)})
d <- read.csv("results/stage2/cells_all.csv.gz"); d$country <- factor(d$country); d$ageband <- pmax(d$a, 12)
d$base <- factor(paste(d$country, d$wave, d$ageband)); d$div <- factor(paste(d$country, d$division)); d$res <- factor(paste(d$country, d$residence))
d$eth <- factor(paste(d$country, d$ethnicity)); d$rel <- factor(paste(d$country, d$religion)); d$p <- d$wy / d$w
f2 <- suppressWarnings(glmer(p ~ 0 + base + div + res + eth + rel + e_early + e_late_inc + e_late_comp + (0 + e_early + e_late_inc + e_late_comp || country),
                             family = binomial(link = "cloglog"), weights = w, data = d, nAGQ = 0, control = glmerControl(optimizer = "nloptwrap", calc.derivs = FALSE)))
nm <- c("e_early", "e_late_inc", "e_late_comp"); fe <- fixef(f2)[nm]; se <- sqrt(diag(as.matrix(vcov(f2))))[nm]; vc <- as.data.frame(VarCorr(f2))
k <- nlevels(d$country)
out <- data.frame(term = nm, logHR = fe, se_model = se, HR = exp(fe), lo_t = exp(fe - qt(.975, k - 1) * se), hi_t = exp(fe + qt(.975, k - 1) * se), tau = vc$sdcor[match(nm, vc$var1)])
write.csv(out, "results/stage2/onestage_mixed_results.csv", row.names = FALSE); print(out, digits = 3)
