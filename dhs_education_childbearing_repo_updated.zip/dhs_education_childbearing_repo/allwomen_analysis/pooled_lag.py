"""Pools the current and one-year-lagged schooling estimates (Additional file 1, Table S23) across seven countries, primary sample and ever-married women.
Run from the repository root after results/<Country>/aw_extras.csv (India, Nepal, Myanmar, Maldives) and reference_results/<Country>/extras2.csv exist.
The Maldives is left out of the ages 10-14 contrast (13 first births before age 15). Writes final_aw/pooled_lag_both_frames.csv."""
import sys, os
sys.path.insert(0, os.getcwd())
import numpy as np, pandas as pd
from pooling import pool
ORDER = ["Bangladesh", "India", "Nepal", "Pakistan", "Afghanistan", "Myanmar", "Maldives"]; AW = ["India", "Nepal", "Myanmar", "Maldives"]
TERMS = ["early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv"]; rows = []
def est(c, frame, lab):
    d = pd.read_csv(f"results/{c}/aw_extras.csv") if frame == "aw" else pd.read_csv(f"reference_results/{c}/extras2.csv"); d = d[d.analysis == lab]
    return {t: (np.log(float(d[d.term == t].HR.iloc[0])), (np.log(float(d[d.term == t].hi.iloc[0])) - np.log(float(d[d.term == t].lo.iloc[0]))) / (2 * 1.959964)) for t in TERMS}
for analysis in ["current (age a)", "lag 1 year (schooling reached at age a-1)"]:
    for fn, sel in [("Primary sample", lambda c: "aw" if c in AW else "em"), ("Ever-married women", lambda c: "em")]:
        for t in TERMS:
            ys, ss = [], []
            for c in ORDER:
                if c == "Maldives" and t.startswith("early"): continue
                y, s = est(c, sel(c), analysis)[t]; ys.append(y); ss.append(s)
            r = pool(np.array(ys), np.array(ss)); rows.append(dict(analysis=analysis, frame=fn, term=t, k=len(ys), HR=r["HR"], lo=r["hksj_lo"], hi=r["hksj_hi"], pi_lo=r["pi_lo"], pi_hi=r["pi_hi"]))
os.makedirs("final_aw", exist_ok=True); pd.DataFrame(rows).to_csv("final_aw/pooled_lag_both_frames.csv", index=False)
