"""All-women versions of the lag-1, survey-round (wave-specific + Wald test) and landmark analyses. Usage: python aw_extras.py India 5 12
Writes results/<country>/aw_extras.csv (cluster-robust SEs; Model A, plus Model B for the landmark)."""
import sys, os, gc
sys.path.insert(0, os.getcwd())
import numpy as np, pandas as pd, scipy.sparse as sp
from scipy.stats import norm, chi2
import dhs_engine as E
country, prim, sec = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]); E.set_thresholds(prim, sec)
raw = pd.read_parquet(f"results/{country}/cohort.parquet"); out = []
def fit_cov(X, names, y, w, groups):
    beta = E._irls(X, y, w, E.start_vec(names))
    e = np.exp(np.clip(X @ beta, -30, 5)); p = np.clip(-np.expm1(-e), 1e-300, 1 - 1e-12); dp = e * np.exp(-e)
    sc = np.where(y == 1, dp / p, -e); iw = w * dp**2 / (p * (1 - p)); k = X.shape[1]
    bread = np.linalg.inv(E._gram(X, iw) + 1e-10 * np.eye(k)); ws = w * sc
    gid, _ = pd.factorize(groups); G = gid.max() + 1; Ug = np.zeros((G, k)); chunk = 400_000
    for r0 in range(0, X.shape[0], chunk):
        Xc = X[r0:r0 + chunk]; m = Xc.shape[0]
        Gm = sp.csr_matrix((np.ones(m), (gid[r0:r0 + m], np.arange(m))), shape=(G, m)); Ug += (Gm @ Xc.multiply(ws[r0:r0 + m][:, None]).tocsr()).toarray()
    return pd.Series(beta, names), bread @ (Ug.T @ Ug * (G / (G - 1))) @ bread
def run(label, P, expo, report, level="A", mask=None):
    sel = np.ones(len(P["y"]), bool) if mask is None else mask
    X, nm = E.design(P, level, expo, None, mask); b, V = fit_cov(X, nm, P["y"][sel], P["wt"][sel], P["psu_p"][sel]); se = pd.Series(np.sqrt(np.diag(V)), nm)
    for t in report:
        out.append(dict(country=country, sample="All women", analysis=label, model=level, term=t, HR=np.exp(b[t]), lo=np.exp(b[t] - 1.96 * se[t]), hi=np.exp(b[t] + 1.96 * se[t]),
                        p=2 * (1 - norm.cdf(abs(b[t] / se[t]))), events=int(P["y"][sel].sum()), n_rows=int(sel.sum()), logHR=b[t], se=se[t]))
    E.log(f"{country} {label} [{level}] done"); gc.collect(); return b, V, nm
def tv(P, att): Q = dict(P); Q["attained"] = att; return E.tv_expo(Q, True)
c = E.prepare(raw, False); P = E.expand(c, 6); terms = list(tv(P, P["attained"]))
run("current (age a)", P, tv(P, P["attained"]), terms)
lagatt = np.minimum(P["final"], np.maximum(0, P["a"] - 1 - 6))
run("lag 1 year (schooling reached at age a-1)", P, tv(P, lagatt), terms)
L = 1 - P["early"]; out.append(dict(country=country, sample="All women", analysis="exposed person-years, late completed secondary", term="current/lag1", HR=float(((P["attained"] >= sec) * L).sum()), lo=float(((lagatt >= sec) * L).sum())))
waves = sorted(np.unique(P["survey_year"]).tolist())
if len(waves) > 1:
    cur = tv(P, P["attained"]); ex = {}
    for t in terms:
        for w_ in waves: ex[f"{t}__w{w_}"] = cur[t] * (np.asarray(P["survey_year"]) == w_)
    b, V, nm = run("wave-specific", P, ex, list(ex))
    for t in terms:
        cols = [f"{t}__w{w_}" for w_ in waves]; idx = [nm.index(x) for x in cols]; d = np.array([b[cols[i]] - b[cols[0]] for i in range(1, len(cols))])
        D = np.zeros((len(cols) - 1, len(nm)))
        for i in range(1, len(cols)): D[i - 1, idx[i]] = 1; D[i - 1, idx[0]] = -1
        W = float(d @ np.linalg.solve(D @ V @ D.T, d)); out.append(dict(country=country, sample="All women", analysis="wave heterogeneity Wald test", term=t, HR=W, lo=len(d), p=1 - chi2.cdf(W, len(d))))
del P; gc.collect()
# landmark at age 15 (no birth before 15), all women
lm = c[(c["ev_age"].isna()) | (c["ev_age"] >= 15)].reset_index(drop=True); Pl = E.expand(lm, 6); keep = Pl["a"] >= 15; att15 = np.minimum(Pl["final"], 9)
ex = {"ed15_primary_to_8": (((att15 >= E.CFG["PRIM"]) & (att15 <= 8)) * 1.0), "ed15_grade9_plus": ((att15 >= 9) * 1.0)}
for lvl in ("A", "B"): run("landmark age 15 (no birth <15)", Pl, ex, list(ex), lvl, keep)
pd.DataFrame(out).to_csv(f"results/{country}/aw_extras.csv", index=False); E.log(f"{country}: aw_extras.csv written")
