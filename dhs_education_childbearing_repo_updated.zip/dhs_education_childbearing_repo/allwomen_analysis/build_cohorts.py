import sys, os, json
sys.path.insert(0, os.getcwd())
import pandas as pd, dhs_engine as E, cohorts
from pathlib import Path
name = sys.argv[1]; fn = {"India": "build_india", "Nepal": "build_nepal", "Myanmar": "build_myanmar", "Maldives": "build_maldives"}[name]
raw, info = getattr(cohorts, fn)(os.getcwd())
res = Path("results") / name; res.mkdir(parents=True, exist_ok=True)
raw.to_parquet(res / "cohort.parquet"); json.dump(info, open(res / "cohort_info.json", "w"))
print(name, len(raw), raw.columns.tolist()[:30])
