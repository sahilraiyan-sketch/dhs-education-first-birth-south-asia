All-women analyses (India, Nepal, Myanmar), Oct 2026. Run from the folder that holds dhs_engine.py and data/:
  python3 build_cohorts.py <Country>
  python3 aw_bootstrap.py <Country> <primary_years> <secondary_years> <B>   (India 5 12 500; Nepal 5 10 1000; Myanmar 5 11 1000)
  python3 aw_extras.py <Country> <primary_years> <secondary_years>
  python3 aw_assemble.py   # builds Table 5, Figure 3 and the CSVs in this folder (Additional file 1, S22 to S25)
CSV files here are the outputs used in the manuscript.
