"""Assemble all-women (primary frame) results: absolute-risk table + figure, pooled lag / landmark, wave-specific. Myanmar included if its results exist."""
import sys, os
sys.path.insert(0, os.getcwd()); sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))))
import numpy as np, pandas as pd
from pooling import pool
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
ORDER = ["Bangladesh", "India", "Nepal", "Pakistan", "Afghanistan", "Myanmar", "Maldives"]; AW = ["India", "Nepal", "Myanmar", "Maldives"]
PRIM = {"Bangladesh": 5, "India": 5, "Nepal": 5, "Pakistan": 5, "Afghanistan": 6, "Myanmar": 5, "Maldives": 7}; SEC = {"Bangladesh": 10, "India": 12, "Nepal": 10, "Pakistan": 10, "Afghanistan": 12, "Myanmar": 11, "Maldives": 12}
have = [c for c in AW if os.path.exists(f"results/{c}/allwomen_out/absolute_risks.csv") and os.path.exists(f"results/{c}/aw_extras.csv")]
print("all-women results available for:", have)
OUT = "final_aw"; os.makedirs(OUT + "/tables", exist_ok=True); os.makedirs(OUT + "/figures", exist_ok=True)
# ---------------------------------------------------------------- absolute risks
em = pd.read_csv("ref/stage2/table3_absolute_risks.csv"); rows = []
def getar(c, frame):
    d = em[em.country == c] if frame == "Ever-married" else pd.read_csv(f"results/{c}/allwomen_out/absolute_risks.csv")
    g = lambda grp, age: d[(d.group.str.startswith(grp)) & (d.by_age == age)].iloc[0]
    n0, p0, s0 = g("No schooling", 20), g("Primary only", 20), g("Complete secondary", 20); df = g("Risk difference: complete secondary minus No schooling", 20)
    return dict(country=c, frame=frame, r15_none=g("No schooling", 15).risk, r15_prim=g("Primary only", 15).risk, none=n0, prim=p0, sec=s0, diff=df)
for c in ORDER:
    if c in have: rows.append(getar(c, "All women")); rows.append(getar(c, "Ever-married"))
    elif c in AW: rows.append(getar(c, "Ever-married")); rows[-1]["frame"] = "Ever-married (all-women run pending)"
    else: rows.append(getar(c, "Ever-married"))
f1 = lambda r: f"{100 * r.risk:.1f} ({100 * r.lo:.1f}, {100 * r.hi:.1f})"
L = [r"\begin{tabular}{p{1.9cm}p{2.0cm}p{1.0cm}p{1.0cm}p{2.4cm}p{2.4cm}p{2.4cm}p{2.6cm}p{2.5cm}}", r"\toprule", r" & & \multicolumn{2}{c}{By age 15} & \multicolumn{5}{c}{By age 20}\\", r"\cmidrule(lr){3-4}\cmidrule(lr){5-9}",
     r"Country & Sample & No school & Primary & No schooling & Primary only & Secondary completed & Difference, secondary vs none (pp) & Fewer births per 1,000 girls \\", r"\midrule"]
for i, r in enumerate(rows):
    lab = r["country"] if (i == 0 or rows[i - 1]["country"] != r["country"]) else ""
    fr = "All women$^{a}$" if r["frame"] == "All women" else "Ever-married"
    d = r["diff"]; L.append(f"{lab} & {fr} & {100 * r['r15_none']:.1f} & {100 * r['r15_prim']:.1f} & {f1(r['none'])} & {f1(r['prim'])} & {f1(r['sec'])} & {100 * d.risk:.1f} ({100 * d.lo:.1f}, {100 * d.hi:.1f}) & {-1000 * d.risk:.0f} ({-1000 * d.hi:.0f}, {-1000 * d.lo:.0f}) \\\\")
    if i + 1 < len(rows) and rows[i + 1]["country"] != r["country"]: L.append(r"\addlinespace")
L += [r"\bottomrule", r"\end{tabular}"]; open(OUT + "/tables/table4.tex", "w").write("\n".join(L) + "\n")
pd.DataFrame([{**{k: v for k, v in r.items() if k in ("country", "frame", "r15_none", "r15_prim")}, "none20": r["none"].risk, "prim20": r["prim"].risk, "sec20": r["sec"].risk, "diff20": r["diff"].risk, "diff_lo": r["diff"].lo, "diff_hi": r["diff"].hi} for r in rows]).to_csv(OUT + "/absolute_risks_both_frames.csv", index=False)
# ---------------------------------------------------------------- figure 3: primary frame bars, ever-married markers
fig, ax = plt.subplots(figsize=(8.6, 4.5)); w = .26; cols = ["#9aa5b1", "#4f7cac", "#1f3a5f"]; keys = [("none", "No schooling"), ("prim", "Primary only"), ("sec", "Secondary completed")]
prim_rows = {r["country"]: r for r in rows if r["frame"] == "All women" or (r["country"] not in have)}; em_rows = {r["country"]: r for r in rows if r["frame"].startswith("Ever-married") and r["country"] in have}
for k, (key, lab) in enumerate(keys):
    for i, c in enumerate(ORDER):
        s = prim_rows[c][key] if c in prim_rows else None
        if s is None: continue
        ax.bar(i + (k - 1) * w, 100 * s.risk, w, color=cols[k], yerr=[[100 * (s.risk - s.lo)], [100 * (s.hi - s.risk)]], capsize=2, label=(lab if i == 0 else None))
        if c in em_rows: ax.plot(i + (k - 1) * w, 100 * em_rows[c][key].risk, marker="D", ms=5, mfc="white", mec="black", ls="none", label=("Ever-married women (same countries)" if (k == 0 and c == have[0]) else None))
ax.set_xticks(range(len(ORDER))); ax.set_xticklabels([c + ("\n(all women)" if c in have else "\n(ever-married)") for c in ORDER], fontsize=8.5)
ax.set_ylabel("Cumulative incidence of first birth by age 20 (%)", fontsize=8.5); ax.legend(fontsize=8, frameon=False); [ax.spines[s].set_visible(False) for s in ("top", "right")]
plt.tight_layout(); plt.savefig(OUT + "/figures/figure1_absolute_risk.png", dpi=200); plt.close()
# ---------------------------------------------------------------- lag-1 pooled, both frames
TERMS = ["early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv"]; lagrows = []
def est(c, frame, lab):
    if frame == "aw":
        d = pd.read_csv(f"results/{c}/aw_extras.csv"); d = d[d.analysis == lab]
    else:
        d = pd.read_csv(f"ref/{c}/extras2.csv"); d = d[d.analysis == lab]
    return {t: (np.log(float(d[d.term == t].HR.iloc[0])), (np.log(float(d[d.term == t].hi.iloc[0])) - np.log(float(d[d.term == t].lo.iloc[0]))) / (2 * 1.959964)) for t in TERMS}
for analysis in ["current (age a)", "lag 1 year (schooling reached at age a-1)"]:
    for frame_name, sel in [("Primary sample", lambda c: "aw" if c in have else "em"), ("Ever-married women", lambda c: "em")]:
        for t in TERMS:
            ys, ss = [], []
            for c in ORDER:
                y, s = est(c, sel(c), analysis)[t]; ys.append(y); ss.append(s)
            r = pool(np.array(ys), np.array(ss)); lagrows.append(dict(analysis=analysis, frame=frame_name, term=t, k=len(ys), HR=r["HR"], lo=r["hksj_lo"], hi=r["hksj_hi"], pi_lo=r["pi_lo"], pi_hi=r["pi_hi"]))
pd.DataFrame(lagrows).to_csv(OUT + "/pooled_lag_both_frames.csv", index=False)
print(pd.DataFrame(lagrows).round(3).to_string())
# ---------------------------------------------------------------- wave-specific and landmark, per country (primary frame for have, else ever-married)
w = []
for c in have:
    d = pd.read_csv(f"results/{c}/aw_extras.csv"); w.append(d)
if w: pd.concat(w).to_csv(OUT + "/aw_extras_all.csv", index=False)
print(pd.read_csv(OUT + "/absolute_risks_both_frames.csv").round(3).to_string())
