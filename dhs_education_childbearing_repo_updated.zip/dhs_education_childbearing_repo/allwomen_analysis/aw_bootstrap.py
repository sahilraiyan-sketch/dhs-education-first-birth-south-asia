"""All-women bootstrap (Model A, time-varying schooling, no marriage term) and standardised absolute risks, for India, Nepal, Myanmar.
Usage: python aw_bootstrap.py India 5 12 500   -> results/<country>/aw_stage1_final.csv, aw_absolute_risks.csv"""
import sys, os, inspect
sys.path.insert(0, os.getcwd())
import numpy as np, pandas as pd, dhs_engine as E
from pathlib import Path
country, prim, sec, B = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]); E.set_thresholds(prim, sec)
res = Path("results") / country; E._LOG["fh"] = open(res / "aw_run_log.txt", "a")
raw = pd.read_parquet(res / "cohort.parquet"); c = E.prepare(raw, False)          # ALL women
E.log(f"{country}: all women {len(c):,}, births before 20: {int(c['ev_age'].notna().sum()):,}")
E.run_bootstrap(c, res, B, "_aw", levels="A")
src = inspect.getsource(E.final_tables).replace('for lvl in ("A", "B"):', 'for lvl in ("A",):').replace("def final_tables", "def final_tables_A")
ns = dict(E.__dict__); exec(src, ns)
od = res / "allwomen_out"; od.mkdir(exist_ok=True)
fin, ar = ns["final_tables_A"](c, country, res, "_aw", outdir=od)
fin.to_csv(res / "aw_stage1_final.csv", index=False); ar.to_csv(res / "aw_absolute_risks.csv", index=False)
print(fin.round(3).to_string()); print(ar.round(4).to_string())
