"""Person-years and first births in the 'completed' state, by country and secondary-completion definition (10, 11 and 12 years).
Primary-analysis sample (ever-married women, first-birth outcome). Writes results/stage2/exposure_person_years.csv (Additional file 1, Table S19)."""
import os, sys
sys.path.insert(0, os.getcwd())
try: sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
except NameError: pass
import numpy as np, pandas as pd
import dhs_engine as E
SET = {"Bangladesh": (5, 10), "India": (5, 12), "Nepal": (5, 10), "Pakistan": (5, 10), "Afghanistan": (6, 12), "Myanmar": (5, 11), "Maldives": (7, 12)}
rows = []
for c, (prim, own) in SET.items():
    f = f"results/{c}/cohort.parquet"
    if not os.path.exists(f): continue
    E.set_thresholds(prim, own); P = E.expand(E.prepare(pd.read_parquet(f), True), 6)
    att, late, y, w = P["attained"], P["a"] >= 15, P["y"], P["wt"]; early = ~late
    base = dict(country=c, own_definition=own, women=len(np.unique(P["idx"])), py_early=int(early.sum()), py_late=int(late.sum()),
                py_early_prim_completed=int((early & (att >= prim)).sum()), births_early_prim_completed=int(y[early & (att >= prim)].sum()))
    for s in (10, 11, 12):
        m = late & (att >= s)
        rows.append(dict(base, secondary_years=s, is_own=(s == own), py_late_completed=int(m.sum()), pct_of_late_py=100 * m.sum() / late.sum(), births_late_completed=int(y[m].sum()),
                         women_late_completed=len(np.unique(P["idx"][m])), py_late_completed_weighted_pct=100 * w[m].sum() / w[late].sum()))
out = pd.DataFrame(rows); out.to_csv("results/stage2/exposure_person_years.csv", index=False)
print(out.drop(columns=["py_early", "py_late"]).round(1).to_string(index=False))
