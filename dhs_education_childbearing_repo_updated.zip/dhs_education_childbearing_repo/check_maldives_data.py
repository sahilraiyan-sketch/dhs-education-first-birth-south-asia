"""Run this first. Usage (from the folder that holds dhs_engine.py and the Maldives .dta/.zip files):  python check_maldives_data.py
It (1) finds the Maldives individual-recode files, (2) checks the variables the analysis needs, (3) shows the DHS education coding
(v133 years by v149 category) so the years that define completed primary / secondary schooling can be set, (4) shows the regions,
the sampling frame (all women or ever-married only) and the sample size, and (5) writes maldives_settings.json (edit it if the suggestion is wrong)."""
import os, sys, json
sys.path.insert(0, os.getcwd())
import numpy as np, pandas as pd, pyreadstat
from pathlib import Path
import cohorts_maldives as M
from dhs_engine import find_dta
base = os.getcwd(); stems = M._find_mv_stems(base)
if not stems: sys.exit("No file named like MV?IR??FL.dta (or a .zip containing one) was found under " + base)
need = ["v005","v007","v012","v021","v022","v024","v025","v133","v149","v190","v201","v212","v501","v511"]; prim, sec = {}, {}; ok = True
for stem in stems:
    path = find_dta(base, [stem]); cols = pyreadstat.read_dta(path, metadataonly=True)[1].column_names
    miss = [v for v in need if v not in cols]; print(f"\n=== {stem}: {path}\n  missing variables: {miss or 'none'}"); ok &= not [m for m in miss if m in ("v005","v012","v021","v133","v201","v212","v501","v024","v025","v190")]
    d, meta = pyreadstat.read_dta(path, usecols=[v for v in need if v in cols]); n_all = len(d)
    d["v133"] = pd.to_numeric(d["v133"], errors="coerce").where(lambda s: s < 90)
    print(f"  women in file: {n_all:,}; age range {int(d.v012.min())}-{int(d.v012.max())}; aged 20-29: {int(d.v012.between(20, 29).sum()):,}; interview year(s): {sorted(pd.to_numeric(d.v007, errors='coerce').dropna().unique())[:4]}")
    s = d[d.v012.between(20, 29)]; print(f"  among women aged 20-29: ever-married {100 * (s.v501 != 0).mean():.1f}% (all-women frame if clearly below 100%); ever had a birth {100 * (s.v201 > 0).mean():.1f}%; first birth before 20 {100 * ((s.v201 > 0) & (s.v212 < 20)).mean():.1f}%")
    print("  v133 (years of schooling) missing/DK:", int(s.v133.isna().sum()), "; v212 missing among mothers:", int(((s.v201 > 0) & s.v212.isna()).sum()))
    if "v149" in d:
        lab = meta.variable_value_labels.get("v149", {}); g = d.groupby("v149")["v133"].agg(["min", "max", "count"]); g.index = [f"{int(i)} {lab.get(i, '')}" for i in g.index]
        print("  DHS education level (v149) by years of schooling (v133):"); print(g.to_string())
        for k, v in d.groupby("v149")["v133"].min().items():
            nm = lab.get(k, "").lower()
            if "complete" in nm and "incomplete" not in nm and "primary" in nm: prim[stem] = int(v)
            if "complete" in nm and "incomplete" not in nm and "secondary" in nm: sec[stem] = int(v)
    lab = meta.variable_value_labels.get("v024", {}); print("  regions (v024):", {int(k): v for k, v in lab.items()})
    print("  region categories used in the models:", sorted(d["v024"].map(lab).fillna(d["v024"]).map(lambda x: M._region(x, {})).unique()))
    print("  wealth quintile (v190) counts:", d["v190"].value_counts().sort_index().to_dict(), "; residence (v025):", d["v025"].value_counts().sort_index().to_dict())
sug_p = max(set(prim.values()), key=list(prim.values()).count) if prim else 7; sug_s = max(set(sec.values()), key=list(sec.values()).count) if sec else 12
if len(set(prim.values())) > 1 or len(set(sec.values())) > 1: print("\nWARNING: the DHS education coding differs between surveys:", prim, sec)
st = dict(prim=sug_p, sec=sug_s, sec_alt=(10 if sug_s != 10 else None), region_map={}, gdp_pc_usd_current=None, legal_marriage_age=18)
out = Path(base) / "maldives_settings.json"
if out.exists(): print("\nmaldives_settings.json already exists: left unchanged:", json.load(open(out)))
else: json.dump(st, open(out, "w"), indent=1); print("\nSuggested settings written to maldives_settings.json:", st)
print("\nNOTE: primary completion at", sug_p, "years can first apply at age", 6 + sug_p, "(school entry at 6), so the ages 10-14 contrast is identified from that age onward.")
print("Check passed." if ok else "Some required variables are missing: send me this output.")
