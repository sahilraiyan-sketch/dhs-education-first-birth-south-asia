"""Cohort builders: raw DHS individual-recode files to one analysis table per country.
Each builder returns (DataFrame, info). Raw files are located by dhs_engine.find_dta."""
import os
from pathlib import Path
import numpy as np, pandas as pd, pyreadstat
from dhs_engine import find_dta, log

def _autonomy_media(d):
    for col, src in [("aut_hc", "v743a"), ("aut_pur", "v743b"), ("aut_vis", "v743d")]:
        d[col] = np.where(d[src].isna(), np.nan, d[src].isin([1, 2]).astype(float))
    d["aut_count"] = d[["aut_hc", "aut_pur", "aut_vis"]].sum(axis=1, skipna=True)
    d["aut_3cat"] = pd.cut(d["aut_count"], bins=[-0.1, 0.1, 1.1, 3.1], labels=["None", "Low", "High"])
    med = d[["v157", "v158", "v159"]]
    d["media_any_wk"] = (med >= 2).any(axis=1).astype(float); d.loc[med.isna().all(axis=1), "media_any_wk"] = np.nan
    return d

def _wife_beating(d):
    def wb(r):
        items = [r["v744a"], r["v744b"], r["v744c"], r["v744d"], r["v744e"]]
        if any(x == 1 for x in items): return 1
        if any(pd.isna(x) or x == 8 for x in items): return np.nan
        return 0
    return d.apply(wb, axis=1)

# ------------------------------------------------------------------ Bangladesh
def build_bangladesh(base):
    VARLIST = ["v130","v133","v005","v012","v021","v022","v024","v025","v106","v149","v151","v157","v158","v159","v190","v201","v212",
               "v364","v501","v511","v701","v714","v730","v743a","v743b","v743d","v744a","v744b","v744c","v744d","v744e","awfactt"]
    FILES = {2014: ["BDHS2014", "BDIR72FL"], 2018: ["BDHS2018", "BDIR7RFL", "BDHS2017"], 2022: ["BDHS2022", "BDIR81FL"]}
    waves = []
    for year, names in FILES.items():
        path = find_dta(base, names); log(f"Bangladesh {year}: {path}")
        df, meta = pyreadstat.read_dta(path, usecols=VARLIST)
        sub = df[(df["v012"] >= 20) & (df["v012"] <= 29)].copy(); sub["survey_year"] = year
        v212_capped = sub["v212"].where(sub["v212"].notna(), 20)
        sub["exit_age"] = np.where(sub["v201"] > 0, np.minimum(v212_capped, 20), 20)
        sub["event"] = ((sub["v201"] > 0) & (sub["v212"] < 20)).astype(int); sub["entry_age"] = 10
        sub["duration"] = sub["exit_age"] - sub["entry_age"]
        cond = [(sub["v201"] > 0) & (sub["v212"] < 15), (sub["v201"] > 0) & (sub["v212"] >= 15) & (sub["v212"] < 20)]
        sub["birth_timing"] = np.select(cond, ["before_15", "age_15_19"], default="none_by_20")
        sub["birth_cohort"] = year - sub["v012"]; sub["wt"] = sub["v005"] / 1_000_000
        sub["psu_p"] = sub["v021"].astype(str) + "_" + str(year); sub["strata_p"] = sub["v022"].astype(str) + "_" + str(year)
        sub["social_norm_bin"] = _wife_beating(sub)
        sub = _autonomy_media(sub)
        def edu_cat(v):
            if pd.isna(v): return np.nan
            if v in (0, 1, 2): return "primary_or_below"
            if v == 3: return "incomplete_secondary"
            if v in (4, 5): return "complete_secondary_or_higher"
            return np.nan
        sub["res_edu_cat"] = sub["v149"].apply(edu_cat)
        sub["partner_edu"] = sub["v701"].replace(8, np.nan)
        sub["wealth_index"] = sub["v190"]; sub["working_status"] = sub["v714"]; sub["hhead_sex"] = sub["v151"]
        div_name = sub["v024"].map(meta.variable_value_labels.get("v024", {}))
        div_name = div_name.replace({"chittagong": "chattogram", "barisal": "barishal"}).replace({"mymensingh": "dhaka"})   # Mymensingh merged into Dhaka for comparability
        sub["division"] = div_name; sub["residence"] = sub["v025"]
        rel = sub["v130"].map(meta.variable_value_labels.get("v130", {})).astype(str).str.strip().str.lower()
        sub["religion"] = np.where(rel.str.startswith("islam"), "muslim", np.where(rel.str.startswith("hindu"), "hindu", "other"))
        keep = ["survey_year","birth_cohort","duration","event","entry_age","exit_age","birth_timing","v133","v212","v511","v201","wt","psu_p","strata_p",
                "social_norm_bin","aut_3cat","aut_count","media_any_wk","res_edu_cat","partner_edu","wealth_index","working_status","hhead_sex","division",
                "residence","religion","v012"]
        waves.append(sub[keep])
    c = pd.concat(waves, ignore_index=True); c["v511"] = pd.to_numeric(c["v511"], errors="coerce")
    return c, dict(frame="Ever-married", waves="2014, 2017-18, 2022", ever_married_only_sample=True)

# ------------------------------------------------------------------ Nepal
def build_nepal(base):
    FILES = {2011: ["NPIR61FL"], 2016: ["NPIR7HFL"], 2022: ["NPIR82FL"]}
    VAR = ["v005","v012","v021","v022","v024","v025","v133","v151","v157","v158","v159","v190","v201","v212","v501","v511",
           "v701","v714","v743a","v743b","v743d","sdist","v131"]
    NAME = {"province 1": "koshi", "province 2": "madhesh province", "province 3": "bagmati province", "province 4": "gandaki province",
            "province 5": "lumbini province", "province 6": "karnali province", "province 7": "sudurpashchim province"}
    paths = {y: find_dta(base, n) for y, n in FILES.items()}
    d16, m16 = pyreadstat.read_dta(paths[2016], usecols=["sdist", "v024"])      # 2011 districts -> provinces via the 2016 survey
    d16["province"] = d16["v024"].map(m16.variable_value_labels.get("v024", {})).replace(NAME)
    xwalk = d16.groupby("sdist")["province"].agg(lambda x: x.value_counts().idxmax()).to_dict()
    parts = []
    for yr, p in paths.items():
        d, meta = pyreadstat.read_dta(p, usecols=VAR); d = d[(d["v012"] >= 20) & (d["v012"] <= 29)].copy()
        d["ethnicity"] = d["v131"].map(meta.variable_value_labels.get("v131", {})).astype(str).str.strip().str.lower().replace({"other": "other"})
        d["survey_year"] = yr; d["ever_married"] = (d["v501"] != 0).astype(int); d["wt"] = d["v005"] / 1e6
        d["psu_p"] = d["v021"].astype(str) + "_" + str(yr); d["strata_p"] = d["v022"].astype(str) + "_" + str(yr)
        d["division"] = d["sdist"].map(xwalk) if yr == 2011 else d["v024"].map(meta.variable_value_labels.get("v024", {})).replace(NAME)
        d["residence"] = d["v025"]; d["wealth_index"] = d["v190"]; d["hhead_sex"] = d["v151"]
        d = _autonomy_media(d)
        d["partner_edu"] = pd.to_numeric(d["v701"], errors="coerce").replace(8, np.nan); d["working_status"] = pd.to_numeric(d["v714"], errors="coerce")
        for col in ["v511", "v133", "v212", "v201"]: d[col] = pd.to_numeric(d[col], errors="coerce")
        parts.append(d)
    c = pd.concat(parts, ignore_index=True)
    keep = ["survey_year","wt","psu_p","strata_p","division","residence","wealth_index","hhead_sex","aut_3cat","media_any_wk","partner_edu",
            "working_status","ethnicity","v012","v133","v201","v212","v501","v511","ever_married","v005"]
    return c[keep], dict(frame="All women", waves="2011, 2016, 2022", ever_married_only_sample=False)

# ------------------------------------------------------------------ Pakistan
def build_pakistan(base):
    FILES = {2006: (["PKIR53FL"], "v131"), 2012: (["PKIR61FL"], "v131"), 2017: (["PKIR71FL"], "s121a")}
    VAR = ["v005","v012","v021","v022","v024","v025","v133","v151","v157","v158","v159","v190","v201","v212","v501","v511",
           "v701","v714","v743a","v743b","v743d"]
    NORM = {"nwfp": "kpk", "khyber pakhtunkhwa": "kpk", "fata": "kpk", "islamabad (ict)": "ict islamabad", "ict": "ict islamabad"}
    EXCLUDE = {"gilgit baltistan", "gb", "ajk"}
    TONGUE = {"punjabi": "punjabi", "pushto": "pashto", "sindhi": "sindhi", "siraiki": "siraiki", "urdu": "urdu", "balochi": "balochi",
              "hindko": "hindko", "barauhi": "brahui"}
    parts = []
    for yr, (names, tv) in FILES.items():
        d, meta = pyreadstat.read_dta(find_dta(base, names), usecols=VAR + [tv]); d = d[(d["v012"] >= 20) & (d["v012"] <= 29)].copy()
        d["division"] = d["v024"].map(meta.variable_value_labels.get("v024", {})).astype(str).str.strip().str.lower().replace(NORM)
        d = d[~d["division"].isin(EXCLUDE)].copy()
        t = d[tv].map(meta.variable_value_labels.get(tv, {})).astype(str).str.strip().str.lower()
        d["ethnicity"] = t.map(TONGUE).fillna("other")          # mother tongue (no religion question in the Pakistan files)
        d["survey_year"] = yr; d["wt"] = d["v005"] / 1e6
        d["psu_p"] = d["v021"].astype(str) + "_" + str(yr); d["strata_p"] = d["v022"].astype(str) + "_" + str(yr)
        d = _autonomy_media(d)
        d.loc[d[["v743a", "v743b", "v743d"]].isna().all(axis=1), "aut_3cat"] = np.nan
        d["partner_edu"] = pd.to_numeric(d["v701"], errors="coerce").replace([8, 9], np.nan)
        d["working_status"] = pd.to_numeric(d["v714"], errors="coerce").replace(9, np.nan)
        d["residence"] = d["v025"]; d["wealth_index"] = d["v190"]; d["hhead_sex"] = d["v151"]
        for col in ["v511", "v133", "v212", "v201"]: d[col] = pd.to_numeric(d[col], errors="coerce")
        parts.append(d)
    c = pd.concat(parts, ignore_index=True)
    keep = ["survey_year","wt","psu_p","strata_p","division","residence","wealth_index","hhead_sex","partner_edu","working_status","ethnicity",
            "v012","v133","v201","v212","v511","v005"]          # media/autonomy omitted from the headline model (not asked in 2006-07)
    return c[keep], dict(frame="Ever-married", waves="2006-07, 2012-13, 2017-18", ever_married_only_sample=True)

# ------------------------------------------------------------------ Afghanistan
def build_afghanistan(base):
    VAR = ["v005","v012","v021","v022","v024","v025","v133","v149","v151","v157","v158","v159","v190","v201","v212","v501","v511",
           "v701","v714","v743a","v743b","v743d","v744a","v744b","v744c","v744d","v744e","v131"]
    d, meta = pyreadstat.read_dta(find_dta(base, ["AFIR71FL"]), usecols=VAR); d = d[(d["v012"] >= 20) & (d["v012"] <= 29)].copy()
    for col in ["v212", "v511", "v133", "v201"]: d[col] = pd.to_numeric(d[col], errors="coerce")
    d["survey_year"] = 2015; d["wt"] = d["v005"] / 1e6
    d["psu_p"] = d["v021"].astype(str) + "_2015"; d["strata_p"] = d["v022"].astype(str) + "_2015"
    d["division"] = d["v024"].map(meta.variable_value_labels.get("v024", {})).astype(str).str.strip().str.lower()
    d["ethnicity"] = d["v131"].map(meta.variable_value_labels.get("v131", {})).astype(str).str.strip().str.lower().replace({"nan": "other"})
    d["social_norm_bin"] = _wife_beating(d); d = _autonomy_media(d)
    d.loc[d[["v743a", "v743b", "v743d"]].isna().all(axis=1), "aut_3cat"] = np.nan
    d["partner_edu"] = pd.to_numeric(d["v701"], errors="coerce").replace(8, np.nan); d["working_status"] = pd.to_numeric(d["v714"], errors="coerce")
    d["residence"] = d["v025"]; d["wealth_index"] = d["v190"]; d["hhead_sex"] = d["v151"]
    keep = ["survey_year","wt","psu_p","strata_p","division","residence","wealth_index","hhead_sex","aut_3cat","media_any_wk","partner_edu",
            "working_status","social_norm_bin","ethnicity","v012","v133","v149","v201","v212","v511","v005"]
    return d[keep], dict(frame="Ever-married", waves="2015", ever_married_only_sample=True)

# ------------------------------------------------------------------ Myanmar
def build_myanmar(base):
    VAR = ["v005","v012","v021","v022","v024","v025","v133","v149","v151","v157","v158","v159","v190","v201","v212","v501","v511",
           "v701","v714","v743a","v743b","v743d","v744a","v744b","v744c","v744d","v744e","v045c"]
    d, meta = pyreadstat.read_dta(find_dta(base, ["MMIR71FL"]), usecols=VAR); d = d[(d["v012"] >= 20) & (d["v012"] <= 29)].copy()
    for col in ["v212", "v511", "v133", "v201"]: d[col] = pd.to_numeric(d[col], errors="coerce")
    d["ever_married"] = (d["v501"] != 0).astype(int); d["survey_year"] = 2015; d["wt"] = d["v005"] / 1e6
    d["psu_p"] = d["v021"].astype(str) + "_2015"; d["strata_p"] = d["v022"].astype(str) + "_2015"
    d["division"] = d["v024"].map(meta.variable_value_labels.get("v024", {})).astype(str).str.strip().str.lower()
    lang = d["v045c"].map(meta.variable_value_labels.get("v045c", {})).astype(str).str.strip().str.lower()
    d["ethnicity"] = np.where(lang == "myanmar", "myanmar", "other_language")     # native language: only analogue available (religion/ethnicity blank)
    d["social_norm_bin"] = _wife_beating(d); d = _autonomy_media(d)
    d.loc[d[["v743a", "v743b", "v743d"]].isna().all(axis=1), "aut_3cat"] = np.nan
    d["partner_edu"] = pd.to_numeric(d["v701"], errors="coerce").replace(8, np.nan); d["working_status"] = pd.to_numeric(d["v714"], errors="coerce")
    d["residence"] = d["v025"]; d["wealth_index"] = d["v190"]; d["hhead_sex"] = d["v151"]
    keep = ["survey_year","wt","psu_p","strata_p","division","residence","wealth_index","hhead_sex","aut_3cat","media_any_wk","partner_edu",
            "working_status","social_norm_bin","ethnicity","ever_married","v012","v133","v149","v201","v212","v511","v005"]
    return d[keep], dict(frame="All women", waves="2015-16", ever_married_only_sample=False)

# ------------------------------------------------------------------ India (large files are read in chunks)
def build_india(base):
    FILES = {2006: ["IAIR52FL"], 2016: ["IAIR74FL"], 2020: ["IAIR7EFL"]}
    VAR0 = ["v005","v012","v021","v022","v024","v025","v133","v151","v157","v158","v159","v190","v201","v212","v501","v511",
            "v743a","v743b","v743d","v130","s116","s117","s118"]
    NORM = {"uttaranchal": "uttarakhand", "orissa": "odisha", "nct of delhi": "delhi", "telangana": "andhra pradesh", "ladakh": "jammu and kashmir"}
    parts = []
    for yr, names in FILES.items():
        path = find_dta(base, names); log(f"India {yr}: reading {path} in chunks (this takes a few minutes)")
        allcols = pyreadstat.read_dta(path, metadataonly=True)[1].column_names
        VAR = [v for v in VAR0 if v in allcols]
        _, meta = pyreadstat.read_dta(path, metadataonly=True, usecols=VAR)
        ch = []
        for chunk, _m in pyreadstat.read_file_in_chunks(pyreadstat.read_dta, path, chunksize=200000, usecols=VAR):
            ch.append(chunk[(chunk["v012"] >= 20) & (chunk["v012"] <= 29)].copy())
        d = pd.concat(ch, ignore_index=True); del ch
        if "_extracted" in Path(path).parts:        # the unzipped file is several GB: delete it once read (the cohort is cached in results/India/cohort.parquet)
            try: os.remove(path)
            except OSError: pass
        d["state_label"] = d["v024"].map(meta.variable_value_labels.get("v024", {}))
        for cc in ("v130", "s116", "s117", "s118"):
            if cc in d.columns: d[cc + "_lab"] = d[cc].map(meta.variable_value_labels.get(cc, {}))
        for col in ["v511", "v133", "v212", "v201", "v501", "v012"]: d[col] = pd.to_numeric(d[col], errors="coerce")
        d["survey_year"] = yr; d["ever_married"] = (d["v501"] != 0).astype(int); d["wt"] = d["v005"] / 1e6
        d["psu_p"] = (d["v022"] if yr == 2006 else d["v021"]).astype(str) + "_" + str(yr)    # NFHS-3 has no PSU variable in this file: stratum used
        d["strata_p"] = d["v022"].astype(str) + "_" + str(yr)
        st = d["state_label"].str.strip().str.lower().str.replace(r"^\[.*?\]\s*", "", regex=True).str.replace(" & ", " and ", regex=False)
        d["division"] = st.replace(NORM)
        d["residence"] = d["v025"]; d["wealth_index"] = d["v190"]; d["hhead_sex"] = d["v151"]
        d = _autonomy_media(d)
        rel = d["v130_lab"].astype(str).str.lower()
        d["religion"] = np.select([rel == "hindu", rel == "muslim", rel == "christian", rel == "sikh"], ["hindu", "muslim", "christian", "sikh"], "other")
        if yr == 2006:   # NFHS-3: s117 (caste/tribe/none) + s118 (type SC/ST/OBC; blank = general)
            t = d["s118_lab"].fillna("missing").astype(str).str.lower(); c1 = d["s117_lab"].fillna("missing").astype(str).str.lower()
            d["ethnicity"] = np.select([t.str.contains("scheduled caste"), t.str.contains("scheduled tribe"), t.str.contains("other backward"),
                                        c1.isin(["caste", "tribe", "no caste/tribe"]), c1.str.contains("know")], ["sc", "st", "obc", "general_other", "unknown"], "unknown")
        else:            # NFHS-4/5: s116
            t = d["s116_lab"].fillna("missing").astype(str).str.lower()
            d["ethnicity"] = np.select([t.str.contains("caste"), t.str.contains("tribe"), t.str.startswith("obc"), t.str.startswith("none")],
                                       ["sc", "st", "obc", "general_other"], "unknown")
        keep = ["survey_year","wt","psu_p","strata_p","division","residence","wealth_index","hhead_sex","aut_3cat","media_any_wk",
                "religion","ethnicity","v012","v133","v201","v212","v501","v511","ever_married","v005"]
        parts.append(d[keep]); del d
    c = pd.concat(parts, ignore_index=True)
    return c, dict(frame="All women", waves="2005-06, 2015-16, 2019-21", ever_married_only_sample=False)


import re, json, zipfile
# ------------------------------------------------------------------ Maldives
"""Maldives cohort builder (appended to cohorts.py by apply_maldives_patch.py).
The Maldives DHS surveys sampled ALL women aged 15-49 (not only ever-married women), like India, Nepal and Myanmar.
Individual-recode files: MVIR51FL (2009) and MVIR71FL (2016-17). File names are found by pattern (MV?IR??FL), so a different suffix is fine.
Cultural-group covariate: none (the country is almost entirely one religion and the recodes have no ethnicity variable), so Model A adjusts for region and residence only."""

_MV = re.compile(r"^mv.?ir..fl$", re.I)

def _find_mv_stems(base):
    base = Path(base); skip = {"results", "figures", "_extracted"}; stems = {}
    for p in base.rglob("*"):
        if p.is_file() and not (skip & set(p.relative_to(base).parts)):
            if p.suffix.lower() == ".dta" and _MV.match(p.stem): stems[p.stem.upper()] = str(p)
            elif p.suffix.lower() == ".zip":
                try:
                    for m in zipfile.ZipFile(p).namelist():
                        pm = Path(m)
                        if pm.suffix.lower() == ".dta" and _MV.match(pm.stem): stems.setdefault(pm.stem.upper(), str(p))
                except Exception: pass
    return sorted(stems)

def _year(v007):
    v = pd.to_numeric(v007, errors="coerce").dropna()
    y = int(v.min()) if len(v) else 0
    return y + (1900 if y < 100 and y > 30 else 2000 if y < 100 else 0)

def _settings(base):
    f = Path(base) / "maldives_settings.json"
    return json.load(open(f)) if f.exists() else {}

def _region(label, rmap):
    s = re.sub(r"[^a-z ]", "", str(label).lower().replace("'", "")).strip()
    if s in rmap: return rmap[s]
    if "male" in s: return "male"
    return s or "unknown"

def build_maldives(base):
    stems = _find_mv_stems(base)
    if not stems: raise FileNotFoundError("No Maldives individual-recode file (MV?IR??FL.dta or a .zip containing it) found under " + str(base))
    log("Maldives files found: " + ", ".join(stems)); rmap = {k.lower(): v for k, v in _settings(base).get("region_map", {}).items()}
    WANT = ["v005","v007","v012","v021","v022","v024","v025","v133","v149","v151","v190","v201","v212","v501","v511"]
    parts, years = [], []
    for stem in stems:
        path = find_dta(base, [stem]); allcols = pyreadstat.read_dta(path, metadataonly=True)[1].column_names
        VAR = [v for v in WANT if v in allcols]; d, meta = pyreadstat.read_dta(path, usecols=VAR)
        d = d[(d["v012"] >= 20) & (d["v012"] <= 29)].copy()
        yr = _year(d["v007"]) if "v007" in d else 0; years.append((yr, int(pd.to_numeric(d["v007"], errors="coerce").max()) if "v007" in d else yr))
        for col in ["v212", "v511", "v133", "v201", "v501"]:
            d[col] = pd.to_numeric(d[col], errors="coerce") if col in d else np.nan
        d["survey_year"] = yr; d["ever_married"] = (d["v501"].fillna(0) != 0).astype(int); d["wt"] = d["v005"] / 1e6
        if "v022" not in d: d["v022"] = d["v024"].astype(str) + "_" + d["v025"].astype(str)
        d["psu_p"] = d["v021"].astype(str) + "_" + str(yr); d["strata_p"] = d["v022"].astype(str) + "_" + str(yr)
        lab = meta.variable_value_labels.get("v024", {}); d["division"] = d["v024"].map(lab).fillna(d["v024"]).map(lambda x: _region(x, rmap))
        d["residence"] = d["v025"].astype(int); d["wealth_index"] = d["v190"].astype(int)
        d["hhead_sex"] = pd.to_numeric(d["v151"], errors="coerce").fillna(1).astype(int) if "v151" in d else 1
        if "v149" not in d: d["v149"] = np.nan
        log(f"Maldives {stem}: year {yr}, {len(d):,} women aged 20-29, regions: {sorted(d['division'].unique())}")
        parts.append(d[["survey_year","wt","psu_p","strata_p","division","residence","wealth_index","hhead_sex","ever_married","v012","v133","v149","v201","v212","v511","v005"]])
    c = pd.concat(parts, ignore_index=True)
    waves = ", ".join(f"{y}-{str(m)[2:]}" if m > y else str(y) for y, m in sorted(years))
    return c, dict(frame="All women", waves=waves, ever_married_only_sample=False)
