# Maldives (seventh country)

Surveys: MDHS 2009 (MVIR52FL; ever-married women only in the file) and MDHS 2016-17 (MVIR71FL; all women 15-49). Women aged 20-29.
Settings (maldives_settings.json): completed primary 7 years, completed secondary 12 years (DHS v149), harmonized sensitivity 10 years; atoll groupings collapsed to north / central (incl. Male) / south because they were redrawn between surveys; no cultural-group covariate.

Order of steps (from the repository root, with the DHS files placed under data/):
1. python check_maldives_data.py; python apply_maldives_patch.py .; python maldives_early_exclusion_patch.py .
2. python run_maldives.py   (Stage 1, bootstrap 1,000, absolute risks, sensitivity)
3. python aw_bootstrap.py Maldives 7 12 1000; python aw_extras.py Maldives 7 12; python extras2.py Maldives 7 12; python aw_harmonized10.py Maldives 7  (aw_* scripts are in allwomen_analysis/; copy next to dhs_engine.py)
4. python allwomen_analysis/build_cohorts.py India / Myanmar and python aw_harmonized10.py India 5 / Myanmar 5 (needed for the harmonized primary-sample row)
5. python integrate_maldives.py   (Stage 2 pooling, marriage pooling, primary-sample pooling, bias-analysis grid)
6. cd bias_analysis; python run_qba_grid2.py "0,0.25,0.5,0.75,1" "0,0.5,1,1.5,2,2.5,3" "0,0.25,0.5,0.75,1" qba_grid_m.csv; python qba_pool2.py; python qba_prob2.py
   (finer births-only grid: run_qba_grid.py; qba_pool.py; qba_prob.py)
7. python make_seven_country_outputs.py --old-tables <six-country tables> --out out7
8. python stage2_metareg.R and stage2_validate.R via run_stage2.py --only-r (the one-stage mixed model needs the person-year cells of all countries and was not rerun for seven countries)

Decisions: the ages 10-14 (completed primary) contrast is not estimable in the Maldives (13 first births before age 15; CI 0.05 to >100,000), so the Maldives is excluded from that pooled contrast and its bias adjustment (maldives_early_exclusion_patch.py). Severe marriage scenario: p=1, m=0.75, lag 0.5 year (lag 1 year has no solution for the Maldives). The lag-only and marriage-only scenarios have no solution for the Maldives. 12 years of schooling is first assigned at age 18, so the Maldives completed-secondary hazard ratio (0.02-0.03) is an extreme estimate based on 17 first births in that state.
