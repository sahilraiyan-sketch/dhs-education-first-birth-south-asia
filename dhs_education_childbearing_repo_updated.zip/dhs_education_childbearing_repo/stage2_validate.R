# Validates the Python pooling (pooling.py) against R metafor on the same inputs. Reads results/stage2/stage1_all_primary.csv.
if (!requireNamespace("metafor", quietly = TRUE)) install.packages("metafor", repos = "https://cloud.r-project.org")
suppressMessages(library(metafor))
d <- read.csv("results/stage2/stage1_all_primary.csv"); d <- d[d$model == "A", ]
core <- c("Bangladesh", "India", "Nepal", "Pakistan"); out <- NULL
for (term in unique(d$term)) for (set in c("all", "core")) {
  x <- d[d$term == term, ]; if (set == "core") x <- x[x$country %in% core, ]; x <- x[order(x$country), ]
  a <- rma(yi = x$logHR, sei = x$se_boot, method = "REML", test = "adhoc"); p <- predict(a, transf = exp)
  out <- rbind(out, data.frame(term = term, set = set, k = nrow(x), HR = p$pred, ci_lo = p$ci.lb, ci_hi = p$ci.ub, pi_lo = p$pi.lb, pi_hi = p$pi.ub, tau = sqrt(a$tau2), I2 = a$I2))
}
write.csv(out, "results/stage2/metafor_validation.csv", row.names = FALSE); print(format(out, digits = 4), row.names = FALSE)
