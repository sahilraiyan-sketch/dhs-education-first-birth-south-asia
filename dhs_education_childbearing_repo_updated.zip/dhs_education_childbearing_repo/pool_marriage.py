"""Pools the first-marriage hazard ratios (written by extras2.py) across the countries that sampled ALL women (India, Nepal, Myanmar).
Bangladesh, Pakistan and Afghanistan sampled ever-married women only, so their first-marriage hazard is conditional on having married by
the survey: it is reported for description and not pooled. Writes results/stage2/marriage_by_country.csv, marriage_pooled.csv and table5_marriage.csv."""
import os, sys
from pathlib import Path
sys.path.insert(0, os.getcwd())
try: sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
except NameError: pass
import numpy as np, pandas as pd
from pooling import pool
ORDER = ["Bangladesh", "India", "Nepal", "Pakistan", "Afghanistan", "Myanmar", "Maldives"]; TERMS = ["early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv"]
R = Path(os.getcwd()) / "results"; OUT = R / "stage2"; OUT.mkdir(parents=True, exist_ok=True)
rows, bbm, dropped = [], {}, {}
for c in ORDER:
    f = R / c / "extras2.csv"
    if not f.exists(): print(f"  {c}: extras2.csv missing, skipped"); continue
    d = pd.read_csv(f); m = d[d.outcome == "marriage"].copy()
    m["schooling"] = np.where(m.analysis.str.contains("lag 1"), "lag1", "current"); m["sample"] = np.where(m.analysis.str.contains("all women"), "all women", "ever-married only")
    rows.append(m[["country", "schooling", "sample", "term", "HR", "lo", "hi", "logHR", "se", "events", "n_rows"]])
    bbm[c] = float(d[d.analysis == "share of first births before 20 before marriage (weighted %)"].HR.iloc[0])
    dropped[c] = int(d[d.analysis.str.startswith("ever-married women dropped")].HR.iloc[0])
M = pd.concat(rows, ignore_index=True); M.to_csv(OUT / "marriage_by_country.csv", index=False)
pooled = []
for sch in ("current", "lag1"):
    for t in TERMS:
        s = M[(M.schooling == sch) & (M.term == t) & (M["sample"] == "all women")].sort_values("country"); s = s[~((s.country == "Maldives") & s.term.str.startswith("early"))]
        if len(s) < 3: continue
        r = pool(s.logHR.values, s.se.values); r.update(schooling=sch, term=t, countries=", ".join(s.country)); pooled.append(r)
P = pd.DataFrame(pooled); P.to_csv(OUT / "marriage_pooled.csv", index=False)
cur = M[M.schooling == "current"]; lines = []
for c in ORDER:
    g = cur[cur.country == c]
    if g.empty: continue
    lines.append(dict(country=c, sample=g["sample"].iloc[0], **{t: ("n.e." if (c == "Maldives" and t.startswith("early")) else f"{g[g.term == t].HR.iloc[0]:.2f} ({g[g.term == t].lo.iloc[0]:.2f}, {g[g.term == t].hi.iloc[0]:.2f})") for t in TERMS}, births_before_marriage_pct=round(bbm[c], 1), dropped_missing_v511=dropped[c]))
pr = P[P.schooling == "current"].set_index("term")
lines.append(dict(country="Pooled (all-women countries: " + pr.countries.iloc[0] + ")", sample="", **{t: f"{pr.loc[t, 'HR']:.2f} ({pr.loc[t, 'hksj_lo']:.2f}, {pr.loc[t, 'hksj_hi']:.2f})" for t in TERMS}))
pd.DataFrame(lines).to_csv(OUT / "table5_marriage.csv", index=False)
print(pd.DataFrame(lines).to_string(index=False)); print("births before marriage range: %.1f to %.1f%%" % (min(bbm.values()), max(bbm.values())))
print(P[["schooling", "term", "HR", "hksj_lo", "hksj_hi", "pi_lo", "pi_hi", "tau", "I2"]].round(3).to_string(index=False))
