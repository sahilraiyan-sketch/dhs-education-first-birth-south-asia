# Education and adolescent childbearing in seven South Asian and adjacent countries

Code for a two-stage analysis of Demographic and Health Survey (DHS) data from Bangladesh, India, Nepal, Pakistan, Afghanistan and Myanmar.


## Data
The DHS individual-recode files are not included because DHS data cannot be redistributed. 

| Country | Surveys (file stem) |
|---|---|
| Bangladesh | BDHS2014, BDHS2018, BDHS2022 (or BDIR72FL, BDIR7RFL, BDIR81FL) |
| India | IAIR52FL, IAIR74FL, IAIR7EFL |
| Nepal | NPIR61FL, NPIR7HFL, NPIR82FL |
| Pakistan | PKIR53FL, PKIR61FL, PKIR71FL |
| Afghanistan | AFIR71FL |
| Myanmar | MMIR71FL |


## Run order
```
python check_setup.py
python run_myanmar.py
python run_afghanistan.py
python run_nepal.py
python run_pakistan.py
python run_bangladesh.py
python run_india.py
python run_stage2.py
python run_extras.py        # first-marriage models, births before marriage, lag/wave checks, exposure person-years (needs the Stage-1 cohort files)
python check_prose_numbers.py
```
`run_extras.py` runs `extras2.py` for each country, pools the first-marriage hazard ratios over the all-women countries (`pool_marriage.py`) and tabulates exposure person-years (`exposure_person_years.py`). Run `run_stage2.py` first or after, as you like; `check_prose_numbers.py` reads both.

## Files
| File | Purpose |
|---|---|
| `dhs_engine.py` | Person-period expansion, weighted complementary log-log model, cluster bootstrap, specifications, absolute risks, figures |
| `cohorts.py` | Cohort builders for the seven countries |
| `pooling.py` | REML pooling with Hartung-Knapp-Sidik-Jonkman intervals and prediction intervals |
| `run_<country>.py` | One script per country |
| `run_stage2.py` | Pooling, tables, figures, and the manuscript number checks |
| `stage2_validate.R`, `stage2_metareg.R`, `stage2_onestage.R` | Pooling check against metafor, exploratory meta-regression, one-stage mixed model |
| `extras2.py` | Per country: lag-1 and wave-specific hazard ratios, first-marriage hazard, share of first births before 20 outside marriage, wealth benchmark. Ever-married women with missing age at first marriage are dropped from the marriage analyses |
| `run_extras.py` | Runs `extras2.py` for the seven countries, then `pool_marriage.py` and `exposure_person_years.py` |
| `pool_marriage.py` | Pools the first-marriage hazard ratios over the countries that sampled all women (India, Nepal, Myanmar); the other three countries are descriptive. Writes Table 5 inputs |
| `exposure_person_years.py` | Person-years and first births in the completed-secondary state for 10, 11 and 12 years (Additional file 1, Table S19) |
| `check_prose_numbers.py`, `expected_values.csv` | Recompute numbers quoted in the earlier six-country manuscript (175 checks). Not updated for the seven-country version: for the Maldives and the current manuscript numbers, use the result files in `reference_results/` and `bias_analysis/` and `make_seven_country_outputs.py`, which writes `numbers_for_text.json` |
| `manuscript/` | `build_docx.py` (LaTeX to Word with native equations and Vancouver references), `make_strobe_checklist.py`, and the LaTeX source of the submitted manuscript |
| `independent_check_modelA.R` | Separate R implementation of Model A for Myanmar and Nepal |

## Outputs
`results/<Country>/` holds the hazard ratios (`stage1_final.csv`), absolute risks, specifications, landmark and all-women analyses, bootstrap draws and a run log. `results/stage2/` holds the pooled estimates, tables and check files. Figures are written to `figures/`.

## Settings
Years of schooling that define primary and secondary completion are set at the top of each country script: Bangladesh, Nepal and Pakistan 5 and 10; India 5 and 12; Afghanistan 6 and 12; Myanmar 5 and 11. The random seed for the bootstrap is fixed in `dhs_engine.py`.

`reference_results/` contains the summary tables produced by the final runs, for comparison with a new run.

## Changes in the October 2026 revision
- **Missing age at first marriage.** In BDHS 2022 all marriage variables are missing for about a third of ever-married women (3,383), and in NFHS-4 2016 for 4,047 (2.2%). The earlier `extras2.py` read a missing v511 as "never married" in the first-marriage hazard and as "birth before marriage". Those women are now dropped. Effects: Bangladesh first-marriage HR for completed secondary 0.52 to 0.42, births before marriage 13.4% to 0.9%; India 2.9% to 1.9%. The range over the six countries without the Maldives is 0.7 to 3.8% (Maldives 12.4%). The birth models and the marriage-adjusted birth models were not affected (the latter already excluded missing v511).
- **Pooling of the marriage hazard.** Only countries that sampled all women (India, Nepal, Myanmar) are pooled. Bangladesh, Pakistan and Afghanistan sampled ever-married women only, so their first-marriage hazard is conditional on having married and is descriptive.
- **New outputs.** `results/stage2/marriage_by_country.csv`, `marriage_pooled.csv`, `table5_marriage.csv`, `exposure_person_years.csv`; `results/<Country>/extras2.csv`. Reference copies are in `reference_results/`.
- **Manuscript tooling.** `manuscript/` holds the Word build and STROBE checklist generator. Table numbers in the manuscript follow order of appearance (marriage is Table 4, pooled estimates Table 5).

## Citation

If you use this code, please cite the archived release:

> sahilraiyan-sketch. (2026). sahilraiyan-sketch/dhs-education-first-birth-south-asia: v1.0.0: code as submitted to BMC Public Health (Version v1.0.0) [Computer software]. Zenodo. https://doi.org/10.5281/zenodo.23431854

Repository: https://github.com/sahilraiyan-sketch/dhs-education-first-birth-south-asia

## Supplementary table S17

`make_s17.py <repo_dir> <results/stage2 dir> <out.csv>` regenerates Additional file 1, sheet S17 (pooled Model A and B, ever-married and all-women versions, Q-profile CIs for tau) from the stage 1 and all-women results.

## Revision 2: primary analysis in all women, and quantitative bias analysis (`bias_analysis/`)
Run the scripts from inside `bias_analysis/` (they read `reference_results/` in the parent folder).
- `primary_allwomen.py`: builds the primary country estimates (all women in India, Nepal, Myanmar; ever-married women in Bangladesh, Pakistan, Afghanistan) next to the ever-married estimates, and pools them (`pooled_primary_allwomen.csv`, `loo_primary_allwomen.csv`, `country_primary.csv`). Reproduces the pooled values in Table 3 of the manuscript.
- `qba_sim.py`, `qba_inputs.py`: expected-value simulation of the bias from births that end schooling (probability p) when real progression lags the assumed one grade per year (mean lag, years). Inputs are published country quantities in `reference_results/` (cumulative incidence by 15 and 20 in women with no schooling, person-year shares in `exposure_person_years.csv`, Model A country estimates). No microdata are needed.
- `run_qba_grid.py p_list lag_list out.csv`: solves each country for each (p, lag). Example: `python3 run_qba_grid.py 0,0.25,0.375,0.5,0.625,0.75,0.875,1 0,0.25,0.5,0.75,1,1.25,1.5,1.75,2,2.25,2.5,3 qba_grid_fine.csv` (about 5 minutes on 2 cores). Cells without a solution are flagged and left blank in Additional file 1, Table S20.
- `qba_pool.py` pools the bias-adjusted country estimates (`qba_pooled_fine.csv`, Additional file 1, Table S21a); `qba_prob.py` runs the probabilistic analysis (`qba_probabilistic_fine.csv`, Table S21b; seed 20261019, 4,000 accepted draws).
The absolute risks, survey-round, lagged and landmark analyses need the DHS microdata and remain in ever-married women.


## Maldives (seventh country)
See MALDIVES.md for the added scripts (check_maldives_data.py, apply_maldives_patch.py, maldives_early_exclusion_patch.py, run_maldives.py, integrate_maldives.py, make_seven_country_outputs.py, aw_harmonized10.py) and the order in which to run them. Results are in reference_results/Maldives and the pooled files in reference_results/stage2 and bias_analysis/.
