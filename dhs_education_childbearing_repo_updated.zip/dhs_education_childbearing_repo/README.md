# Education and adolescent childbearing in six South Asian and adjacent countries

Code for a two-stage analysis of Demographic and Health Survey (DHS) data from Bangladesh, India, Nepal, Pakistan, Afghanistan and Myanmar.


## Data
The DHS individual-recode files are not included because DHS data cannot be redistributed. 

| Country | Surveys (file stem) |
|---|---|
| Bangladesh | BDHS2014, BDHS2018, BDHS2022 (or BDIR72FL, BDIR7RFL, BDIR81FL) |
| India | IAIR52FL, IAIR74FL, IAIR7EFL |
| Nepal | NPIR61FL, NPIR7HFL, NPIR82FL |
| Pakistan | PKIR53FL, PKIR61FL, PKIR71FL |
| Afghanistan | AFIR71FL |
| Myanmar | MMIR71FL |


## Run order
```
python check_setup.py
python run_myanmar.py
python run_afghanistan.py
python run_nepal.py
python run_pakistan.py
python run_bangladesh.py
python run_india.py
python run_stage2.py
python run_extras.py        # first-marriage models, births before marriage, lag/wave checks, exposure person-years (needs the Stage-1 cohort files)
python check_prose_numbers.py
```
`run_extras.py` runs `extras2.py` for each country, pools the first-marriage hazard ratios over the all-women countries (`pool_marriage.py`) and tabulates exposure person-years (`exposure_person_years.py`). Run `run_stage2.py` first or after, as you like; `check_prose_numbers.py` reads both.

## Files
| File | Purpose |
|---|---|
| `dhs_engine.py` | Person-period expansion, weighted complementary log-log model, cluster bootstrap, specifications, absolute risks, figures |
| `cohorts.py` | Cohort builders for the six countries |
| `pooling.py` | REML pooling with Hartung-Knapp-Sidik-Jonkman intervals and prediction intervals |
| `run_<country>.py` | One script per country |
| `run_stage2.py` | Pooling, tables, figures, and the manuscript number checks |
| `stage2_validate.R`, `stage2_metareg.R`, `stage2_onestage.R` | Pooling check against metafor, exploratory meta-regression, one-stage mixed model |
| `extras2.py` | Per country: lag-1 and wave-specific hazard ratios, first-marriage hazard, share of first births before 20 outside marriage, wealth benchmark. Ever-married women with missing age at first marriage are dropped from the marriage analyses |
| `run_extras.py` | Runs `extras2.py` for the six countries, then `pool_marriage.py` and `exposure_person_years.py` |
| `pool_marriage.py` | Pools the first-marriage hazard ratios over the countries that sampled all women (India, Nepal, Myanmar); the other three countries are descriptive. Writes Table 5 inputs |
| `exposure_person_years.py` | Person-years and first births in the completed-secondary state for 10, 11 and 12 years (Additional file 1, Table S19) |
| `check_prose_numbers.py`, `expected_values.csv` | Recompute numbers quoted in the manuscript (175 checks, including the marriage, exposure and harmonized-definition numbers) |
| `manuscript/` | `build_docx.py` (LaTeX to Word with native equations and Vancouver references), `make_strobe_checklist.py`, and the LaTeX source of the submitted manuscript |
| `independent_check_modelA.R` | Separate R implementation of Model A for Myanmar and Nepal |

## Outputs
`results/<Country>/` holds the hazard ratios (`stage1_final.csv`), absolute risks, specifications, landmark and all-women analyses, bootstrap draws and a run log. `results/stage2/` holds the pooled estimates, tables and check files. Figures are written to `figures/`.

## Settings
Years of schooling that define primary and secondary completion are set at the top of each country script: Bangladesh, Nepal and Pakistan 5 and 10; India 5 and 12; Afghanistan 6 and 12; Myanmar 5 and 11. The random seed for the bootstrap is fixed in `dhs_engine.py`.

`reference_results/` contains the summary tables produced by the final runs, for comparison with a new run.

## Changes in the October 2026 revision
- **Missing age at first marriage.** In BDHS 2022 all marriage variables are missing for about a third of ever-married women (3,383), and in NFHS-4 2016 for 4,047 (2.2%). The earlier `extras2.py` read a missing v511 as "never married" in the first-marriage hazard and as "birth before marriage". Those women are now dropped. Effects: Bangladesh first-marriage HR for completed secondary 0.52 to 0.42, births before marriage 13.4% to 0.9%; India 2.9% to 1.9%. The range over the six countries is 0.7 to 3.8%. The birth models and the marriage-adjusted birth models were not affected (the latter already excluded missing v511).
- **Pooling of the marriage hazard.** Only countries that sampled all women (India, Nepal, Myanmar) are pooled. Bangladesh, Pakistan and Afghanistan sampled ever-married women only, so their first-marriage hazard is conditional on having married and is descriptive.
- **New outputs.** `results/stage2/marriage_by_country.csv`, `marriage_pooled.csv`, `table5_marriage.csv`, `exposure_person_years.csv`; `results/<Country>/extras2.csv`. Reference copies are in `reference_results/`.
- **Manuscript tooling.** `manuscript/` holds the Word build and STROBE checklist generator. Table numbers in the manuscript follow order of appearance (marriage is Table 4, pooled estimates Table 5).
