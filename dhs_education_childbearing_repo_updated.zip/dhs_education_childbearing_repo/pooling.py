"""Random-effects pooling of country log hazard ratios: REML tau^2, Hartung-Knapp-Sidik-Jonkman interval (t, k-1 df, never narrower than the
conventional interval), 95% prediction interval, Q, I^2, leave-one-out. Checked against R metafor in stage2_validate.R."""
import numpy as np, pandas as pd
from scipy import optimize, stats

def reml_tau2(y, v):
    k = len(y)
    def nll(t2):
        w = 1 / (v + t2); mu = np.sum(w * y) / np.sum(w)
        return 0.5 * (np.sum(np.log(v + t2)) + np.log(np.sum(w)) + np.sum(w * (y - mu) ** 2))
    if nll(0.0) <= nll(1e-9) and optimize.minimize_scalar(nll, bounds=(0, 50), method="bounded", options={"xatol": 1e-12}).x < 1e-8:
        return 0.0
    r = optimize.minimize_scalar(nll, bounds=(0, 50), method="bounded", options={"xatol": 1e-12})
    return float(r.x) if nll(r.x) < nll(0.0) else 0.0

def pool(y, se, method="REML"):
    y = np.asarray(y, float); v = np.asarray(se, float) ** 2; k = len(y)
    t2 = reml_tau2(y, v)
    w = 1 / (v + t2); mu = np.sum(w * y) / np.sum(w); se_dl = np.sqrt(1 / np.sum(w))        # conventional (normal) SE
    q_hk = np.sum(w * (y - mu) ** 2) / (k - 1)
    se_knha = np.sqrt(q_hk / np.sum(w)); se_adhoc = np.sqrt(max(1.0, q_hk) / np.sum(w))
    tcrit = stats.t.ppf(0.975, k - 1); z = stats.norm.ppf(0.975)
    wf = 1 / v; muf = np.sum(wf * y) / np.sum(wf); Q = np.sum(wf * (y - muf) ** 2)
    s2 = (k - 1) * np.sum(wf) / (np.sum(wf) ** 2 - np.sum(wf ** 2)); I2 = 100 * t2 / (t2 + s2)      # metafor definition (tau^2 based)
    return dict(k=k, tau2=t2, tau=np.sqrt(t2), logHR=mu, HR=np.exp(mu),
                conv_lo=np.exp(mu - z * se_dl), conv_hi=np.exp(mu + z * se_dl),
                hksj_lo=np.exp(mu - tcrit * se_adhoc), hksj_hi=np.exp(mu + tcrit * se_adhoc),
                knha_raw_lo=np.exp(mu - tcrit * se_knha), knha_raw_hi=np.exp(mu + tcrit * se_knha), q_hk=q_hk,
                pi_lo=np.exp(mu - tcrit * np.sqrt(t2 + se_adhoc ** 2)), pi_hi=np.exp(mu + tcrit * np.sqrt(t2 + se_adhoc ** 2)),
                Q=Q, Q_p=1 - stats.chi2.cdf(Q, k - 1), I2=I2)

def loo(y, se, labels):
    rows = []
    for i in range(len(y)):
        idx = [j for j in range(len(y)) if j != i]
        r = pool(np.array(y)[idx], np.array(se)[idx]); r["omitted"] = labels[i]; rows.append(r)
    return pd.DataFrame(rows)

CORE4 = ["Bangladesh", "India", "Nepal", "Pakistan"]
def run(df, model="A", terms=("early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv")):
    out, loo_rows = [], []
    for term in terms:
        d = df[(df.model == model) & (df.term == term)].sort_values("country")
        for label, sub in (("all countries", d), ("core four", d[d.country.isin(CORE4)])):
            if len(sub) < 3: continue
            r = pool(sub.logHR.values, sub.se_boot.values); r.update(term=term, model=model, set=label, countries=", ".join(sub.country)); out.append(r)
            if label == "all countries":
                l = loo(sub.logHR.values, sub.se_boot.values, list(sub.country)); l["term"] = term; l["model"] = model; loo_rows.append(l)
    return pd.DataFrame(out), (pd.concat(loo_rows) if loo_rows else pd.DataFrame())
