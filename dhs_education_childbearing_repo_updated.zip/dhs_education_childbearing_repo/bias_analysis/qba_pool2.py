"""Pooled bias-adjusted HRs with marriage exit. Reads qba_grid_m.csv (p, lag, m grid) and the old births-only grid for m=0 cross-check."""
import sys, numpy as np, pandas as pd
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))))
from pooling import pool
ORDER = ["Bangladesh", "India", "Nepal", "Pakistan", "Afghanistan", "Myanmar", "Maldives"]
ORD = lambda t: [c for c in ORDER if not (c == "Maldives" and str(t).startswith("early"))]  # Maldives: ages 10-14 contrast not estimable
TERMS = ["early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv"]
g = pd.read_csv("qba_grid_m.csv"); g = g[g.ok & (g.resid < 1e-3)]
C = pd.read_csv("country_primary.csv"); C = C[C.model == "A"]
def shifts(p, lag, m):
    d = {}
    for c in ORDER:
        r = g[(g.country == c) & np.isclose(g.p, p) & np.isclose(g.lag, lag) & np.isclose(g.m, m)]
        if len(r) == 0: return None
        d[c] = {t: float(r["shift_" + t].iloc[0]) for t in TERMS}
    return d
def pooled(p, lag, m, frame):
    sh = shifts(p, lag, m)
    if sh is None: return None
    out = {}
    for t in TERMS:
        x = C[C.term == t].set_index("country").loc[ORD(t)]
        y = (x.aw_logHR if frame == "primary" else x.em_logHR).values + np.array([sh[c][t] for c in ORD(t)]); se = (x.aw_se if frame == "primary" else x.em_se).values
        out[t] = pool(y, se)
    return out, sh
SCEN = [("As observed (no lag, no truncation)", 0, 0, 0), ("Lag 1 year, no births or marriages end schooling", 0, 1, 0),
        ("Births only, central: 75% of births end schooling, lag 1 year", .75, 1, 0), ("Births only, severe: all births end schooling, lag 2 years", 1, 2, 0),
        ("Central: 75% of births and 50% of marriages end schooling, lag 1 year", .75, 1, .5),
        ("Severe: all births and 75% of marriages end schooling, lag 0.5 year", 1, .5, .75), ("Marriages only: 50% of marriages end schooling, lag 1 year", 0, 1, .5)]
if __name__ == "__main__":
    rows = []; crow = []
    for name, p, l, m in SCEN:
        for frame in ("primary", "ever-married"):
            o = pooled(p, l, m, frame) if (p, l, m) != (0, 0, 0) else None
            if (p, l, m) == (0, 0, 0):
                for t in TERMS:
                    x = C[C.term == t].set_index("country").loc[ORD(t)]; y = (x.aw_logHR if frame == "primary" else x.em_logHR).values; se = (x.aw_se if frame == "primary" else x.em_se).values
                    r = pool(y, se); rows.append(dict(scenario=name, frame=frame, p=p, lag=l, m=m, term=t, HR=r["HR"], lo=r["hksj_lo"], hi=r["hksj_hi"], pi_lo=r["pi_lo"], pi_hi=r["pi_hi"]))
                continue
            if o is None: print("missing", name); continue
            res, sh = o
            for t in TERMS:
                r = res[t]; rows.append(dict(scenario=name, frame=frame, p=p, lag=l, m=m, term=t, HR=r["HR"], lo=r["hksj_lo"], hi=r["hksj_hi"], pi_lo=r["pi_lo"], pi_hi=r["pi_hi"]))
            if frame == "primary":
                for c in ORDER:
                    for t in TERMS: crow.append(dict(scenario=name, country=c, term=t, shift=sh[c][t], adj_HR=float(np.exp(C[(C.country == c) & (C.term == t)].aw_logHR.iloc[0] + sh[c][t]))))
    D = pd.DataFrame(rows); D.to_csv("qba_pooled_m.csv", index=False); pd.DataFrame(crow).to_csv("qba_country_adj_m.csv", index=False)
    pd.set_option("display.width", 250, "display.max_rows", 400)
    print(D[D.frame == "primary"].pivot_table(index="scenario", columns="term", values="HR").round(2))
    print(D[D.frame == "ever-married"].pivot_table(index="scenario", columns="term", values="HR").round(2))
