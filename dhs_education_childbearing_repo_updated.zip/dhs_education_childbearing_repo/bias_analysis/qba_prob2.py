"""Probabilistic bias analysis with three parameters: p~tri(0.25,0.75,1), lag~tri(0,1,2.5), m~tri(0.25,0.5,1). Trilinear interpolation of the solved grid."""
import sys, numpy as np, pandas as pd
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))))
from pooling import pool
from scipy.interpolate import RegularGridInterpolator
ORDER = ["Bangladesh", "India", "Nepal", "Pakistan", "Afghanistan", "Myanmar", "Maldives"]
ORD = lambda t: [c for c in ORDER if not (c == "Maldives" and str(t).startswith("early"))]  # Maldives: ages 10-14 contrast not estimable
TERMS = ["early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv"]
g = pd.read_csv("qba_grid_m.csv"); C = pd.read_csv("country_primary.csv"); C = C[C.model == "A"]
ps = np.array(sorted(g.p.unique())); ls = np.array(sorted(g.lag.unique())); ms = np.array(sorted(g.m.unique()))
interp = {}; nfail = 0
for t in TERMS:
    for c in ORDER:
        M = np.full((len(ps), len(ls), len(ms)), np.nan)
        for i, p in enumerate(ps):
            for j, l in enumerate(ls):
                for k, m in enumerate(ms):
                    r = g[(g.country == c) & np.isclose(g.p, p) & np.isclose(g.lag, l) & np.isclose(g.m, m)]
                    if len(r) and bool(r.ok.iloc[0]) and r.resid.iloc[0] < 1e-3: M[i, j, k] = r["shift_" + t].iloc[0]
        interp[(c, t)] = RegularGridInterpolator((ps, ls, ms), M)
rng = np.random.default_rng(20261024); B = 4000
def draws(mdist):
    P, L, Mm = [], [], []; ntry = 0
    while len(P) < B:
        p = rng.triangular(0.25, 0.75, 1.0); l = rng.triangular(0.0, 1.0, 2.5); m = rng.triangular(*mdist) if mdist else 0.0; ntry += 1
        if all(np.isfinite(interp[(c, t)]((p, l, m)).item()) for t in TERMS for c in ORD(t)): P.append(p); L.append(l); Mm.append(m)
    return P, L, Mm, 1 - B / ntry
out = []
for label, mdist in (("births only", None), ("births and marriages", (0.25, 0.5, 1.0))):
    P, L, Mm, rej = draws(mdist); print(label, "reject share", round(rej, 4))
    for frame in ("primary", "ever-married"):
        for t in TERMS:
            x = C[C.term == t].set_index("country").loc[ORD(t)]
            y = (x.aw_logHR if frame == "primary" else x.em_logHR).values; se = (x.aw_se if frame == "primary" else x.em_se).values
            sysd, comb = [], []
            for p, l, m in zip(P, L, Mm):
                dl = np.array([interp[(c, t)]((p, l, m)).item() for c in ORD(t)]); ya = y + dl
                sysd.append(pool(ya, se)["HR"]); comb.append(pool(ya + rng.normal(0, se), se)["HR"])
            out.append(dict(scenario=label, frame=frame, term=t, sys_median=np.median(sysd), sys_lo=np.percentile(sysd, 2.5), sys_hi=np.percentile(sysd, 97.5),
                            comb_median=np.median(comb), comb_lo=np.percentile(comb, 2.5), comb_hi=np.percentile(comb, 97.5), B=B, reject_share=rej))
D = pd.DataFrame(out); D.to_csv("qba_probabilistic_m.csv", index=False); pd.set_option("display.width", 250); print(D.round(3).to_string())
