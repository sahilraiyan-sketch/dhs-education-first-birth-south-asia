import numpy as np, pandas as pd, sys, time
from multiprocessing import Pool
from qba_inputs import load, ORDER
from qba_sim import solve_country
cs, tg = load()
PS = [float(x) for x in sys.argv[1].split(",")]; LAGS = [float(x) for x in sys.argv[2].split(",")]; OUT = sys.argv[3]
def job(a):
    c, p, lag = a
    r = solve_country(cs[c], tg[c], p, lag)
    if r is None: return dict(country=c, p=p, lag=lag, ok=False)
    d = dict(country=c, p=p, lag=lag, ok=True, resid=r["resid"], share_err=float(np.abs(r["share_sim"] / r["share_tgt"] - 1).max()))
    for k, t in enumerate(("early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv")):
        d["obs_" + t] = float(tg[c][k]); d["true_" + t] = float(r["true_logHR"][k]); d["shift_" + t] = float(r["true_logHR"][k] - tg[c][k])
    return d
if __name__ == "__main__":
    jobs = [(c, p, l) for c in ORDER for p in PS for l in LAGS]
    t = time.time()
    with Pool(2) as pl: out = pl.map(job, jobs, chunksize=1)
    df = pd.DataFrame(out); df.to_csv(OUT, index=False); print("done", time.time() - t, "s;", (~df.ok).sum(), "failed")
