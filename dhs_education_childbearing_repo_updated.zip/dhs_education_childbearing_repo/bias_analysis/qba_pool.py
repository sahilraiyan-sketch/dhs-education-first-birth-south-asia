import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys, numpy as np, pandas as pd
sys.path.insert(0, ROOT)
from pooling import pool
ORDER = ["Bangladesh", "India", "Nepal", "Pakistan", "Afghanistan", "Myanmar", "Maldives"]
ORD = lambda t: [c for c in ORDER if not (c == "Maldives" and str(t).startswith("early"))]  # Maldives: ages 10-14 contrast not estimable
TERMS = ["early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv"]
GRID = sys.argv[1] if len(sys.argv) > 1 else "qba_grid_fine.csv"
g = pd.read_csv(GRID); g = g[g.ok & (g.resid < 1e-3)]
C = pd.read_csv("country_primary.csv"); C = C[C.model == "A"]
def pooled_for(p, lag, frame):
    out = {}
    for t in TERMS:
        y, s = [], []
        for c in ORD(t):
            r = g[(g.country == c) & (np.isclose(g.p, p)) & (np.isclose(g.lag, lag))]
            if len(r) == 0: return None
            sh = float(r["shift_" + t].iloc[0]); x = C[(C.country == c) & (C.term == t)].iloc[0]
            if frame == "primary": y.append(x.aw_logHR + sh); s.append(x.aw_se)
            else: y.append(x.em_logHR + sh); s.append(x.em_se)
        out[t] = pool(np.array(y), np.array(s))
    return out
if __name__ == "__main__":
    rows = []
    for frame in ("primary", "ever-married"):
        for p in sorted(g.p.unique()):
            for lag in sorted(g.lag.unique()):
                o = pooled_for(p, lag, frame)
                if o is None: continue
                for t in TERMS:
                    r = o[t]; rows.append(dict(frame=frame, p=p, lag=lag, term=t, HR=r["HR"], lo=r["hksj_lo"], hi=r["hksj_hi"], pi_lo=r["pi_lo"], pi_hi=r["pi_hi"], tau=r["tau"], I2=r["I2"]))
    D = pd.DataFrame(rows); D.to_csv("qba_pooled_fine.csv", index=False)
    pd.set_option("display.width", 250, "display.max_rows", 400)
    for (p, lag) in [(0.75, 1.0), (1.0, 2.0), (1.0, 1.0), (0.0, 1.0), (0.5, 1.0)]:
        print(p, lag); print(D[(D.p == p) & (D.lag == lag)][["frame", "term", "HR", "lo", "hi", "pi_lo", "pi_hi"]].round(2).to_string(index=False))
