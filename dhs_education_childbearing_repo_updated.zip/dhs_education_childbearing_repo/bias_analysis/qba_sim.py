"""Quantitative bias analysis for the age-specific schooling exposure (expected-value simulation).
Mechanism: analysis assigns schooling at age a as min(final, a-6). If true progression lags that line by D years AND a birth makes a
still-enrolled girl leave school (prob p), girls who give birth are credited with less schooling before the birth than they had reached
(immortal-time-like bias, exaggerated protection). lag 0 => no bias; p=0 and lag>0 => attenuation."""
import numpy as np, pandas as pd
import statsmodels.api as sm
from scipy import optimize
import warnings; warnings.filterwarnings("ignore")
AGES = np.arange(10, 20)
SUPPORT = np.arange(0, 13)
NMAX_D = 6
CLL = sm.families.links.CLogLog()

def dist_D(lag):
    if lag <= 0: d = np.zeros(NMAX_D + 1); d[0] = 1; return d
    from scipy.stats import poisson
    d = poisson.pmf(np.arange(NMAX_D + 1), lag); return d / d.sum()

def state_table(prim, sec):
    tab = np.zeros((17, 10), int)
    for v in range(17):
        for j, a in enumerate(AGES):
            tab[v, j] = int(v >= prim) if a <= 14 else (2 if v >= sec else (1 if v > prim else 0))
    return tab

def baseline(r15, r20):
    def f(x):
        al, ga = x; h = 1 - np.exp(-np.exp(al + ga * (AGES - 10))); S = np.cumprod(1 - h)
        return [1 - S[4] - r15, 1 - S[9] - r20]
    return optimize.fsolve(f, [-5.0, 0.4], xtol=1e-12)

def paths(prim, sec, S, D):
    return np.clip(np.minimum(S, AGES - 6 - D), 0, None)

class Country:
    def __init__(self, name, prim, sec, r15, r20, early_share, late_shares):
        self.name, self.prim, self.sec, self.r15, self.r20 = name, prim, sec, r15, r20
        self.early_share = early_share; self.late_shares = late_shares
        self.state = state_table(prim, sec); self.alpha, self.gamma = baseline(r15, r20)

def masses_from_params(c, m0, mmid, m10, m11, m12, h=0.5):
    m = np.zeros(len(SUPPORT)); m[0] = m0; m[c.prim] += h * mmid
    low = np.arange(c.prim + 1, 10); m[low] += (1 - h) * mmid / len(low); m[10] += m10; m[11] += m11; m[12] += m12
    return m / m.sum()

def simulate(c, mass, beta, p, lag):
    Dp = dist_D(lag); nP = np.zeros((10, 17)); eP = np.zeros((10, 17)); st = c.state
    al, ga = c.alpha, c.gamma; ar = np.arange(10); a6 = np.clip(AGES - 6, 0, None)
    for S in SUPPORT:
        if mass[S] <= 0: continue
        Pfull = np.minimum(S, a6)
        for D in range(NMAX_D + 1):
            wSD = mass[S] * Dp[D]
            if wSD <= 0: continue
            T = paths(c.prim, c.sec, S, D).astype(int)
            sT = st[T, ar]
            eta = al + ga * (AGES - 10) + np.where(AGES <= 14, beta[0] * (sT == 1), beta[1] * (sT == 1) + beta[2] * (sT == 2))
            h = 1 - np.exp(-np.exp(eta)); surv = np.concatenate([[1.0], np.cumprod(1 - h)])
            for j in range(10):
                fb = surv[j] * h[j]
                enrolled = (S > 0) and (T[j] < S)
                outs = [(p, T[j]), (1 - p, S)] if enrolled else [(1.0, S)]
                for pr, Sobs in outs:
                    if pr <= 0: continue
                    P = np.minimum(Sobs, a6); w = wSD * fb * pr
                    nP[ar[:j + 1], P[:j + 1]] += w; eP[j, P[j]] += w
            wn = wSD * surv[10]; nP[ar, Pfull] += wn
    return nP, eP

def cells(c, nP, eP):
    n = np.zeros((10, 3)); e = np.zeros((10, 3))
    for j in range(10):
        for v in range(17):
            s = c.state[v, j]; n[j, s] += nP[j, v]; e[j, s] += eP[j, v]
    return n, e

def fit(c, nP, eP):
    n, e = cells(c, nP, eP)
    rows, y, wt = [], [], []
    for j, a in enumerate(AGES):
        for s in range(3):
            if n[j, s] <= 1e-9: continue
            x = np.zeros(13); x[j] = 1
            if a <= 14:
                if s == 2: continue
                x[10] = (s == 1)
            else:
                x[11] = (s == 1); x[12] = (s == 2)
            rows.append(x); y.append(min(max(e[j, s] / n[j, s], 1e-12), 1 - 1e-12)); wt.append(n[j, s])
    X = np.array(rows); keep = np.abs(X).sum(0) > 0
    res = sm.GLM(np.array(y), X[:, keep], family=sm.families.Binomial(link=CLL), var_weights=np.array(wt)).fit(maxiter=100, tol=1e-10)
    out = np.full(13, np.nan); out[keep] = res.params
    return out[10:13]

def sim_shares(c, nP):
    early = nP[:5, c.prim:].sum() / nP[:5].sum(); late = nP[5:].sum()
    return np.array([early] + [nP[5:, k:].sum() / late for k in (10, 11, 12)])

def calibrate_mass(c, beta, p, lag, h=0.5, x0=None):
    tgt = np.array([c.early_share, c.late_shares[10], c.late_shares[11], c.late_shares[12]])
    def mk(x):
        lg = np.array([x[0], 0.0, x[1], x[2], x[3]]); w = np.exp(lg - lg.max()); w /= w.sum(); return masses_from_params(c, *w, h=h)
    def resid(x):
        nP, _ = simulate(c, mk(x), beta, p, lag); return np.log(sim_shares(c, nP) / tgt)
    x0 = np.array([-1.5, -1.5, -2.5, -2.5]) if x0 is None else x0
    r = optimize.least_squares(resid, x0, xtol=1e-9, ftol=1e-10, diff_step=1e-3, max_nfev=60)
    m = mk(r.x); nP, _ = simulate(c, m, beta, p, lag)
    return m, sim_shares(c, nP), tgt, r.x

def solve_country(c, target_logHR, p, lag, h=0.5, outer=3, inner=80, verbose=False):
    target = np.array(target_logHR, float); beta = target.copy(); x0 = None
    for o in range(outer):
        m, sim, tgt, x0 = calibrate_mass(c, beta, p, lag, h=h, x0=x0)
        for i in range(inner):
            nP, eP = simulate(c, m, beta, p, lag); est = fit(c, nP, eP)
            if np.any(~np.isfinite(est)): return None
            d = target - est
            if np.max(np.abs(d)) < 1e-4: break
            beta = beta + 0.9 * d
        if verbose: print(c.name, "outer", o, "true HR", np.exp(beta).round(3), "share rel err", np.abs(sim / tgt - 1).max().round(4), "resid", np.abs(d).max().round(5))
    nP, eP = simulate(c, m, beta, p, lag); est = fit(c, nP, eP)
    return dict(true_logHR=beta, est_logHR=est, mass=m, share_sim=sim, share_tgt=tgt, resid=float(np.max(np.abs(est - target))))
