
Marriage-exit extension (Oct 2026): qba_sim2.py (simulation with share m of first marriages ending schooling), run_qba_grid2.py (grid over p, lag, m), qba_pool2.py (pooled scenarios), qba_prob2.py (probabilistic). Outputs: qba_*_m.csv.
