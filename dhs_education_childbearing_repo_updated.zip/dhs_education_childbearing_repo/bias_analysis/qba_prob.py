import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys, numpy as np, pandas as pd
sys.path.insert(0, ROOT)
from pooling import pool
from scipy.interpolate import RegularGridInterpolator
ORDER = ["Bangladesh", "India", "Nepal", "Pakistan", "Afghanistan", "Myanmar", "Maldives"]
ORD = lambda t: [c for c in ORDER if not (c == "Maldives" and str(t).startswith("early"))]  # Maldives: ages 10-14 contrast not estimable
TERMS = ["early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv"]
g = pd.read_csv("qba_grid_fine.csv"); C = pd.read_csv("country_primary.csv"); C = C[C.model == "A"]
ps = np.array(sorted(g.p.unique())); ls = np.array(sorted(g.lag.unique()))
interp = {}
for t in TERMS:
    for c in ORDER:
        M = np.full((len(ps), len(ls)), np.nan)
        for i, p in enumerate(ps):
            for j, l in enumerate(ls):
                r = g[(g.country == c) & np.isclose(g.p, p) & np.isclose(g.lag, l)].iloc[0]
                if r.ok and r.resid < 1e-3: M[i, j] = r["shift_" + t]
        interp[(c, t)] = RegularGridInterpolator((ps, ls), M)
rng = np.random.default_rng(20261019); B = 4000
P, L = [], []
ntry = 0
while len(P) < B:
    p = rng.triangular(0.25, 0.75, 1.0); l = rng.triangular(0.0, 1.0, 2.5); ntry += 1
    ok = all(np.isfinite(interp[(c, t)]((p, l)).item()) for t in TERMS for c in ORD(t))
    if ok: P.append(p); L.append(l)
rej = 1 - B / ntry; print("draws tried", ntry, "rejected (no solution) share", round(rej, 4))
out = []
for frame in ("primary", "ever-married"):
    for t in TERMS:
        x = C[C.term == t].set_index("country").loc[ORD(t)]
        y = (x.aw_logHR if frame == "primary" else x.em_logHR).values; se = (x.aw_se if frame == "primary" else x.em_se).values
        sysd, comb = [], []
        for p, l in zip(P, L):
            dl = np.array([interp[(c, t)]((p, l)).item() for c in ORD(t)]); ya = y + dl
            sysd.append(pool(ya, se)["HR"]); comb.append(pool(ya + rng.normal(0, se), se)["HR"])
        o = pool(y, se)
        out.append(dict(frame=frame, term=t, observed=o["HR"], obs_lo=o["hksj_lo"], obs_hi=o["hksj_hi"], sys_median=np.median(sysd), sys_lo=np.percentile(sysd, 2.5), sys_hi=np.percentile(sysd, 97.5),
                        comb_median=np.median(comb), comb_lo=np.percentile(comb, 2.5), comb_hi=np.percentile(comb, 97.5), B=B, reject_share=rej))
D = pd.DataFrame(out); D.to_csv("qba_probabilistic_fine.csv", index=False); pd.set_option("display.width", 250); print(D.round(3).to_string())
