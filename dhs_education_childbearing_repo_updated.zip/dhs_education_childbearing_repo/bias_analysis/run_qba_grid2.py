"""Grid of bias-analysis solves with the marriage-exit parameter m. Usage: python3 run_qba_grid2.py p-list lag-list m-list out.csv
Resumable: rows already in out.csv are skipped; results are appended as they finish."""
import numpy as np, pandas as pd, sys, time, os, itertools
from multiprocessing import Pool
from qba_inputs import load, ORDER
from qba_sim2 import solve_country
cs, tg = load()
PS = [float(x) for x in sys.argv[1].split(",")]; LAGS = [float(x) for x in sys.argv[2].split(",")]; MS = [float(x) for x in sys.argv[3].split(",")]; OUT = sys.argv[4]
TERMS = ("early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv")
def job(a):
    c, p, lag, m = a
    r = solve_country(cs[c], tg[c], p, lag, m)
    if r is None: return dict(country=c, p=p, lag=lag, m=m, ok=False)
    d = dict(country=c, p=p, lag=lag, m=m, ok=True, resid=r["resid"], share_err=float(np.abs(r["share_sim"] / r["share_tgt"] - 1).max()))
    for k, t in enumerate(TERMS):
        d["obs_" + t] = float(tg[c][k]); d["true_" + t] = float(r["true_logHR"][k]); d["shift_" + t] = float(r["true_logHR"][k] - tg[c][k])
    return d
if __name__ == "__main__":
    done = set()
    if os.path.exists(OUT):
        o = pd.read_csv(OUT); done = set(zip(o.country, o.p.round(4), o.lag.round(4), o.m.round(4)))
    jobs = [(c, p, l, m) for m in MS for c in ORDER for p in PS for l in LAGS if (c, round(p, 4), round(l, 4), round(m, 4)) not in done]
    print(len(jobs), "jobs", flush=True); t = time.time(); n = 0
    with Pool(2) as pl:
        for d in pl.imap_unordered(job, jobs, chunksize=1):
            pd.DataFrame([d]).to_csv(OUT, mode="a", header=not os.path.exists(OUT), index=False); n += 1
            if n % 25 == 0: print(n, round(time.time() - t), "s", flush=True)
    print("done", round(time.time() - t), "s", flush=True)
