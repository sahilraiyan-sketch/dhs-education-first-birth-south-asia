"""Build the primary (all women where sampled) country estimates and pooled results; ever-married alongside."""
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import sys, numpy as np, pandas as pd
sys.path.insert(0, ROOT)
from pooling import pool, loo
R = ROOT + "/reference_results/"
ORDER = ["Bangladesh", "India", "Nepal", "Pakistan", "Afghanistan", "Myanmar", "Maldives"]; CORE4 = ORDER[:4]; AW = ["India", "Nepal", "Myanmar", "Maldives"]
ORD = lambda t: [c for c in ORDER if not (c == "Maldives" and str(t).startswith("early"))]  # Maldives: ages 10-14 contrast not estimable
TERMS = ["early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv"]
em = pd.read_csv(R + "stage2/stage1_all_primary.csv")
aw = pd.read_csv(R + "stage2/supplement_allwomen.csv")
aw = aw[aw.spec.str.contains("no marriage term")].copy()
aw["logHR"] = np.log(aw.HR); aw["se"] = (np.log(aw.hi) - np.log(aw.lo)) / (2 * 1.959964)
em["se"] = em.se_boot
rows = []
for m in "AB":
    for t in TERMS:
        for c in ORDER:
            e = em[(em.model == m) & (em.term == t) & (em.country == c)].iloc[0]
            row = dict(model=m, term=t, country=c, em_logHR=e.logHR, em_se=e.se, em_HR=e.HR, em_lo=e.lo_pct, em_hi=e.hi_pct, em_n=e.n_women, em_events=e.events)
            if c in AW:
                a = aw[(aw.model == m) & (aw.term == t) & (aw.country == c)].iloc[0]
                row.update(aw_logHR=a.logHR, aw_se=a.se, aw_HR=a.HR, aw_lo=a.lo, aw_hi=a.hi, aw_n=a.n_women, aw_events=a.events)
            else:
                row.update(aw_logHR=e.logHR, aw_se=e.se, aw_HR=e.HR, aw_lo=e.lo_pct, aw_hi=e.hi_pct, aw_n=e.n_women, aw_events=e.events)
            row["prim_frame"] = "All women" if c in AW else "Ever-married"
            rows.append(row)
C = pd.DataFrame(rows); C.to_csv("country_primary.csv", index=False)
P, L = [], []
for m in "AB":
    for t in TERMS:
        x = C[(C.model == m) & (C.term == t)].set_index("country").loc[ORD(t)]
        for setname, sub, y, s in [("Primary: all women where sampled, seven countries", x, x.aw_logHR, x.aw_se),
                                   ("Ever-married women, seven countries", x, x.em_logHR, x.em_se),
                                   ("Primary frame, core four (Bangladesh, India, Nepal, Pakistan)", x.loc[CORE4], x.loc[CORE4].aw_logHR, x.loc[CORE4].aw_se),
                                   ("Ever-married, core four", x.loc[CORE4], x.loc[CORE4].em_logHR, x.loc[CORE4].em_se)]:
            r = pool(y.values, s.values); r.update(model=m, term=t, set=setname); P.append(r)
        l = loo(x.aw_logHR.values, x.aw_se.values, list(x.index)); l["model"] = m; l["term"] = t; l["frame"] = "primary"; L.append(l)
P = pd.DataFrame(P); P.to_csv("pooled_primary_allwomen.csv", index=False); pd.concat(L).to_csv("loo_primary_allwomen.csv", index=False)
pd.set_option("display.width", 250, "display.max_columns", 30)
print(P[["model", "term", "set", "k", "HR", "hksj_lo", "hksj_hi", "pi_lo", "pi_hi", "tau", "I2"]].round(3).to_string())
