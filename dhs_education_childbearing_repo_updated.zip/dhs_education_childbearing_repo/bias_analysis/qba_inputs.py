import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import pandas as pd, numpy as np
from qba_sim import Country
R = ROOT + "/reference_results/stage2/"
ORDER = ["Bangladesh", "India", "Nepal", "Pakistan", "Afghanistan", "Myanmar", "Maldives"]
def load():
    ex = pd.read_csv(R + "exposure_person_years.csv"); ar = pd.read_csv(R + "table3_absolute_risks.csv"); t1 = pd.read_csv(R + "table1_sample.csv").set_index("country")
    em = pd.read_csv(R + "stage1_all_primary.csv"); em = em[em.model == "A"]
    cs = {}; targets = {}
    for c in ORDER:
        x = ex[ex.country == c]; r = ar[(ar.country == c) & (ar.group == "No schooling")].set_index("by_age").risk
        late = {int(k): float(v) / 100 for k, v in zip(x.secondary_years, x.pct_of_late_py)}
        early = float(x.py_early_prim_completed.iloc[0] / x.py_early.iloc[0])
        cs[c] = Country(c, int(t1.loc[c, "primary_years"]), int(t1.loc[c, "secondary_years"]), float(r[15]), float(r[20]), early, late)
        targets[c] = [float(em[(em.country == c) & (em.term == t)].logHR.iloc[0]) for t in ("early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv")]
    return cs, targets
