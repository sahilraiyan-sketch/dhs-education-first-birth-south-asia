"""Builds the manuscript tables (LaTeX) and figures for the seven-country version, and a numbers sheet for the text.
Usage (from the repo folder, after integrate_maldives.py):
    python make_seven_country_outputs.py --old-tables <folder with the six-country table1.tex, table_abs_main.tex, table_pooled_main.tex, table_bias_main.tex> [--out out7] [--validate]
Rows of the absolute-risk and sample tables for the six existing countries are taken from the old tables (their bootstrap files are not needed); Maldives rows are computed.
--validate : run on the six-country reference files (no Maldives) and compare the regenerated bias/pooled tables with the old ones."""
import os, re, sys, json, argparse
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
sys.path.insert(0, os.getcwd())
from pooling import pool
ap = argparse.ArgumentParser(); ap.add_argument("--old-tables", required=True); ap.add_argument("--out", default="out7"); ap.add_argument("--validate", action="store_true"); a = ap.parse_args()
BASE = Path.cwd(); REF = BASE / "reference_results"; RES = BASE / "results"; OLD = Path(a.old_tables); OUT = BASE / a.out; (OUT / "tables").mkdir(parents=True, exist_ok=True); (OUT / "figures").mkdir(exist_ok=True)
ORDER = ["Bangladesh", "India", "Nepal", "Pakistan", "Afghanistan", "Myanmar"] + ([] if a.validate else ["Maldives"]); K = len(ORDER); KW = {6: "six", 7: "seven"}[K]
AW = [c for c in ["India", "Nepal", "Myanmar", "Maldives"] if c in ORDER]; TERMS = ["early_prim_comp_tv", "late_inc_sec_tv", "late_comp_sec_tv"]
CP = pd.read_csv(BASE / "bias_analysis" / "country_primary.csv"); CP = CP[(CP.model == "A") & CP.country.isin(ORDER)]
T1 = pd.read_csv(REF / "stage2" / "table1_sample.csv").set_index("country"); NUMS = {}
f2 = lambda x: f"{x:.2f}"; row_hr = lambda r: f"{f2(r['HR'])} ({f2(r['hksj_lo'] if 'hksj_lo' in r else r['lo'])}, {f2(r['hksj_hi'] if 'hksj_hi' in r else r['hi'])})"
def body(path):
    t = open(path, encoding="utf-8").read(); return t
# ------------------------------------------------------------------ Table 1
old = body(OLD / "table1.tex"); lines = old.splitlines(); hdr = [l for l in lines[:4]]; rows = [l for l in lines if re.match(r"^(Bangladesh|India|Nepal|Pakistan|Afghanistan|Myanmar) &", l)]
num = lambda s: int(s.replace(",", ""))
def t1_row(c):
    if any(r.startswith(c + " &") for r in rows): return next(r for r in rows if r.startswith(c + " &"))
    cs = T1.loc[c]; aw = pd.read_csv(RES / c / "stage1_allwomen.csv"); aw = aw[(aw.model == "A")].iloc[0]; frame = cs.frame
    yrs = cs.waves.replace(", ", ", ")
    return (f"{c} & {yrs} & {frame} & {int(aw.n_women):,} & {int(cs.n_women):,} & {int(aw.events):,} ({int(cs.events):,}) & {cs.pct_birth_before20_weighted:.1f} & {cs.pct_before15_weighted:.1f} & {int(cs.primary_years)} / {int(cs.secondary_years)} \\\\")
rows7 = [t1_row(c) for c in ORDER]; tot = [0, 0, 0, 0]
for r in rows7:
    cells = [x.strip() for x in r.rstrip("\\ ").split("&")]; tot[0] += num(cells[3]); tot[1] += num(cells[4]); m = re.match(r"([\d,]+) \(([\d,]+)\)", cells[5]); tot[2] += num(m.group(1)); tot[3] += num(m.group(2))
t1 = "\n".join(hdr[:4]) + "\n" + "\n".join(rows7) + f"\n\\midrule\nTotal & & & {tot[0]:,} & {tot[1]:,} & {tot[2]:,} ({tot[3]:,}) & & & \\\\\n\\bottomrule\n\\end{{tabular}}\n"
open(OUT / "tables" / "table1.tex", "w", encoding="utf-8").write(t1); NUMS["table1_totals"] = dict(primary_women=tot[0], ever_married_women=tot[1], primary_births=tot[2], ever_married_births=tot[3])
# ------------------------------------------------------------------ Absolute-risk table (+ parsed values for the figure)
old = body(OLD / "table_abs_main.tex"); L = old.splitlines(); i0 = next(i for i, l in enumerate(L) if l.startswith("\\midrule")) + 1; i1 = next(i for i, l in enumerate(L) if l.startswith("\\bottomrule"))
parsed = []; blocks = []; cur = None
for l in L[i0:i1]:
    if l.startswith("\\addlinespace"): continue
    cells = [x.strip() for x in l.rstrip("\\ ").split("&")]
    if cells[0]: cur = cells[0]; blocks.append(cur)
    parsed.append((cur, cells[1], cells[2:]))
def ar_rows(c):
    out = []
    def mk(df, sample):
        g = lambda grp, age=20: df[(df.group.str.startswith(grp)) & (df.by_age == age)].iloc[0]
        n, p, s = g("No schooling"), g("Primary only"), g("Complete secondary"); d = g("Risk difference: complete secondary minus No schooling")
        f = lambda r: f"{100 * r.risk:.1f} ({100 * r.lo:.1f}, {100 * r.hi:.1f})"
        return (c, sample, [f(n), f(p), f(s), f"{100 * d.risk:.1f} ({100 * d.lo:.1f}, {100 * d.hi:.1f})", f"{-1000 * d.risk:.0f} ({-1000 * d.hi:.0f}, {-1000 * d.lo:.0f})"], dict(none=n.risk, prim=p.risk, sec=s.risk, diff=d.risk))
    em = pd.read_csv(RES / c / "absolute_risks.csv") if (RES / c / "absolute_risks.csv").exists() else pd.read_csv(REF / c / "absolute_risks.csv")
    if c in AW:
        aw = pd.read_csv(RES / c / "allwomen_out" / "absolute_risks.csv"); out.append(mk(aw, "All women$^{a}$")); out.append((c, "Ever-married", mk(em, "Ever-married")[2], mk(em, "Ever-married")[3]))
    else: out.append(mk(em, "Ever-married"))
    return out
new_rows = parsed[:]
for c in ORDER:
    if c not in blocks: new_rows += [(c if k == 0 else "", s, v) for k, (_, s, v, *_x) in enumerate(ar_rows(c))]
def fmt_abs(rows):
    out, prev = [], None
    for k, (c, s, v) in enumerate(rows):
        out.append(f"{c if c and c != prev else ''} & {s} & " + " & ".join(v) + " \\\\"); prev = c or prev
        if k + 1 < len(rows) and rows[k + 1][0] and rows[k + 1][0] != (c or prev): out.append("\\addlinespace")
    return out
# rebuild with blank country for continuation rows
rr = []; last = None
for c, s, v in new_rows:
    rr.append((c if c != last else "", s, v)); last = c
abs_tex = "\n".join(L[:i0]) + "\n" + "\n".join(fmt_abs([(c if c else rr[k - 1][0], s, v) for k, (c, s, v) in enumerate(rr)])).replace("\n & ", "\n & ") + "\n" + "\n".join(L[i1:]) + "\n"
open(OUT / "tables" / "table_abs_main.tex", "w", encoding="utf-8").write(abs_tex)
val = lambda s: float(re.match(r"-?[\d.]+", s).group(0)); pr_diff, em_diff = [], []; bars = []
cc = None
for c, s, v in [(c if c else rr[k - 1][0], s, v) for k, (c, s, v) in enumerate(rr)]:
    d = -val(v[3]); (pr_diff if (s.startswith("All women") or c not in AW) else em_diff).append((c, d)); bars.append((c, s, [val(v[0]), val(v[1]), val(v[2])], [tuple(map(float, re.findall(r"[\d.]+", x.split("(")[1]))) for x in v[:3]]))
em_all = [(c, -val(v[3])) for c, s, v in [(c if c else rr[k - 1][0], s, v) for k, (c, s, v) in enumerate(rr)] if s.startswith("Ever-married")]
NUMS["abs_risk_diff_ever_married_range"] = [min(x[1] for x in em_all), max(x[1] for x in em_all), min(em_all, key=lambda x: x[1])[0], max(em_all, key=lambda x: x[1])[0]]
prim_all = [(c, -val(v[3])) for c, s, v in [(c if c else rr[k - 1][0], s, v) for k, (c, s, v) in enumerate(rr)] if (s.startswith("All women") or c not in AW)]
NUMS["abs_risk_diff_primary_range"] = [min(x[1] for x in prim_all), max(x[1] for x in prim_all), min(prim_all, key=lambda x: x[1])[0], max(prim_all, key=lambda x: x[1])[0]]
sec20 = [(c, val(v[2])) for c, s, v in [(c if c else rr[k - 1][0], s, v) for k, (c, s, v) in enumerate(rr)]]; none20 = [(c, val(v[0]), s) for c, s, v in [(c if c else rr[k - 1][0], s, v) for k, (c, s, v) in enumerate(rr)]]
NUMS["risk_none_age20_range"] = [min(none20, key=lambda x: x[1])[:2], max(none20, key=lambda x: x[1])[:2]]; NUMS["risk_secondary_age20_range"] = [min(sec20, key=lambda x: x[1]), max(sec20, key=lambda x: x[1])]
# ------------------------------------------------------------------ Pooled table
PP = pd.read_csv(BASE / "bias_analysis" / "pooled_primary_allwomen.csv"); PP = PP[PP.model == "A"]
prim_set = PP[PP.set.str.startswith("Primary: all women")]; em_set = PP[PP.set.str.startswith("Ever-married women,")]
def prow(lab, r): return f"{lab} & {row_hr(r)} & ({f2(r['pi_lo'])}, {f2(r['pi_hi'])}) & {f2(r['tau'])} & {r['I2']:.0f} \\\\"
LAB = {TERMS[0]: "Ages 10-14, primary completed", TERMS[1]: "Ages 15-19, incomplete secondary", TERMS[2]: "Ages 15-19, secondary completed"}
aw_names = ", ".join(AW[:-1]) + " and " + AW[-1]
pool_lines = ["\\begin{tabular}{lcccc}", "\\toprule", "Contrast & Pooled HR (95\\% CI) & 95\\% prediction interval & $\\tau$ (SD of log HR) & $I^2$ (\\%) \\\\", "\\midrule",
              f"\\multicolumn{{5}}{{l}}{{\\textit{{Primary sample (all women in {aw_names}; ever-married women elsewhere), Model A}}}}\\\\"]
for t in TERMS: pool_lines.append(prow(LAB[t], prim_set[prim_set.term == t].iloc[0]))
pool_lines += ["\\midrule", f"\\multicolumn{{5}}{{l}}{{\\textit{{Ever-married women in all {KW} countries (six for ages 10 to 14), Model A}}}}\\\\"]
for t in TERMS: pool_lines.append(prow(LAB[t], em_set[em_set.term == t].iloc[0]))
NUMS["pooled_primary"] = {t: prim_set[prim_set.term == t].iloc[0][["HR", "hksj_lo", "hksj_hi", "pi_lo", "pi_hi", "tau", "I2"]].to_dict() for t in TERMS}; NUMS["pooled_ever_married"] = {t: em_set[em_set.term == t].iloc[0][["HR", "hksj_lo", "hksj_hi", "pi_lo", "pi_hi", "tau", "I2"]].to_dict() for t in TERMS}
# harmonized 10-year rows
H = pd.read_csv(REF / "stage2" / "stage1_all_harmonized10.csv"); H = H[H.model == "A"]; warn = []
def harm_primary():
    ys, ss = {t: [] for t in TERMS[1:]}, {t: [] for t in TERMS[1:]}
    for c in ORDER:
        for t in TERMS[1:]:
            if c in AW and c != "Nepal":
                f = RES / c / "aw_harmonized10.csv"; f2_ = REF / c / "aw_harmonized10.csv"; ff = f if f.exists() else (f2_ if f2_.exists() else None)
                if ff is None: warn.append(f"aw_harmonized10.csv missing for {c}"); return None
                d = pd.read_csv(ff); r = d[(d.model == "A") & (d.term == t)].iloc[0]; ys[t].append(r.logHR); ss[t].append(r.se)
            elif c == "Nepal":
                r = CP[(CP.country == c) & (CP.term == t)].iloc[0]; ys[t].append(r.aw_logHR); ss[t].append(r.aw_se)
            else:
                r = H[(H.country == c) & (H.term == t)].iloc[0]; ys[t].append(r.logHR); ss[t].append(r.se_boot)
    return {t: pool(np.array(ys[t]), np.array(ss[t])) for t in TERMS[1:]}
hp = harm_primary(); HE = pd.read_csv(REF / "stage2" / "pooled_harmonized10.csv"); HE = HE[(HE.model == "A") & (HE.set == "all countries")]
pool_lines += ["\\midrule", "\\multicolumn{5}{l}{\\textit{Harmonized 10-year definition of completed secondary schooling in all countries: primary sample, Model A}}\\\\"]
if hp:
    for t in TERMS[1:]: pool_lines.append(prow(LAB[t], hp[t])); NUMS.setdefault("harmonized_primary", {})[t] = {k: float(hp[t][k]) for k in ("HR", "hksj_lo", "hksj_hi", "pi_lo", "pi_hi", "tau", "I2")}
else:
    oldp = body(OLD / "table_pooled_main.tex").splitlines(); k0 = next(i for i, l in enumerate(oldp) if "primary sample, Model A" in l and "Harmonized" in l)
    pool_lines += oldp[k0 + 1:k0 + 3]; pool_lines.append("% WARNING: the two rows above are the OLD six-country harmonized primary-sample rows (need aw_harmonized10.csv for India and Myanmar)")
pool_lines += ["\\midrule", f"\\multicolumn{{5}}{{l}}{{\\textit{{Harmonized 10-year definition: ever-married women in all {KW} countries, Model A}}}}\\\\"]
for t in TERMS[1:]: pool_lines.append(prow(LAB[t], HE[HE.term == t].iloc[0])); NUMS.setdefault("harmonized_ever_married", {})[t] = HE[HE.term == t].iloc[0][["HR", "hksj_lo", "hksj_hi", "pi_lo", "pi_hi", "tau", "I2"]].to_dict()
pool_lines += ["\\bottomrule", "\\end{tabular}"]; open(OUT / "tables" / "table_pooled_main.tex", "w", encoding="utf-8").write("\n".join(pool_lines) + "\n")
# ------------------------------------------------------------------ Bias table
QP = pd.read_csv(BASE / "bias_analysis" / "qba_pooled_m.csv"); QR = pd.read_csv(BASE / "bias_analysis" / "qba_probabilistic_m.csv")
SC = [("As observed (no lag, no truncation)", "As observed (no lag, no truncation)"), ("Births only, moderate: 75\\% of births end schooling, lag 1 year", "Births only, central"),
      ("Births only, severe: all births end schooling, lag 2 years", "Births only, severe"),
      ("Births and marriages, moderate: 75\\% of births and 50\\% of marriages end schooling, lag 1 year", "Central: 75% of births and 50%"),
      ("Births and marriages, severe: all births and 75\\% of marriages end schooling, lag 0.5 year", "Severe: all births and 75%")]
def bias_cells(frame, pref):
    out = []
    for t in TERMS:
        r = QP[(QP.frame == frame) & QP.scenario.str.startswith(pref) & (QP.term == t)]
        out.append(row_hr(r.iloc[0]) if len(r) else "not feasible")
    return out
def prob_cells(frame, scen):
    return [(lambda r: f"{f2(r.sys_median)} ({f2(r.sys_lo)}, {f2(r.sys_hi)})")(QR[(QR.scenario == scen) & (QR.frame == frame) & (QR.term == t)].iloc[0]) for t in TERMS]
bt = ["\\begin{tabular}{p{6.4cm}p{3.1cm}p{3.1cm}p{3.1cm}}", "\\toprule", "Scenario & Completed primary, ages 10 to 14 & Incomplete secondary, ages 15 to 19 & Completed secondary, ages 15 to 19 \\\\", "\\midrule"]
rj = float(QR[QR.scenario == "births only"].reject_share.iloc[0]); rm = float(QR[QR.scenario == "births and marriages"].reject_share.iloc[0]); NUMS["probabilistic_discarded"] = dict(births_only=rj, births_and_marriages=rm)
for frame, title in (("primary", "\\textbf{Primary sample}"), ("ever-married", f"\\textbf{{Ever-married women, {KW} countries}}")):
    bt.append(title + " & & & \\\\"); bt.append("\\midrule")
    for lab, pref in SC: bt.append(f"{lab} & " + " & ".join(bias_cells(frame, pref)) + " \\\\")
    bt.append("Probabilistic, births only: median (2.5th to 97.5th percentile)$^{a}$ & " + " & ".join(prob_cells(frame, "births only")) + " \\\\")
    bt.append("Probabilistic, births and marriages: median (2.5th to 97.5th percentile)$^{a}$ & " + " & ".join(prob_cells(frame, "births and marriages")) + " \\\\")
    if frame == "primary": bt.append("\\midrule")
bt += ["\\bottomrule", "\\end{tabular}"]; open(OUT / "tables" / "table_bias_main.tex", "w", encoding="utf-8").write("\n".join(bt) + "\n")
NUMS["bias_scenarios"] = {f"{fr}|{sc}|{t}": QP[(QP.frame == fr) & (QP.scenario == sc) & (QP.term == t)][["HR", "lo", "hi"]].iloc[0].round(3).to_dict() for fr in ("primary", "ever-married") for sc in QP.scenario.unique() for t in TERMS if len(QP[(QP.frame == fr) & (QP.scenario == sc) & (QP.term == t)])}
G = pd.read_csv(BASE / "bias_analysis" / "qba_grid_m.csv"); NUMS["qba_grid_feasible_by_country"] = {c: float(((G.country == c) & G.ok & (G.resid < 1e-3)).sum() / max(1, (G.country == c).sum())) for c in ORDER}
# ------------------------------------------------------------------ Forest figures
SEC = {c: int(T1.loc[c, "secondary_years"]) for c in ORDER}; PRM = {c: int(T1.loc[c, "primary_years"]) for c in ORDER}
def forest(term, fname, late):
    x = CP[CP.term == term].set_index("country").loc[ORDER]; fig, ax = plt.subplots(figsize=(10, 6.2)); n = len(ORDER); ypos = np.arange(n + 3)[::-1][: n + 3]; lo_, hi_ = (0.01, 3.0) if late else (0.04, 1.8)
    clip = lambda v: float(np.clip(v, lo_, hi_))
    for i, c in enumerate(ORDER):
        r = x.loc[c]; y = ypos[i]; yo = y + 0.28 if c in AW else y; yp = y - 0.12 if c in AW else y
        if (c == "Maldives") and not late:
            ax.text(-0.015, y, f"{c}  not estimable ({int(round(0))}13 births before age 15)".replace("0" + "13", "13"), va="center", ha="right", fontsize=10.5, transform=ax.get_yaxis_transform()); continue
        if c in AW: ax.plot([clip(r.em_lo), clip(r.em_hi)], [yo] * 2, color="#555555", lw=1.2); ax.plot(clip(r.em_HR), yo, "o", mfc="white", mec="#333333", ms=6)
        ax.plot([clip(r.aw_lo), clip(r.aw_hi)], [yp] * 2, color="#222222", lw=2.2); ax.plot(clip(r.aw_HR), yp, "s", color="#222222", ms=8)
        tail = f"{r.aw_HR:.2f}" + (f" ({r.em_HR:.2f})" if c in AW else ""); name = f"{c} ({SEC[c]} yrs)" if late else f"{c}"
        ax.text(-0.015, y, f"{name}  {tail}", va="center", ha="right", fontsize=10.5, transform=ax.get_yaxis_transform())
    for j, (nm, d, colr) in enumerate([(f"Pooled, primary (all women where sampled)", prim_set, "#222222"), (f"Pooled, ever-married ({'six' if not late else KW} countries)", em_set, "#777777")]):
        r = d[d.term == term].iloc[0]; yy = ypos[n + 0] - 1.6 - 1.1 * j
        ax.fill([r.hksj_lo, r.HR, r.hksj_hi, r.HR], [yy, yy + .3, yy, yy - .3], color=colr); ax.plot([clip(r.pi_lo), clip(r.pi_hi)], [yy - .45] * 2, color=colr, lw=1.6, ls="--")
        ax.text(-0.015, yy, f"{nm}  {r.HR:.2f}", va="center", ha="right", fontsize=10.5, transform=ax.get_yaxis_transform())
    ax.axvline(1, color="grey", lw=1); ax.set_xscale("log"); ax.set_xlim(lo_, hi_); tk = [.02, .05, .1, .2, .5, 1, 2] if late else [.1, .2, .3, .5, 1]; ax.set_xticks(tk); ax.set_xticklabels([("%g" % v) if v != 1 else "1.0" for v in tk]); ax.minorticks_off()
    ax.set_yticks([]); ax.set_xlabel("Hazard ratio (log scale)", fontsize=10.5); [ax.spines[s].set_visible(False) for s in ("top", "right", "left")]
    plt.subplots_adjust(left=.42, right=.97, top=.97, bottom=.1); plt.savefig(OUT / "figures" / fname, dpi=200); plt.close()
forest(TERMS[0], "figure2_forest_early.png", False); forest(TERMS[2], "figure3_forest_late.png", True)
# ------------------------------------------------------------------ Absolute-risk figure (bars = primary sample; diamonds = ever-married where they differ)
fig, ax = plt.subplots(figsize=(9.6, 4.6)); w = .26; cols = ["#9aa5b1", "#4f7cac", "#1f3a5f"]; labs = ["No schooling", "Primary only", "Secondary completed"]
prim_b = {c: (v, ci) for c, s, v, ci in bars if s.startswith("All women") or c not in AW}; em_b = {c: v for c, s, v, ci in bars if s.startswith("Ever-married") and c in AW}
for k in range(3):
    for i, c in enumerate(ORDER):
        v, ci = prim_b[c]; ax.bar(i + (k - 1) * w, v[k], w, color=cols[k], yerr=[[v[k] - ci[k][0]], [ci[k][1] - v[k]]], capsize=2, label=(labs[k] if i == 0 else None))
        if c in em_b: ax.plot(i + (k - 1) * w, em_b[c][k], marker="D", ms=5, mfc="white", mec="black", ls="none", label=("Ever-married women (same countries)" if (k == 0 and c == AW[0]) else None))
ax.set_xticks(range(K)); ax.set_xticklabels([c + ("\n(all women)" if c in AW else "\n(ever-married)") for c in ORDER], fontsize=9); ax.set_ylabel("Cumulative incidence of first birth by age 20 (%)", fontsize=9)
h, l_ = ax.get_legend_handles_labels(); order = [l_.index("Ever-married women (same countries)")] + [l_.index(x) for x in labs] if "Ever-married women (same countries)" in l_ else range(len(l_))
ax.legend([h[i] for i in order], [l_[i] for i in order], fontsize=8.5, frameon=False); [ax.spines[s].set_visible(False) for s in ("top", "right")]; plt.tight_layout(); plt.savefig(OUT / "figures" / "figure1_absolute_risk.png", dpi=200); plt.close()
# ------------------------------------------------------------------ numbers sheet
json.dump(NUMS, open(OUT / "numbers_for_text.json", "w"), indent=1, default=lambda o: float(o) if hasattr(o, "__float__") else str(o))
print("\n".join(["written: " + str(p.relative_to(BASE)) for p in sorted(OUT.rglob("*")) if p.is_file()]))
for w_ in warn: print("WARNING:", w_)
if a.validate:
    for nm in ("table_bias_main.tex", "table_pooled_main.tex", "table_abs_main.tex", "table1.tex"):
        o = [l.strip() for l in open(OLD / nm, encoding="utf-8").read().splitlines() if l.strip()]; n = [l.strip() for l in open(OUT / "tables" / nm, encoding="utf-8").read().splitlines() if l.strip()]
        diff = [(x, y) for x, y in zip(o, n) if x != y]; print(f"VALIDATE {nm}: lines old {len(o)} new {len(n)}; differing lines {len(diff)}"); [print("   OLD:", x[:170], "\n   NEW:", y[:170]) for x, y in diff[:6]]
